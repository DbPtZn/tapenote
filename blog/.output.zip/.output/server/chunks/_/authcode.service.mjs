import { A as Authcode } from './authcode.schema.mjs';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, key + "" , value);
  return value;
};
class AuthcodeService {
  constructor() {
    __publicField(this, "authcodesRepository");
    this.authcodesRepository = Authcode;
  }
  add(userId) {
    try {
      return this.authcodesRepository.create({
        userId,
        name: "",
        code: "",
        desc: ""
      });
    } catch (error) {
      throw error;
    }
  }
  findAll(userId) {
    try {
      return this.authcodesRepository.find({ userId });
    } catch (error) {
      throw error;
    }
  }
  findOne(_id, userId) {
    try {
      return this.authcodesRepository.findOne({ _id, userId });
    } catch (error) {
      throw error;
    }
  }
  findOneByCode(code, userId) {
    try {
      return this.authcodesRepository.findOne({ code, userId });
    } catch (error) {
      throw error;
    }
  }
  update(dto, userId) {
    try {
      const { _id, ...data } = dto;
      return this.authcodesRepository.findOneAndUpdate(
        { _id, userId },
        data,
        { new: true }
      );
    } catch (error) {
      throw error;
    }
  }
  delete(_id, userId) {
    try {
      return this.authcodesRepository.deleteOne({ _id, userId });
    } catch (error) {
      throw error;
    }
  }
}
const authcodeService = new AuthcodeService();

export { authcodeService as a };
//# sourceMappingURL=authcode.service.mjs.map
