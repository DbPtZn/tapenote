import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { U as User } from './user.schema.mjs';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, key + "" , value);
  return value;
};
class UserService {
  constructor() {
    __publicField(this, "usersRepository");
    this.usersRepository = User;
  }
  /** 创建新用户 */
  async create(createUserDto) {
    try {
      const { account, password, nickname } = createUserDto;
      console.log(createUserDto);
      const isValid = /^[a-zA-Z0-9@.]+$/.test(account);
      if (!isValid)
        throw new Error("\u8D26\u53F7\u540D\u79F0\u5305\u542B\u975E\u6CD5\u5B57\u7B26\uFF01");
      if (password.includes(" "))
        throw new Error("\u5BC6\u7801\u4E0D\u80FD\u5305\u542B\u7A7A\u683C\uFF01");
      const isUserExist = await this.findOneByAccount(account);
      if (isUserExist) {
        throw new Error("\u8BE5\u8D26\u53F7\u5DF2\u6CE8\u518C\uFF01");
      }
      const UID = await this.generateUID();
      const salt = bcrypt.genSaltSync();
      const encryptedPassword = bcrypt.hashSync(password, salt);
      console.log(encryptedPassword);
      const user = await this.usersRepository.create({
        account,
        nickname,
        encryptedPassword,
        UID
      });
      console.log(user);
      return user;
    } catch (error) {
      console.log(error);
      throw error;
    }
  }
  /** 通过账号查询用户 */
  async findOneByAccount(account) {
    try {
      const user = await this.usersRepository.findOne({ account });
      return user || null;
    } catch (error) {
      throw error;
    }
  }
  async findOneById(_id) {
    try {
      const user = await this.usersRepository.findById(_id);
      return user;
    } catch (error) {
      throw error;
    }
  }
  async findUserInfo(_id) {
    try {
      const user = await this.usersRepository.findOne(
        { _id },
        { encryptedPassword: 0 }
        // 需要排除的字段
      );
      return user;
    } catch (error) {
      throw error;
    }
  }
  async findAll() {
    try {
      const users = await this.usersRepository.find(
        {},
        {
          UID: 1,
          nickname: 1,
          avatar: 1,
          desc: 1,
          createdAt: 1,
          updatedAt: 1
        }
      );
      return users;
    } catch (error) {
      throw error;
    }
  }
  /** 生成用户私有文件夹的地址 */
  async generateUID() {
    let UID = generateRandomStr();
    const __rootdirname = process.cwd();
    let isExist = await this.usersRepository.exists({ UID });
    let fullPath = path.join(__rootdirname, "public", UID);
    console.log(fullPath);
    console.log(isExist);
    while (fs.existsSync(fullPath) || isExist) {
      console.log("\u8BE5\u7528\u6237\u6587\u4EF6\u5939\u5DF2\u5B58\u5728\uFF0C\u91CD\u65B0\u751F\u6210");
      UID = generateRandomStr();
      isExist = await this.usersRepository.exists({ UID });
      fullPath = path.join(__rootdirname, "public", UID);
    }
    console.log(UID);
    return UID;
  }
  /** 用户密码登录验证 */
  async validateUser(account, password) {
    try {
      const user = await this.findOneByAccount(account);
      if (!user)
        return null;
      const valid = bcrypt.compareSync(password, user.encryptedPassword);
      if (valid)
        return user;
      return null;
    } catch (error) {
      throw error;
    }
  }
  /** 更新接收器状态 */
  updateReceiverConfig(status, _id) {
    try {
      return this.usersRepository.updateOne(
        { _id },
        { $set: { "receiverConfig.status": status } }
      );
    } catch (error) {
      throw error;
    }
  }
  /** 更新比较麻烦，需要考虑增删改的情况，所以先直接用前端改完的数据覆盖 */
  updateColumnsSequence(dto, _id) {
    try {
      const { sequence } = dto;
      console.log(sequence);
      return this.usersRepository.updateOne(
        { _id },
        { $set: { columnSequence: sequence } }
      );
    } catch (error) {
      throw error;
    }
  }
}
function generateRandomStr(num = 8) {
  const characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let result = "";
  for (let i = 0; i < num; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    result += characters.charAt(randomIndex);
  }
  return result;
}
const userService = new UserService();

export { userService as u };
//# sourceMappingURL=user.service.mjs.map
