import { Types } from 'mongoose';
import mongoosePaginateV2 from 'mongoose-paginate-v2';
import { d as defineMongooseModel } from './model.mjs';

var RemovedEnum = /* @__PURE__ */ ((RemovedEnum2) => {
  RemovedEnum2["NEVER"] = "never";
  RemovedEnum2["ACTIVE"] = "active";
  RemovedEnum2["PASSIVE"] = "passive";
  return RemovedEnum2;
})(RemovedEnum || {});

const Article = defineMongooseModel({
  name: "Article",
  schema: {
    /** 一个较为简短的 ID，用来有限制地查询作品文章 (仅为普通访客查询展示必要的文章信息) */
    UID: {
      type: String,
      require: true
    },
    /** 版号：每个新项目拥有一个唯一的版号（更新稿件没有独立版号） */
    editionId: {
      type: String,
      required: false,
      unique: true
    },
    /** 隶属版号：来自项目的更新稿件会将此字段指向项目版号 */
    fromEditionId: {
      type: String,
      required: false
    },
    /** 用户 ID */
    userId: {
      type: Types.ObjectId,
      required: true,
      ref: "User"
    },
    /** 授权 ID, 指向授权信息 */
    authcodeId: {
      type: Types.ObjectId,
      ref: "Authcode"
    },
    /** 专栏 ID */
    columnId: {
      type: Types.ObjectId,
      ref: "Column"
    },
    /** 是否完成解析 */
    isParsed: {
      type: Boolean,
      required: true,
      default: false
    },
    /** 投稿时携带的消息 */
    msg: {
      type: String,
      default: ""
    },
    /** 编辑器版本号 */
    editorVersion: {
      type: String,
      default: "0.0.0"
    },
    /** 封面 */
    cover: {
      type: String,
      default: ""
    },
    /** 类型 */
    type: {
      type: String,
      required: true,
      enum: ["note", "course", "other"]
    },
    /** 标题 */
    title: {
      type: String,
      required: true
    },
    /** 正文 */
    content: {
      type: String,
      default: ""
    },
    /** 缩略文本 */
    abbrev: {
      type: String,
      default: ""
    },
    /** 音频 */
    audio: {
      type: String,
      default: ""
    },
    /** 启动子序列 */
    promoterSequence: {
      type: [String],
      default: []
    },
    /** 关键帧序列 */
    keyframeSequence: {
      type: [String],
      default: []
    },
    /** 字幕序列 */
    subtitleSequence: {
      type: [String],
      default: []
    },
    /** 字幕关键帧序列 */
    subtitleKeyframeSequence: {
      type: [String],
      default: []
    },
    /** 标签 */
    tags: {
      type: [String],
      default: []
    },
    /** 发布状态 */
    isPublish: {
      type: Boolean,
      require: true,
      default: false
    },
    removed: {
      type: String,
      require: true,
      default: RemovedEnum.NEVER
    },
    /** 作者信息 */
    author: {
      /** 笔名 */
      penname: {
        type: String,
        require: false,
        default: ""
      },
      /** 邮箱 */
      email: {
        type: String,
        require: false,
        default: ""
      },
      /** 个人博客 */
      blog: {
        type: String,
        require: false,
        default: ""
      }
    },
    /** 作品详情 */
    detail: {
      /** 时长 */
      duration: {
        type: Number,
        require: false,
        default: 0
      },
      /** 字数 */
      wordage: {
        type: Number,
        require: false,
        default: 0
      },
      /** 文件大小（主要是项目中包含的音频文件和富文本数据（含图片）的大小） */
      filesize: {
        type: Number,
        require: false,
        default: 0
      }
    },
    meta: {
      // 看过数量
      views: { type: Number, default: 0 },
      // 喜欢数量
      likes: { type: Number, default: 0 },
      // 收藏数量
      collections: { type: Number, default: 0 },
      // 评论数量
      comments: { type: Number, default: 0 }
    },
    // 创建时间
    createAt: {
      type: Date,
      default: /* @__PURE__ */ new Date()
    },
    // 修改时间
    updateAt: {
      type: Date,
      default: /* @__PURE__ */ new Date()
    }
  },
  options: {
    timestamps: true,
    pluginTags: ["paginate"]
  },
  hooks(schema) {
    schema.pre("save", function(next) {
      this.updateAt = /* @__PURE__ */ new Date();
      next();
    });
    schema.plugin(mongoosePaginateV2);
  }
});

const Column = defineMongooseModel({
  name: "Column",
  schema: {
    /** 用户 ID */
    userId: {
      type: Types.ObjectId,
      required: true,
      ref: "User"
    },
    UID: {
      type: String,
      require: true
    },
    name: {
      type: String,
      maxlength: 32,
      default: "",
      require: true
    },
    cover: {
      type: String,
      default: ""
    },
    desc: {
      type: String,
      default: ""
    },
    isPublish: {
      type: Boolean,
      default: false
    },
    removed: {
      type: String,
      require: true,
      default: RemovedEnum.NEVER
    },
    // 创建时间
    createAt: {
      type: Date,
      default: /* @__PURE__ */ new Date()
    },
    // 修改时间
    updateAt: {
      type: Date,
      default: /* @__PURE__ */ new Date()
    }
  },
  options: {
    timestamps: true
  },
  hooks(schema) {
    schema.pre("save", function(next) {
      this.updateAt = /* @__PURE__ */ new Date();
      next();
    });
    schema.plugin(mongoosePaginateV2);
  }
});

export { Article as A, Column as C, RemovedEnum as R };
//# sourceMappingURL=column.schema.mjs.map
