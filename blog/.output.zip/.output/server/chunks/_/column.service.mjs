import { A as Article, C as Column, R as RemovedEnum } from './column.schema.mjs';
import { U as User } from './user.schema.mjs';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
class ColumnService {
  constructor() {
    __publicField(this, "articlesRepository");
    __publicField(this, "columnsRepository");
    __publicField(this, "usersRepository");
    this.articlesRepository = Article;
    this.columnsRepository = Column;
    this.usersRepository = User;
  }
  async create(dto, userId, UID) {
    try {
      const column = await this.columnsRepository.create({
        ...dto,
        userId,
        UID
      });
      await this.usersRepository.updateOne({ _id: userId }, { $push: { columnSequence: { $each: [column._id], $position: 0 } } });
      return column;
    } catch (error) {
      console.log(error);
      throw error;
    }
  }
  async getColumns(userId) {
    try {
      const columns = await this.columnsRepository.find({ userId, removed: RemovedEnum.NEVER });
      return columns;
    } catch (error) {
      throw error;
    }
  }
  async getColumn(columnId, userId) {
    try {
      const articles = await this.articlesRepository.find(
        { columnId, userId, removed: RemovedEnum.NEVER },
        { _id: 1, columnId: 1, editionId: 1, type: 1, title: 1, abbrev: 1, cover: 1, isParsed: 1, isPublish: 1, author: 1, detail: 1 }
      );
      const column = await this.columnsRepository.findById(columnId);
      if (!column) {
        throw new Error("\u4E13\u680F\u4E0D\u5B58\u5728");
      }
      const data = {
        _id: column._id,
        name: column.name,
        isPublish: column.isPublish,
        subfiles: articles.map((article) => {
          return {
            _id: article._id,
            columnId: article.columnId,
            editionId: article.editionId,
            type: article.type,
            title: article.title,
            abbrev: article.abbrev,
            cover: article.cover,
            isParsed: article.isParsed,
            isPublish: article.isPublish,
            author: article.author,
            detail: article.detail
          };
        })
      };
      return data;
    } catch (error) {
      throw error;
    }
  }
  update() {
  }
  remove() {
  }
}
const columnService = new ColumnService();

export { columnService as c };
//# sourceMappingURL=column.service.mjs.map
