import { Types } from 'mongoose';
import mongoosePaginateV2 from 'mongoose-paginate-v2';
import { d as defineMongooseModel } from './model.mjs';

const Authcode = defineMongooseModel({
  name: "Authcode",
  schema: {
    /** 用户 ID */
    userId: {
      type: Types.ObjectId,
      required: true,
      ref: "User"
    },
    name: {
      type: String,
      maxlength: 24,
      require: false,
      default: ""
    },
    code: {
      type: String,
      maxlength: 64,
      require: true,
      unique: true
    },
    /** 禁用状态 */
    disabled: {
      type: Boolean,
      require: true,
      default: false
    },
    desc: {
      type: String,
      maxlength: 128,
      require: false,
      default: ""
    },
    // 创建时间
    createAt: {
      type: Date,
      default: /* @__PURE__ */ new Date()
    },
    // 修改时间
    updateAt: {
      type: Date,
      default: /* @__PURE__ */ new Date()
    }
  },
  options: {
    timestamps: true
  },
  hooks(schema) {
    schema.pre("save", function(next) {
      this.updateAt = /* @__PURE__ */ new Date();
      next();
    }), schema.plugin(mongoosePaginateV2);
  }
});

export { Authcode as A };
//# sourceMappingURL=authcode.schema.mjs.map
