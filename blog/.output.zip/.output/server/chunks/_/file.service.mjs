import path from 'path';
import fs from 'fs';
import randomstring from 'randomstring';
import child_process from 'child_process';
import { u as useRuntimeConfig } from '../runtime.mjs';
import { Types } from 'mongoose';
import { d as defineMongooseModel } from './model.mjs';

const UploadFile = defineMongooseModel({
  name: "UploadFile",
  schema: {
    userId: {
      type: Types.ObjectId,
      require: true
    },
    /** 名称 */
    name: {
      type: String,
      require: true
    },
    /** 文件类型: image, audio */
    type: {
      type: String,
      require: true
    },
    /** 扩展名 */
    extname: {
      type: String,
      require: false
    },
    /** md5 */
    md5: {
      type: String,
      require: true
    },
    /** 文件大小 */
    size: {
      type: Number,
      require: false
    },
    /** 文件路径 */
    path: {
      type: String,
      require: true
    }
  },
  options: {
    timestamps: true
  }
});

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, key + "" , value);
  return value;
};
process.cwd();
const runtimeConfig = useRuntimeConfig();
class FileService {
  constructor() {
    __publicField(this, "filesRepository");
    this.filesRepository = UploadFile;
  }
  getFilePath(args) {
    const { dirname, category, filename } = args;
    const dir = typeof dirname === "string" ? dirname : dirname.join("/");
    const dirPath = path.join(runtimeConfig.staticDir, dir, category);
    return `${dirPath}/${filename}`;
  }
  saveImage(args, userId) {
    const { sourcePath, extname, dirname } = args;
    return new Promise(async (resolve, reject) => {
      const { size, md5 } = await this.calculateFileStats(sourcePath);
      const file = await this.filesRepository.findOne({ md5, size, userId });
      if (file) {
        const isExists = fs.existsSync(file.path);
        if (isExists) {
          console.log("\u7528\u6237\u4E0A\u4F20\u7684\u56FE\u7247\u5DF2\u5B58\u5728\uFF0C\u76F4\u63A5\u8FD4\u56DE\u56FE\u7247\u8DEF\u5F84!");
          resolve(file.path);
          return;
        }
      }
      const extWithoutDot = extname.charAt(0) === "." ? extname.slice(1) : extname;
      const filename = `${randomstring.generate(3)}${(/* @__PURE__ */ new Date()).getTime()}.${extWithoutDot}`;
      const filepath = this.getFilePath({
        dirname,
        filename,
        category: "image"
      });
      console.log(filepath);
      const targetDir = path.dirname(filepath);
      if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
      }
      fs.rename(sourcePath, filepath, (err) => {
        if (err) {
          reject(err);
        } else {
          this.filesRepository.create({
            userId,
            name: filename,
            extname,
            type: "image",
            path: filepath,
            size,
            md5
          });
          resolve(filepath);
        }
      });
    });
  }
  saveAudio(args, userId) {
    const { sourcePath, extname, dirname } = args;
    return new Promise(async (resolve, reject) => {
      const { size, md5 } = await this.calculateFileStats(sourcePath);
      const file = await this.filesRepository.findOne({ md5, size, userId });
      if (file) {
        const isExists = fs.existsSync(file.path);
        if (isExists) {
          console.log("\u7528\u6237\u4E0A\u4F20\u7684\u97F3\u9891\u5DF2\u5B58\u5728\uFF0C\u76F4\u63A5\u8FD4\u56DE\u97F3\u9891\u6587\u4EF6\u8DEF\u5F84!");
          resolve(file.path);
          return;
        }
      }
      const extWithoutDot = extname.charAt(0) === "." ? extname.slice(1) : extname;
      const filename = `${randomstring.generate(3)}${(/* @__PURE__ */ new Date()).getTime()}.${extWithoutDot}`;
      const filepath = this.getFilePath({
        dirname,
        filename,
        category: "audio"
      });
      const targetDir = path.dirname(filepath);
      if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
      }
      fs.rename(sourcePath, filepath, (err) => {
        if (err) {
          reject(err);
        } else {
          this.filesRepository.create({
            userId,
            name: filename,
            extname,
            type: "audio",
            path: filepath,
            size,
            md5
          });
          resolve(filepath);
        }
      });
    });
  }
  async calculateFileStats(filePath) {
    return new Promise((resolve, reject) => {
      const child = child_process.fork("workers/md5-worker.mjs");
      child.send(filePath);
      const timer = setTimeout(() => {
        child.kill();
        clearTimeout(timer);
      }, 1e4);
      child.on("message", (msg) => {
        if (msg.error) {
          console.log("\u8B66\u544A\uFF01\u8BA1\u7B97\u56FE\u7247\u76F8\u5173\u4FE1\u606F\u5931\u8D25\uFF0C\u672A\u80FD\u6210\u529F\u521B\u5EFA\u56FE\u7247\u6570\u636E\u5BF9\u8C61\uFF0C\u56FE\u7247\u5730\u5740:" + filePath);
          reject(msg.error);
        } else {
          resolve(msg);
        }
        clearTimeout(timer);
        child.kill();
      });
      child.on("error", (error) => {
        console.log(error);
        console.log("\u8B66\u544A\uFF01\u8BA1\u7B97\u56FE\u7247\u76F8\u5173\u4FE1\u606F\u5931\u8D25\uFF0C\u672A\u80FD\u6210\u529F\u521B\u5EFA\u56FE\u7247\u6570\u636E\u5BF9\u8C61\uFF0C\u56FE\u7247\u5730\u5740:" + filePath);
        clearTimeout(timer);
        child.kill();
        reject(error);
      });
    });
  }
}
const fileService = new FileService();

export { UploadFile as U, fileService as f };
//# sourceMappingURL=file.service.mjs.map
