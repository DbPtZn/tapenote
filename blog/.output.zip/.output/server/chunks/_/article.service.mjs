import fs from 'fs';
import path from 'path';
import { U as UploadFile, f as fileService } from './file.service.mjs';
import { A as Article, C as Column, R as RemovedEnum } from './column.schema.mjs';
import { A as Authcode } from './authcode.schema.mjs';
import { U as User } from './user.schema.mjs';
import crypto from 'node:crypto';

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
const byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  //
  // Note to future-self: No, you can't remove the `toLowerCase()` call.
  // REF: https://github.com/uuidjs/uuid/pull/677#issuecomment-1757351351
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

const rnds8Pool = new Uint8Array(256); // # of random values to pre-allocate
let poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    crypto.randomFillSync(rnds8Pool);
    poolPtr = 0;
  }
  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}

const native = {
  randomUUID: crypto.randomUUID
};

function v4(options, buf, offset) {
  if (native.randomUUID && !buf && !options) {
    return native.randomUUID();
  }
  options = options || {};
  const rnds = options.random || (options.rng || rng)();

  // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80;
  return unsafeStringify(rnds);
}

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, key + "" , value);
  return value;
};
[
  Article.length,
  Column.length,
  Authcode.length,
  User.length,
  UploadFile.length
];
class ArticleService {
  constructor() {
    __publicField(this, "articlesRepository");
    this.articlesRepository = Article;
  }
  /** 查询文章版本是否存在 */
  queryEditionExists(editionId) {
    return this.articlesRepository.exists({ editionId });
  }
  create(dto, userId, fromEditionId) {
    const { UID, isParsed, editorVersion, authcodeId, penname, email, blog, msg, type, title, abbrev, content, audio } = dto;
    try {
      return this.articlesRepository.create({
        isParsed,
        editionId: !fromEditionId ? v4() : null,
        fromEditionId: fromEditionId ? fromEditionId : null,
        editorVersion,
        authcodeId,
        msg,
        type,
        title,
        abbrev,
        content,
        audio,
        author: {
          penname,
          email,
          blog
        },
        createAt: /* @__PURE__ */ new Date(),
        updateAt: /* @__PURE__ */ new Date(),
        userId,
        UID
      });
    } catch (error) {
    }
  }
  async parse(dto, userId, UID) {
    try {
      const { _id, cover, content, duration, promoterSequence, keyframeSequence, subtitleSequence, subtitleKeyframeSequence } = dto;
      const article = await this.articlesRepository.findById(_id);
      if (!article) {
        throw new Error("\u6587\u7AE0\u4E0D\u5B58\u5728\uFF01");
      }
      let filepath = "";
      if (article.type === "course" && article.audio) {
        filepath = await fileService.saveAudio(
          {
            sourcePath: article.audio,
            extname: path.extname(article.audio),
            dirname: UID
          },
          userId
        );
      }
      const result = await this.articlesRepository.updateOne(
        { _id },
        {
          $set: {
            isParsed: true,
            cover,
            content,
            audio: filepath,
            abbrev: content.replace(/<[^>]+>/g, "").slice(0, 100),
            "detail.duration": duration,
            "detail.wordage": content.replace(/<[^>]+>/g, "").length,
            promoterSequence,
            keyframeSequence,
            subtitleSequence,
            subtitleKeyframeSequence
          }
        }
      );
      return result.acknowledged;
    } catch (error) {
      throw error;
    }
  }
  findOne(_id, userId) {
    return this.articlesRepository.findOne({ _id, userId });
  }
  async find(dto, userId) {
    const { filter, limit, page, sort } = dto;
    const result = await this.articlesRepository.paginate(
      { ...filter, userId },
      {
        projection: {
          _id: 1,
          UID: 1,
          editionId: 1,
          fromEditionId: 1,
          authcodeId: 1,
          columnId: 1,
          isParsed: 1,
          title: 1,
          msg: 1,
          editorVersion: 1,
          type: 1,
          abbrev: 1,
          author: 1,
          createAt: 1,
          updateAt: 1
        },
        populate: ["authcodeId", "columnId"],
        limit: limit || 10,
        page: page || 1,
        sort
      }
    );
    result.docs = result.docs.map((artilce) => {
      const { authcodeId, columnId, ...members } = artilce.toJSON();
      return {
        ...members,
        authcode: artilce.authcodeId,
        authcodeId: authcodeId["_id"],
        column: columnId || null,
        columnId: (columnId == null ? void 0 : columnId["_id"]) || null
      };
    });
    return result;
  }
  async getUnparsedFile(_id) {
    try {
      const article = await this.articlesRepository.findById(_id);
      if (article && !article.isParsed) {
        const filepath = article.content;
        if (fs.existsSync(filepath)) {
          const file = fs.readFileSync(filepath);
          return file;
        } else {
          throw new Error("\u76EE\u6807\u6587\u4EF6\u4E0D\u5B58\u5728\uFF01");
        }
      } else {
        throw new Error("\u76EE\u6807\u9879\u76EE\u4E0D\u5B58\u5728\uFF01");
      }
    } catch (error) {
      throw error;
    }
  }
  async allot(_id, columnId, userId) {
    try {
      const result = await this.articlesRepository.updateOne({ _id, userId }, { $set: { columnId } });
      return result.acknowledged;
    } catch (error) {
      throw error;
    }
  }
  async get(_id) {
    try {
      const article = await this.articlesRepository.findOne(
        { _id, removed: RemovedEnum.NEVER, isParsed: true },
        {
          editionId: 0,
          fromEditionId: 0,
          msg: 0,
          removed: 0
        },
        {
          populate: ["userId"]
        }
      );
      if (!article)
        throw new Error("\u6587\u7AE0\u4E0D\u5B58\u5728\uFF01");
      const { userId, ...meta } = article.toJSON();
      const data = Object.assign({}, meta);
      const user = userId;
      const userinfo = {
        UID: user.UID,
        nickname: user.nickname,
        avatar: user.avatar ? user.avatar.split("public")[1] : ""
      };
      data["user"] = userinfo;
      return data;
    } catch (error) {
      throw error;
    }
  }
  async getAll(UID, limit, page, sort) {
    try {
      const result = await this.articlesRepository.paginate(
        { UID, isParsed: true, removed: RemovedEnum.NEVER },
        {
          projection: {
            _id: 1,
            columnId: 1,
            cover: 1,
            title: 1,
            abbrev: 1,
            detail: 1,
            author: 1,
            meta: 1,
            tags: 1,
            createdAt: 1,
            updatedAt: 1
          },
          populate: ["columnId"],
          limit: limit || 10,
          page: page || 1,
          sort
        }
      );
      result.docs = result.docs.map((artilce) => {
        const { columnId, ...members } = artilce.toJSON();
        return {
          ...members,
          column: columnId || null,
          columnId: (columnId == null ? void 0 : columnId["_id"]) || null
        };
      });
      return result.docs;
    } catch (error) {
      throw error;
    }
  }
}
const articleService = new ArticleService();

export { articleService as a };
//# sourceMappingURL=article.service.mjs.map
