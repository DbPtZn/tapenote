import { d as defineEventHandler, r as readBody, c as createError } from '../../../runtime.mjs';
import { u as userService } from '../../../_/user.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import 'bcryptjs';
import '../../../_/user.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../_/model.mjs';

const updateReceiver = defineEventHandler(async (event) => {
  try {
    const { status } = await readBody(event);
    const result = await userService.updateReceiverConfig(status, event.context.auth.id);
    if (result.acknowledged)
      return { message: "\u63A5\u6536\u6A21\u5F0F\u66F4\u65B0\u6210\u529F\uFF01" };
    else
      throw new Error("\u63A5\u6536\u6A21\u5F0F\u66F4\u65B0\u5931\u8D25\uFF01");
  } catch (error) {
    throw createError({
      statusCode: 400,
      message: "\u63A5\u6536\u6A21\u5F0F\u66F4\u65B0\u5931\u8D25\uFF01"
    });
  }
});

export { updateReceiver as default };
//# sourceMappingURL=updateReceiver.mjs.map
