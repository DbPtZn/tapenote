import { d as defineEventHandler, c as createError } from '../../../runtime.mjs';
import { u as userService } from '../../../_/user.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import 'bcryptjs';
import '../../../_/user.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../_/model.mjs';

const list = defineEventHandler(async (event) => {
  try {
    const users = await userService.findAll();
    console.log(users);
    return users;
  } catch (error) {
    console.error(error);
    throw createError({
      statusCode: 401,
      message: "\u83B7\u53D6\u7528\u6237\u4FE1\u606F\u5931\u8D25\uFF01"
    });
  }
});

export { list as default };
//# sourceMappingURL=list.mjs.map
