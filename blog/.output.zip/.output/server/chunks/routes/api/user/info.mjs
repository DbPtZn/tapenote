import { d as defineEventHandler, c as createError } from '../../../runtime.mjs';
import { u as userService } from '../../../_/user.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import 'bcryptjs';
import '../../../_/user.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../_/model.mjs';

const info = defineEventHandler(async (event) => {
  try {
    if (event.context.auth && event.context.auth.id) {
      const user = await userService.findUserInfo(event.context.auth.id);
      return user;
    } else {
      throw new Error("\u6743\u9650\u4E0D\u8DB3\uFF01");
    }
  } catch (error) {
    console.error(error);
    throw createError({
      statusCode: 401,
      message: "\u83B7\u53D6\u7528\u6237\u4FE1\u606F\u5931\u8D25\uFF01"
    });
  }
});

export { info as default };
//# sourceMappingURL=info.mjs.map
