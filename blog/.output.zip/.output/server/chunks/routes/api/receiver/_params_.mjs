import { d as defineEventHandler, g as getRouterParam, a as getHeader, u as useRuntimeConfig } from '../../../runtime.mjs';
import formidable from 'formidable';
import { u as userService } from '../../../_/user.service.mjs';
import { a as authcodeService } from '../../../_/authcode.service.mjs';
import { a as articleService } from '../../../_/article.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import 'bcryptjs';
import '../../../_/user.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../_/model.mjs';
import '../../../_/authcode.schema.mjs';
import '../../../_/file.service.mjs';
import 'randomstring';
import 'child_process';
import '../../../_/column.schema.mjs';
import 'node:crypto';

const runtimeConfig = useRuntimeConfig();
console.log(runtimeConfig.tempDir);
const _params_ = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n;
  try {
    const params = getRouterParam(event, "params");
    console.log(params);
    if (!params)
      throw new Error("\u7F3A\u5C11 params \u53C2\u6570\uFF01");
    const [account, code] = params.split("&");
    const user = await userService.findOneByAccount(account);
    if (!user)
      throw new Error("\u7528\u6237\u4E0D\u5B58\u5728\uFF01");
    if (user.receiverConfig.status === 2) {
      throw new Error("\u6536\u7A3F\u4EBA\u62D2\u7EDD\u4EFB\u4F55\u6295\u7A3F\uFF01");
    }
    console.log(getHeader(event, "Auth-Code"));
    const authcode = await authcodeService.findOneByCode(code, user._id);
    if (!authcode) {
      throw new Error("\u6388\u6743\u7801\u9A8C\u8BC1\u5931\u8D25\uFF01");
    }
    const form = formidable({
      multiples: true,
      uploadDir: runtimeConfig.tempDir,
      // 指定上传文件存放的目录
      keepExtensions: true,
      // 保持文件的原始扩展名
      maxFileSize: 32 * 1024 * 1024
      // 限制文件大小为 32MB
    });
    form.on("error", (err) => {
      if (err.code === "ENOENT") {
        console.error(err.message);
        event.node.res.statusCode = 400;
        event.node.res.end(err.message || "\u6587\u4EF6\u4E0A\u4F20\u9519\u8BEF");
      }
    });
    form.on("file", (name, file) => {
      console.log("File uploaded:", name);
    });
    const formParse = () => new Promise((resolve, reject) => {
      form.parse(event.node.req, (err, fields2, files2) => {
        if (err) {
          reject(err);
        } else {
          resolve({ fields: fields2, files: files2 });
        }
      });
    });
    const { fields, files } = await formParse();
    if (!((_a = files["jsonDocs"]) == null ? void 0 : _a[0].filepath))
      throw new Error("\u672A\u63D0\u4F9B\u6709\u6548\u6587\u6863\u5185\u5BB9\uFF01");
    const data = {
      isParsed: false,
      editorVersion: "",
      UID: user.UID,
      authcodeId: authcode._id,
      penname: ((_b = fields.penname) == null ? void 0 : _b[0]) || "\u4F5A\u540D",
      email: ((_c = fields.email) == null ? void 0 : _c[0]) || "",
      blog: ((_d = fields.blog) == null ? void 0 : _d[0]) || "",
      msg: ((_e = fields.msg) == null ? void 0 : _e[0]) || "",
      type: ((_f = fields.type) == null ? void 0 : _f[0]) || "other",
      title: ((_g = fields.title) == null ? void 0 : _g[0]) || "",
      abbrev: ((_h = fields.abbrev) == null ? void 0 : _h[0]) || "",
      content: (_i = files["jsonDocs"]) == null ? void 0 : _i[0].filepath,
      audio: ((_j = files["audios"]) == null ? void 0 : _j[0].filepath) || "",
      duration: ((_k = fields.duration) == null ? void 0 : _k[0]) || 0
    };
    let fromEditionId = "";
    if ((_l = fields.editionId) == null ? void 0 : _l[0]) {
      const result = await articleService.queryEditionExists((_m = fields.editionId) == null ? void 0 : _m[0]);
      if (result) {
        fromEditionId = (_n = fields.editionId) == null ? void 0 : _n[0];
      }
    }
    const article = await articleService.create(data, user._id, fromEditionId);
    if (article) {
      console.log("\u6536\u7A3F\u6210\u529F\uFF01");
      return { editionId: article.editionId };
    } else {
      throw new Error("\u6295\u7A3F\u5931\u8D25\uFF0C\u65E0\u6CD5\u521B\u5EFA\u9879\u76EE\uFF01");
    }
  } catch (error) {
    console.log(error);
    event.node.res.statusCode = 400;
    event.node.res.end(error.message);
    return { error: error.message };
  }
});

export { _params_ as default };
//# sourceMappingURL=_params_.mjs.map
