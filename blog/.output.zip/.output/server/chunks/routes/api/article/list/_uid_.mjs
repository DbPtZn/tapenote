import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../../runtime.mjs';
import { a as articleService } from '../../../../_/article.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import '../../../../_/file.service.mjs';
import 'randomstring';
import 'child_process';
import '../../../../_/model.mjs';
import '../../../../_/column.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../../_/authcode.schema.mjs';
import '../../../../_/user.schema.mjs';
import 'node:crypto';

const _uid_ = defineEventHandler(async (event) => {
  try {
    const uid = getRouterParam(event, "uid");
    if (!uid)
      throw new Error("\u672A\u63D0\u4F9B uid \u53C2\u6570\uFF01");
    const data = await articleService.getAll(uid);
    return data;
  } catch (error) {
    console.error(error);
    throw createError({
      statusCode: 400,
      message: "\u83B7\u53D6\u6587\u7AE0\u5217\u8868\u6570\u636E\u5931\u8D25\uFF01"
    });
  }
});

export { _uid_ as default };
//# sourceMappingURL=_uid_.mjs.map
