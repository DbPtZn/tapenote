import { d as defineEventHandler, r as readBody, u as useRuntimeConfig } from '../../../runtime.mjs';
import jwt from 'jsonwebtoken';
import { u as userService } from '../../../_/user.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'serve-static';
import '@iconify/utils';
import 'bcryptjs';
import '../../../_/user.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../_/model.mjs';

const login_post = defineEventHandler(async (event) => {
  const { account, password } = await readBody(event);
  const user = await userService.validateUser(account, password);
  if (!user) {
    return null;
  }
  const runtime = useRuntimeConfig();
  const accessToken = jwt.sign(
    {
      id: user._id,
      account: user.account,
      UID: user.UID
    },
    runtime.jwtSecret,
    { expiresIn: "1d" }
  );
  return accessToken;
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
