import { d as defineEventHandler, r as readBody, c as createError } from '../../../runtime.mjs';
import { u as userService } from '../../../_/user.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import 'bcryptjs';
import '../../../_/user.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../_/model.mjs';

const register_post = defineEventHandler(async (event) => {
  const { nickname, account, password } = await readBody(event);
  console.log(account, password);
  try {
    await userService.create({
      nickname,
      account,
      password
    });
    return {
      msg: "\u6CE8\u518C\u6210\u529F\uFF01"
    };
  } catch (error) {
    console.error(error);
    throw createError({
      message: "\u6CE8\u518C\u5931\u8D25\uFF01"
    });
  }
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
