import { d as defineEventHandler, c as createError, u as useRuntimeConfig } from '../../../runtime.mjs';
import formidable from 'formidable';
import { extname } from 'path';
import { f as fileService } from '../../../_/file.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import 'randomstring';
import 'child_process';
import '../../../_/model.mjs';

const runtimeConfig = useRuntimeConfig();
const img = defineEventHandler(async (event) => {
  try {
    const form = formidable({
      multiples: true,
      uploadDir: runtimeConfig.tempDir,
      // 指定上传文件存放的目录
      keepExtensions: true,
      // 保持文件的原始扩展名
      maxFileSize: 12 * 1024 * 1024
      // 限制文件大小为 12 MB
    });
    form.on("error", (err) => {
      if (err.code === "ENOENT") {
        console.error("File size exceeds the limit");
        throw err;
      }
    });
    const formParse = () => new Promise((resolve, reject) => {
      form.parse(event.node.req, (err, fields, files2) => {
        if (err) {
          reject(err);
        } else {
          resolve({ fields, files: files2 });
        }
      });
    });
    const { files } = await formParse();
    const sourcePath = files.file[0].filepath;
    const path = await fileService.saveImage({
      sourcePath,
      extname: extname(sourcePath),
      dirname: event.context.auth.UID
    }, event.context.auth.id);
    const imgPath = runtimeConfig.staticPrefix + path.split(runtimeConfig.staticDir)[1];
    return imgPath;
  } catch (error) {
    console.error("error");
    console.error(error.message);
    throw createError({
      statusCode: 400,
      message: "\u56FE\u7247\u4E0A\u4F20\u5931\u8D25\uFF01"
    });
  }
});

export { img as default };
//# sourceMappingURL=img.mjs.map
