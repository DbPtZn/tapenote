import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../../../runtime.mjs';
import { Types } from 'mongoose';
import { a as authcodeService } from '../../../../../_/authcode.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import '../../../../../_/authcode.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../../../_/model.mjs';

const _id__delete = defineEventHandler(async (event) => {
  try {
    const id = getRouterParam(event, "id");
    console.log(id);
    await authcodeService.delete(new Types.ObjectId(id), event.context.auth.id);
    return {
      statusCode: 200,
      message: "\u5220\u9664\u6388\u6743\u7801\u6210\u529F\uFF01"
    };
  } catch (error) {
    console.error(error);
    throw createError({
      message: "\u5220\u9664\u6388\u6743\u7801\u5931\u8D25\uFF01"
    });
  }
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
