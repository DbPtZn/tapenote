import { d as defineEventHandler, r as readBody, c as createError } from '../../../../runtime.mjs';
import { c as columnService } from '../../../../_/column.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import '../../../../_/column.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../../_/model.mjs';
import '../../../../_/user.schema.mjs';

const create = defineEventHandler(async (event) => {
  try {
    const dto = await readBody(event);
    const result = await columnService.create(dto, event.context.auth.id, event.context.auth.UID);
    return result;
  } catch (error) {
    console.error(error);
    throw createError({
      statusCode: 400,
      message: "\u521B\u5EFA\u4E13\u680F\u5931\u8D25\uFF01"
    });
  }
});

export { create as default };
//# sourceMappingURL=create.mjs.map
