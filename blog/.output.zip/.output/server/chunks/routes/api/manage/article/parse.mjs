import { d as defineEventHandler, r as readBody, c as createError } from '../../../../runtime.mjs';
import { a as articleService } from '../../../../_/article.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import '../../../../_/file.service.mjs';
import 'randomstring';
import 'child_process';
import '../../../../_/model.mjs';
import '../../../../_/column.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../../_/authcode.schema.mjs';
import '../../../../_/user.schema.mjs';
import 'node:crypto';

const parse = defineEventHandler(async (event) => {
  try {
    console.log("parse");
    const dto = await readBody(event);
    const result = await articleService.parse(dto, event.context.auth.id, event.context.auth.UID);
    return {
      statusCode: 200,
      message: "\u89E3\u6790\u9879\u76EE\u6210\u529F!",
      data: result
    };
  } catch (error) {
    throw createError({
      statusCode: 400,
      message: "\u89E3\u6790\u9879\u76EE\u5931\u8D25!"
    });
  }
});

export { parse as default };
//# sourceMappingURL=parse.mjs.map
