import { d as defineEventHandler, r as readBody, c as createError } from '../../../../runtime.mjs';
import { a as authcodeService } from '../../../../_/authcode.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import '../../../../_/authcode.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../../_/model.mjs';

const update = defineEventHandler(async (event) => {
  try {
    const dto = await readBody(event);
    const authcode = await authcodeService.update(dto, event.context.auth.id);
    return authcode;
  } catch (error) {
    console.error(error);
    throw createError({
      statusCode: 400,
      message: "\u6DFB\u52A0\u6388\u6743\u7801\u5931\u8D25\uFF01"
    });
  }
});

export { update as default };
//# sourceMappingURL=update.mjs.map
