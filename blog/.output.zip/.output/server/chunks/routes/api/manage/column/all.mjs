import { d as defineEventHandler, c as createError } from '../../../../runtime.mjs';
import { c as columnService } from '../../../../_/column.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import '../../../../_/column.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../../_/model.mjs';
import '../../../../_/user.schema.mjs';

const all = defineEventHandler(async (event) => {
  try {
    const result = await columnService.getColumns(event.context.auth.id);
    return result;
  } catch (error) {
    console.error(error);
    throw createError({
      statusCode: 400,
      message: "\u83B7\u53D6\u4E13\u680F\u6570\u636E\u5931\u8D25\uFF01"
    });
  }
});

export { all as default };
//# sourceMappingURL=all.mjs.map
