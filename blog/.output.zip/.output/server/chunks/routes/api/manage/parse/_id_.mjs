import { d as defineEventHandler, g as getRouterParam, c as createError } from '../../../../runtime.mjs';
import { a as articleService } from '../../../../_/article.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import '../../../../_/file.service.mjs';
import 'randomstring';
import 'child_process';
import '../../../../_/model.mjs';
import '../../../../_/column.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../../_/authcode.schema.mjs';
import '../../../../_/user.schema.mjs';
import 'node:crypto';

const _id_ = defineEventHandler(async (event) => {
  try {
    const id = getRouterParam(event, "id");
    if (!id)
      throw new Error("\u672A\u63D0\u4F9B\u6709\u6548 id \u53C2\u6570");
    const file = await articleService.getUnparsedFile(id);
    return file;
  } catch (error) {
    console.error(error);
    throw createError({
      message: "\u83B7\u53D6\u672A\u89E3\u6790\u6587\u6863\u6570\u636E\u5931\u8D25\uFF01"
    });
  }
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
