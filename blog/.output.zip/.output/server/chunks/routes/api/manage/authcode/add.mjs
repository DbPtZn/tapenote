import { d as defineEventHandler, c as createError } from '../../../../runtime.mjs';
import { a as authcodeService } from '../../../../_/authcode.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import '../../../../_/authcode.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../../_/model.mjs';

const add = defineEventHandler(async (event) => {
  try {
    const authcode = await authcodeService.add(event.context.auth.id);
    return authcode;
  } catch (error) {
    throw createError({
      statusCode: 400,
      message: "\u6DFB\u52A0\u6388\u6743\u7801\u5931\u8D25, \u5B58\u5728\u672A\u8BBE\u7F6E\u6388\u6743\u7801\u7684\u9879\u76EE!"
    });
  }
});

export { add as default };
//# sourceMappingURL=add.mjs.map
