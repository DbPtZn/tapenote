import { d as defineEventHandler, r as readBody, c as createError } from '../../../../runtime.mjs';
import { a as articleService } from '../../../../_/article.service.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'consola/core';
import 'mongoose';
import 'node:fs';
import 'node:url';
import 'jsonwebtoken';
import 'serve-static';
import '@iconify/utils';
import '../../../../_/file.service.mjs';
import 'randomstring';
import 'child_process';
import '../../../../_/model.mjs';
import '../../../../_/column.schema.mjs';
import 'mongoose-paginate-v2';
import '../../../../_/authcode.schema.mjs';
import '../../../../_/user.schema.mjs';
import 'node:crypto';

const allot = defineEventHandler(async (event) => {
  try {
    console.log("allot");
    const dto = await readBody(event);
    const { articleId, columnId } = dto;
    const result = await articleService.allot(articleId, columnId, event.context.auth.id);
    return {
      statusCode: 200,
      message: "\u5206\u914D\u9879\u76EE\u6210\u529F!",
      data: result
    };
  } catch (error) {
    throw createError({
      statusCode: 400,
      message: "\u5206\u914D\u9879\u76EE\u5931\u8D25!"
    });
  }
});

export { allot as default };
//# sourceMappingURL=allot.mjs.map
