import{_ as e}from"./DlAUqK2U.js";import{A as t,z as r}from"./Dw-eJYB0.js";const c={};function o(n,a){return r(),t("div",null," tags ")}const f=e(c,[["render",o]]);export{f as default};
