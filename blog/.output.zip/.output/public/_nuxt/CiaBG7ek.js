import{p as i,h as a}from"./Dw-eJYB0.js";function p(u,e){return i(u,r=>{r!==void 0&&(e.value=r)}),a(()=>u.value===void 0?e.value:u.value)}export{p as u};
