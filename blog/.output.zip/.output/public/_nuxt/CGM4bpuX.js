import{aO as o}from"./Dw-eJYB0.js";const p=o("/logo.png");export{p as _};
