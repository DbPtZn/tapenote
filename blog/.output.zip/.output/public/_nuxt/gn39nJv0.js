const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./C6sUMVAr.js","./BmdUO_FW.js","./CCOuVzoT.js","./Bof1u0Bp.js","./D0995R5s.js","./xE-q8oSL.js","./BDA7js-N.js","./D-yaZmbF.js","./CZmh-_H_.js","./CbzlE-UY.js","./DtWIJEEX.js","./FLc-EezL.js","./iVmpCJtO.js","./BMQOZHC_.js","./jnXzesTB.js","./B-p6aW7q.js","./DZtetp8p.js","./Boq91Qev.js","./DuiJ8gfA.js","./m39PvhF6.js","./BAywZTNm.js","./Bk_rJcZu.js","./DtnLHOdI.js","./CgNPm_vq.js","./DbVKYhpJ.js","./C0EI-Vu-.js","./CgTfj5pB.js","./CV5z6qGq.js","./kaYnUS7i.js","./hqJfMenR.js","./DL2Kioqa.js","./D8UazF6_.js","./C4qrVBgM.js","./DFYbxKrY.js","./BYev3GBo.js","./DHchU6Tm.js","./OZOYL9g9.js","./DGw8h4Qk.js","./CWbq_njo.js","./CV0NmQdN.js","./Cwrhy0vR.js","./DMQ2ZO9U.js","./DJYPfbMN.js"])))=>i.map(i=>d[i]);
import{Q as Pe,s as n,a as L,R as D,b as i,f as Z,u as ce,r as _,w as Te,p as pe,S as ae,h as F,j as Q,o as ye,n as Be,l as we,T as Ee,U as _e,V as Me,q as Ie,W as Qe,X as He,g as xe,Y as et,Z as ie,_ as oe,$ as ge,a0 as de,e as N,a1 as q,a2 as tt,c as ot,t as rt,v as Le,x as u,a3 as Oe,N as nt,O as Ne,a4 as st,a5 as Fe,z as X,A as G,B as h,D as g,E as j,C as K,a6 as te,L as De,M as je,a7 as it,P as Ae,H as be,I as ke,J as at,G as $e,F as ve,a8 as lt}from"./BmdUO_FW.js";import{_ as ct}from"./C9xch5eQ.js";import Ue from"./QDJhiwxt.js";import{M as dt,_ as ut}from"./CZ0UZIp1.js";import{f as Ve}from"./D0995R5s.js";import{u as We}from"./CV0NmQdN.js";import{_ as Ye}from"./vUYyxuAu.js";import{_ as qe}from"./DlAUqK2U.js";import{d as ze}from"./Bof1u0Bp.js";import{u as ht}from"./Dbm6lC8K.js";import{u as mt}from"./Cwrhy0vR.js";import{u as le}from"./BAywZTNm.js";import{f as W}from"./B-p6aW7q.js";import{m as ft}from"./jnXzesTB.js";import{N as bt,E as vt}from"./DbVKYhpJ.js";import{f as pt,L as Xe,d as Se,c as gt,a as yt,p as wt,m as _t,z as xt}from"./CbzlE-UY.js";import{l as St,u as Ct,a as kt}from"./S3Nd5eyr.js";import{c as $t,d as zt}from"./DL2Kioqa.js";import{S as Ke,f as Rt}from"./DtWIJEEX.js";import{F as Pt}from"./m39PvhF6.js";import{e as Tt}from"./DsSU6HIH.js";import{_ as Bt}from"./D8DKs5GO.js";import{N as Et}from"./DJYPfbMN.js";import"./FLc-EezL.js";import"./D8UazF6_.js";import"./C4qrVBgM.js";import"./DuiJ8gfA.js";import"./Bk_rJcZu.js";function Mt(e){return e.nodeType===9?null:e.parentNode}function Ge(e){if(e===null)return null;const t=Mt(e);if(t===null)return null;if(t.nodeType===9)return document.documentElement;if(t.nodeType===1){const{overflow:o,overflowX:f,overflowY:s}=getComputedStyle(t);if(/(auto|scroll|overlay)/.test(o+s+f))return t}return Ge(t)}function It(e){return typeof e=="string"?document.querySelector(e):typeof e=="function"?e():e}function Re(e){return e.nodeName==="#document"}function Ht(e){const{popoverColor:t,textColor2:o,primaryColorHover:f,primaryColorPressed:s}=e;return Object.assign(Object.assign({},$t),{color:t,textColor:o,iconColor:o,iconColorHover:f,iconColorPressed:s,boxShadow:"0 2px 8px 0px rgba(0, 0, 0, .12)",boxShadowHover:"0 2px 12px 0px rgba(0, 0, 0, .18)",boxShadowPressed:"0 2px 12px 0px rgba(0, 0, 0, .18)"})}const Lt={name:"BackTop",common:Pe,self:Ht},Ot=n("svg",{viewBox:"0 0 24 24",version:"1.1",xmlns:"http://www.w3.org/2000/svg",xlinkHref:"http://www.w3.org/1999/xlink"},n("g",{stroke:"none","stroke-width":"1","fill-rule":"evenodd"},n("g",{transform:"translate(-139.000000, -4423.000000)","fill-rule":"nonzero"},n("g",{transform:"translate(120.000000, 4285.000000)"},n("g",{transform:"translate(7.000000, 126.000000)"},n("g",{transform:"translate(24.000000, 24.000000) scale(1, -1) translate(-24.000000, -24.000000) translate(12.000000, 12.000000)"},n("g",{transform:"translate(4.000000, 2.000000)"},n("path",{d:"M8,0 C8.51283584,0 8.93550716,0.38604019 8.99327227,0.883378875 L9,1 L9,10.584 L12.2928932,7.29289322 C12.6834175,6.90236893 13.3165825,6.90236893 13.7071068,7.29289322 C14.0675907,7.65337718 14.0953203,8.22060824 13.7902954,8.61289944 L13.7071068,8.70710678 L8.70710678,13.7071068 L8.62544899,13.7803112 L8.618,13.784 L8.59530661,13.8036654 L8.4840621,13.8753288 L8.37133602,13.9287745 L8.22929083,13.9735893 L8.14346259,13.9897165 L8.03324678,13.9994506 L7.9137692,13.9962979 L7.77070917,13.9735893 L7.6583843,13.9401293 L7.57677845,13.9063266 L7.47929125,13.8540045 L7.4048407,13.8036865 L7.38131006,13.7856883 C7.35030318,13.7612383 7.32077858,13.7349921 7.29289322,13.7071068 L2.29289322,8.70710678 L2.20970461,8.61289944 C1.90467972,8.22060824 1.93240926,7.65337718 2.29289322,7.29289322 C2.65337718,6.93240926 3.22060824,6.90467972 3.61289944,7.20970461 L3.70710678,7.29289322 L7,10.585 L7,1 L7.00672773,0.883378875 C7.06449284,0.38604019 7.48716416,0 8,0 Z"}),n("path",{d:"M14.9333333,15.9994506 C15.5224371,15.9994506 16,16.4471659 16,16.9994506 C16,17.5122865 15.5882238,17.9349578 15.0577292,17.9927229 L14.9333333,17.9994506 L1.06666667,17.9994506 C0.477562934,17.9994506 0,17.5517354 0,16.9994506 C0,16.4866148 0.411776203,16.0639435 0.9422708,16.0061783 L1.06666667,15.9994506 L14.9333333,15.9994506 Z"})))))))),Nt=L("back-top",`
 position: fixed;
 right: 40px;
 bottom: 40px;
 cursor: pointer;
 display: flex;
 align-items: center;
 justify-content: center;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 height: var(--n-height);
 min-width: var(--n-width);
 box-shadow: var(--n-box-shadow);
 background-color: var(--n-color);
`,[pt(),D("transition-disabled",{transition:"none !important"}),L("base-icon",`
 font-size: var(--n-icon-size);
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),i("svg",{pointerEvents:"none"}),i("&:hover",{boxShadow:"var(--n-box-shadow-hover)"},[L("base-icon",{color:"var(--n-icon-color-hover)"})]),i("&:active",{boxShadow:"var(--n-box-shadow-pressed)"},[L("base-icon",{color:"var(--n-icon-color-pressed)"})])]),Ft=Object.assign(Object.assign({},Q.props),{show:{type:Boolean,default:void 0},right:{type:[Number,String],default:40},bottom:{type:[Number,String],default:40},to:{type:[String,Object],default:"body"},visibilityHeight:{type:Number,default:180},listenTo:[String,Object,Function],"onUpdate:show":{type:Function,default:()=>{}},target:Function,onShow:Function,onHide:Function}),Dt=Z({name:"BackTop",inheritAttrs:!1,props:Ft,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:o}=ce(e),f=_(null),s=_(!1);Te(()=>{const{value:C}=f;if(C===null){s.value=!1;return}s.value=C>=e.visibilityHeight});const b=_(!1);pe(s,C=>{var w;b.value&&((w=e["onUpdate:show"])===null||w===void 0||w.call(e,C))});const y=ae(e,"show"),p=le(y,s),d=_(!0),$=_(null),E=F(()=>({right:`calc(${W(e.right)} + ${St.value})`,bottom:W(e.bottom)}));let l,a;pe(p,C=>{var w,r;b.value&&(C&&((w=e.onShow)===null||w===void 0||w.call(e)),(r=e.onHide)===null||r===void 0||r.call(e))});const S=Q("BackTop","-back-top",Nt,Lt,e,t);function z(){var C;if(a)return;a=!0;const w=((C=e.target)===null||C===void 0?void 0:C.call(e))||It(e.listenTo)||Ge($.value);if(!w)return;l=w===document.documentElement?document:w;const{to:r}=e;typeof r=="string"&&document.querySelector(r),l.addEventListener("scroll",k),k()}function m(){(Re(l)?document.documentElement:l).scrollTo({top:0,behavior:"smooth"})}function k(){f.value=(Re(l)?document.documentElement:l).scrollTop,b.value||Qe(()=>{b.value=!0})}function O(){d.value=!1}ye(()=>{z(),d.value=p.value}),Be(()=>{l&&l.removeEventListener("scroll",k)});const B=F(()=>{const{self:{color:C,boxShadow:w,boxShadowHover:r,boxShadowPressed:v,iconColor:T,iconColorHover:c,iconColorPressed:R,width:P,height:I,iconSize:H,borderRadius:x,textColor:U},common:{cubicBezierEaseInOut:Y}}=S.value;return{"--n-bezier":Y,"--n-border-radius":x,"--n-height":I,"--n-width":P,"--n-box-shadow":w,"--n-box-shadow-hover":r,"--n-box-shadow-pressed":v,"--n-color":C,"--n-icon-size":H,"--n-icon-color":T,"--n-icon-color-hover":c,"--n-icon-color-pressed":R,"--n-text-color":U}}),M=o?we("back-top",void 0,B,e):void 0;return{placeholderRef:$,style:E,mergedShow:p,isMounted:Ee(),scrollElement:_(null),scrollTop:f,DomInfoReady:b,transitionDisabled:d,mergedClsPrefix:t,handleAfterEnter:O,handleScroll:k,handleClick:m,cssVars:o?void 0:B,themeClass:M==null?void 0:M.themeClass,onRender:M==null?void 0:M.onRender}},render(){const{mergedClsPrefix:e}=this;return n("div",{ref:"placeholderRef",class:`${e}-back-top-placeholder`,style:"display: none","aria-hidden":!0},n(Xe,{to:this.to,show:this.mergedShow},{default:()=>n(_e,{name:"fade-in-scale-up-transition",appear:this.isMounted,onAfterEnter:this.handleAfterEnter},{default:()=>{var t;return(t=this.onRender)===null||t===void 0||t.call(this),this.mergedShow?n("div",Me(this.$attrs,{class:[`${e}-back-top`,this.themeClass,this.transitionDisabled&&`${e}-back-top--transition-disabled`],style:[this.style,this.cssVars],onClick:this.handleClick}),Ie(this.$slots.default,()=>[n(He,{clsPrefix:e},{default:()=>Ot})])):null}})}))}}),jt=Z({name:"NDrawerContent",inheritAttrs:!1,props:{blockScroll:Boolean,show:{type:Boolean,default:void 0},displayDirective:{type:String,required:!0},placement:{type:String,required:!0},contentClass:String,contentStyle:[Object,String],nativeScrollbar:{type:Boolean,required:!0},scrollbarProps:Object,trapFocus:{type:Boolean,default:!0},autoFocus:{type:Boolean,default:!0},showMask:{type:[Boolean,String],required:!0},maxWidth:Number,maxHeight:Number,minWidth:Number,minHeight:Number,resizable:Boolean,onClickoutside:Function,onAfterLeave:Function,onAfterEnter:Function,onEsc:Function},setup(e){const t=_(!!e.show),o=_(null),f=xe(Se);let s=0,b="",y=null;const p=_(!1),d=_(!1),$=F(()=>e.placement==="top"||e.placement==="bottom"),{mergedClsPrefixRef:E,mergedRtlRef:l}=ce(e),a=et("Drawer",l,E),S=r,z=c=>{d.value=!0,s=$.value?c.clientY:c.clientX,b=document.body.style.cursor,document.body.style.cursor=$.value?"ns-resize":"ew-resize",document.body.addEventListener("mousemove",w),document.body.addEventListener("mouseleave",S),document.body.addEventListener("mouseup",r)},m=()=>{y!==null&&(window.clearTimeout(y),y=null),d.value?p.value=!0:y=window.setTimeout(()=>{p.value=!0},300)},k=()=>{y!==null&&(window.clearTimeout(y),y=null),p.value=!1},{doUpdateHeight:O,doUpdateWidth:B}=f,M=c=>{const{maxWidth:R}=e;if(R&&c>R)return R;const{minWidth:P}=e;return P&&c<P?P:c},C=c=>{const{maxHeight:R}=e;if(R&&c>R)return R;const{minHeight:P}=e;return P&&c<P?P:c};function w(c){var R,P;if(d.value)if($.value){let I=((R=o.value)===null||R===void 0?void 0:R.offsetHeight)||0;const H=s-c.clientY;I+=e.placement==="bottom"?H:-H,I=C(I),O(I),s=c.clientY}else{let I=((P=o.value)===null||P===void 0?void 0:P.offsetWidth)||0;const H=s-c.clientX;I+=e.placement==="right"?H:-H,I=M(I),B(I),s=c.clientX}}function r(){d.value&&(s=0,d.value=!1,document.body.style.cursor=b,document.body.removeEventListener("mousemove",w),document.body.removeEventListener("mouseup",r),document.body.removeEventListener("mouseleave",S))}Te(()=>{e.show&&(t.value=!0)}),pe(()=>e.show,c=>{c||r()}),Be(()=>{r()});const v=F(()=>{const{show:c}=e,R=[[ge,c]];return e.showMask||R.push([gt,e.onClickoutside,void 0,{capture:!0}]),R});function T(){var c;t.value=!1,(c=e.onAfterLeave)===null||c===void 0||c.call(e)}return Ct(F(()=>e.blockScroll&&t.value)),ie(yt,o),ie(wt,null),ie(_t,null),{bodyRef:o,rtlEnabled:a,mergedClsPrefix:f.mergedClsPrefixRef,isMounted:f.isMountedRef,mergedTheme:f.mergedThemeRef,displayed:t,transitionName:F(()=>({right:"slide-in-from-right-transition",left:"slide-in-from-left-transition",top:"slide-in-from-top-transition",bottom:"slide-in-from-bottom-transition"})[e.placement]),handleAfterLeave:T,bodyDirectives:v,handleMousedownResizeTrigger:z,handleMouseenterResizeTrigger:m,handleMouseleaveResizeTrigger:k,isDragging:d,isHoverOnResizeTrigger:p}},render(){const{$slots:e,mergedClsPrefix:t}=this;return this.displayDirective==="show"||this.displayed||this.show?oe(n("div",{role:"none"},n(Pt,{disabled:!this.showMask||!this.trapFocus,active:this.show,autoFocus:this.autoFocus,onEsc:this.onEsc},{default:()=>n(_e,{name:this.transitionName,appear:this.isMounted,onAfterEnter:this.onAfterEnter,onAfterLeave:this.handleAfterLeave},{default:()=>oe(n("div",Me(this.$attrs,{role:"dialog",ref:"bodyRef","aria-modal":"true",class:[`${t}-drawer`,this.rtlEnabled&&`${t}-drawer--rtl`,`${t}-drawer--${this.placement}-placement`,this.isDragging&&`${t}-drawer--unselectable`,this.nativeScrollbar&&`${t}-drawer--native-scrollbar`]}),[this.resizable?n("div",{class:[`${t}-drawer__resize-trigger`,(this.isDragging||this.isHoverOnResizeTrigger)&&`${t}-drawer__resize-trigger--hover`],onMouseenter:this.handleMouseenterResizeTrigger,onMouseleave:this.handleMouseleaveResizeTrigger,onMousedown:this.handleMousedownResizeTrigger}):null,this.nativeScrollbar?n("div",{class:[`${t}-drawer-content-wrapper`,this.contentClass],style:this.contentStyle,role:"none"},e):n(Ke,Object.assign({},this.scrollbarProps,{contentStyle:this.contentStyle,contentClass:[`${t}-drawer-content-wrapper`,this.contentClass],theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar}),e)]),this.bodyDirectives)})})),[[ge,this.displayDirective==="if"||this.displayed||this.show]]):null}}),{cubicBezierEaseIn:At,cubicBezierEaseOut:Ut}=de;function Vt({duration:e="0.3s",leaveDuration:t="0.2s",name:o="slide-in-from-right"}={}){return[i(`&.${o}-transition-leave-active`,{transition:`transform ${t} ${At}`}),i(`&.${o}-transition-enter-active`,{transition:`transform ${e} ${Ut}`}),i(`&.${o}-transition-enter-to`,{transform:"translateX(0)"}),i(`&.${o}-transition-enter-from`,{transform:"translateX(100%)"}),i(`&.${o}-transition-leave-from`,{transform:"translateX(0)"}),i(`&.${o}-transition-leave-to`,{transform:"translateX(100%)"})]}const{cubicBezierEaseIn:Wt,cubicBezierEaseOut:Yt}=de;function qt({duration:e="0.3s",leaveDuration:t="0.2s",name:o="slide-in-from-left"}={}){return[i(`&.${o}-transition-leave-active`,{transition:`transform ${t} ${Wt}`}),i(`&.${o}-transition-enter-active`,{transition:`transform ${e} ${Yt}`}),i(`&.${o}-transition-enter-to`,{transform:"translateX(0)"}),i(`&.${o}-transition-enter-from`,{transform:"translateX(-100%)"}),i(`&.${o}-transition-leave-from`,{transform:"translateX(0)"}),i(`&.${o}-transition-leave-to`,{transform:"translateX(-100%)"})]}const{cubicBezierEaseIn:Xt,cubicBezierEaseOut:Kt}=de;function Gt({duration:e="0.3s",leaveDuration:t="0.2s",name:o="slide-in-from-top"}={}){return[i(`&.${o}-transition-leave-active`,{transition:`transform ${t} ${Xt}`}),i(`&.${o}-transition-enter-active`,{transition:`transform ${e} ${Kt}`}),i(`&.${o}-transition-enter-to`,{transform:"translateY(0)"}),i(`&.${o}-transition-enter-from`,{transform:"translateY(-100%)"}),i(`&.${o}-transition-leave-from`,{transform:"translateY(0)"}),i(`&.${o}-transition-leave-to`,{transform:"translateY(-100%)"})]}const{cubicBezierEaseIn:Zt,cubicBezierEaseOut:Jt}=de;function Qt({duration:e="0.3s",leaveDuration:t="0.2s",name:o="slide-in-from-bottom"}={}){return[i(`&.${o}-transition-leave-active`,{transition:`transform ${t} ${Zt}`}),i(`&.${o}-transition-enter-active`,{transition:`transform ${e} ${Jt}`}),i(`&.${o}-transition-enter-to`,{transform:"translateY(0)"}),i(`&.${o}-transition-enter-from`,{transform:"translateY(100%)"}),i(`&.${o}-transition-leave-from`,{transform:"translateY(0)"}),i(`&.${o}-transition-leave-to`,{transform:"translateY(100%)"})]}const eo=i([L("drawer",`
 word-break: break-word;
 line-height: var(--n-line-height);
 position: absolute;
 pointer-events: all;
 box-shadow: var(--n-box-shadow);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 background-color: var(--n-color);
 color: var(--n-text-color);
 box-sizing: border-box;
 `,[Vt(),qt(),Gt(),Qt(),D("unselectable",`
 user-select: none; 
 -webkit-user-select: none;
 `),D("native-scrollbar",[L("drawer-content-wrapper",`
 overflow: auto;
 height: 100%;
 `)]),N("resize-trigger",`
 position: absolute;
 background-color: #0000;
 transition: background-color .3s var(--n-bezier);
 `,[D("hover",`
 background-color: var(--n-resize-trigger-color-hover);
 `)]),L("drawer-content-wrapper",`
 box-sizing: border-box;
 `),L("drawer-content",`
 height: 100%;
 display: flex;
 flex-direction: column;
 `,[D("native-scrollbar",[L("drawer-body-content-wrapper",`
 height: 100%;
 overflow: auto;
 `)]),L("drawer-body",`
 flex: 1 0 0;
 overflow: hidden;
 `),L("drawer-body-content-wrapper",`
 box-sizing: border-box;
 padding: var(--n-body-padding);
 `),L("drawer-header",`
 font-weight: var(--n-title-font-weight);
 line-height: 1;
 font-size: var(--n-title-font-size);
 color: var(--n-title-text-color);
 padding: var(--n-header-padding);
 transition: border .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-divider-color);
 border-bottom: var(--n-header-border-bottom);
 display: flex;
 justify-content: space-between;
 align-items: center;
 `,[N("close",`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `)]),L("drawer-footer",`
 display: flex;
 justify-content: flex-end;
 border-top: var(--n-footer-border-top);
 transition: border .3s var(--n-bezier);
 padding: var(--n-footer-padding);
 `)]),D("right-placement",`
 top: 0;
 bottom: 0;
 right: 0;
 border-top-left-radius: var(--n-border-radius);
 border-bottom-left-radius: var(--n-border-radius);
 `,[N("resize-trigger",`
 width: 3px;
 height: 100%;
 top: 0;
 left: 0;
 transform: translateX(-1.5px);
 cursor: ew-resize;
 `)]),D("left-placement",`
 top: 0;
 bottom: 0;
 left: 0;
 border-top-right-radius: var(--n-border-radius);
 border-bottom-right-radius: var(--n-border-radius);
 `,[N("resize-trigger",`
 width: 3px;
 height: 100%;
 top: 0;
 right: 0;
 transform: translateX(1.5px);
 cursor: ew-resize;
 `)]),D("top-placement",`
 top: 0;
 left: 0;
 right: 0;
 border-bottom-left-radius: var(--n-border-radius);
 border-bottom-right-radius: var(--n-border-radius);
 `,[N("resize-trigger",`
 width: 100%;
 height: 3px;
 bottom: 0;
 left: 0;
 transform: translateY(1.5px);
 cursor: ns-resize;
 `)]),D("bottom-placement",`
 left: 0;
 bottom: 0;
 right: 0;
 border-top-left-radius: var(--n-border-radius);
 border-top-right-radius: var(--n-border-radius);
 `,[N("resize-trigger",`
 width: 100%;
 height: 3px;
 top: 0;
 left: 0;
 transform: translateY(-1.5px);
 cursor: ns-resize;
 `)])]),i("body",[i(">",[L("drawer-container",`
 position: fixed;
 `)])]),L("drawer-container",`
 position: relative;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 `,[i("> *",`
 pointer-events: all;
 `)]),L("drawer-mask",`
 background-color: rgba(0, 0, 0, .3);
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `,[D("invisible",`
 background-color: rgba(0, 0, 0, 0)
 `),Rt({enterDuration:"0.2s",leaveDuration:"0.2s",enterCubicBezier:"var(--n-bezier-in)",leaveCubicBezier:"var(--n-bezier-out)"})])]),to=Object.assign(Object.assign({},Q.props),{show:Boolean,width:[Number,String],height:[Number,String],placement:{type:String,default:"right"},maskClosable:{type:Boolean,default:!0},showMask:{type:[Boolean,String],default:!0},to:[String,Object],displayDirective:{type:String,default:"if"},nativeScrollbar:{type:Boolean,default:!0},zIndex:Number,onMaskClick:Function,scrollbarProps:Object,contentClass:String,contentStyle:[Object,String],trapFocus:{type:Boolean,default:!0},onEsc:Function,autoFocus:{type:Boolean,default:!0},closeOnEsc:{type:Boolean,default:!0},blockScroll:{type:Boolean,default:!0},maxWidth:Number,maxHeight:Number,minWidth:Number,minHeight:Number,resizable:Boolean,defaultWidth:{type:[Number,String],default:251},defaultHeight:{type:[Number,String],default:251},onUpdateWidth:[Function,Array],onUpdateHeight:[Function,Array],"onUpdate:width":[Function,Array],"onUpdate:height":[Function,Array],"onUpdate:show":[Function,Array],onUpdateShow:[Function,Array],onAfterEnter:Function,onAfterLeave:Function,drawerStyle:[String,Object],drawerClass:String,target:null,onShow:Function,onHide:Function}),oo=Z({name:"Drawer",inheritAttrs:!1,props:to,setup(e){const{mergedClsPrefixRef:t,namespaceRef:o,inlineThemeDisabled:f}=ce(e),s=Ee(),b=Q("Drawer","-drawer",eo,zt,e,t),y=_(e.defaultWidth),p=_(e.defaultHeight),d=le(ae(e,"width"),y),$=le(ae(e,"height"),p),E=F(()=>{const{placement:r}=e;return r==="top"||r==="bottom"?"":W(d.value)}),l=F(()=>{const{placement:r}=e;return r==="left"||r==="right"?"":W($.value)}),a=r=>{const{onUpdateWidth:v,"onUpdate:width":T}=e;v&&q(v,r),T&&q(T,r),y.value=r},S=r=>{const{onUpdateHeight:v,"onUpdate:width":T}=e;v&&q(v,r),T&&q(T,r),p.value=r},z=F(()=>[{width:E.value,height:l.value},e.drawerStyle||""]);function m(r){const{onMaskClick:v,maskClosable:T}=e;T&&M(!1),v&&v(r)}function k(r){m(r)}const O=kt();function B(r){var v;(v=e.onEsc)===null||v===void 0||v.call(e),e.show&&e.closeOnEsc&&Tt(r)&&(O.value||M(!1))}function M(r){const{onHide:v,onUpdateShow:T,"onUpdate:show":c}=e;T&&q(T,r),c&&q(c,r),v&&!r&&q(v,r)}ie(Se,{isMountedRef:s,mergedThemeRef:b,mergedClsPrefixRef:t,doUpdateShow:M,doUpdateHeight:S,doUpdateWidth:a});const C=F(()=>{const{common:{cubicBezierEaseInOut:r,cubicBezierEaseIn:v,cubicBezierEaseOut:T},self:{color:c,textColor:R,boxShadow:P,lineHeight:I,headerPadding:H,footerPadding:x,borderRadius:U,bodyPadding:Y,titleFontSize:J,titleTextColor:V,titleFontWeight:re,headerBorderBottom:ee,footerBorderTop:ue,closeIconColor:he,closeIconColorHover:ne,closeIconColorPressed:me,closeColorHover:fe,closeColorPressed:A,closeIconSize:se,closeSize:Ce,closeBorderRadius:Ze,resizableTriggerColorHover:Je}}=b.value;return{"--n-line-height":I,"--n-color":c,"--n-border-radius":U,"--n-text-color":R,"--n-box-shadow":P,"--n-bezier":r,"--n-bezier-out":T,"--n-bezier-in":v,"--n-header-padding":H,"--n-body-padding":Y,"--n-footer-padding":x,"--n-title-text-color":V,"--n-title-font-size":J,"--n-title-font-weight":re,"--n-header-border-bottom":ee,"--n-footer-border-top":ue,"--n-close-icon-color":he,"--n-close-icon-color-hover":ne,"--n-close-icon-color-pressed":me,"--n-close-size":Ce,"--n-close-color-hover":fe,"--n-close-color-pressed":A,"--n-close-icon-size":se,"--n-close-border-radius":Ze,"--n-resize-trigger-color-hover":Je}}),w=f?we("drawer",void 0,C,e):void 0;return{mergedClsPrefix:t,namespace:o,mergedBodyStyle:z,handleOutsideClick:k,handleMaskClick:m,handleEsc:B,mergedTheme:b,cssVars:f?void 0:C,themeClass:w==null?void 0:w.themeClass,onRender:w==null?void 0:w.onRender,isMounted:s}},render(){const{mergedClsPrefix:e}=this;return n(Xe,{to:this.to,show:this.show},{default:()=>{var t;return(t=this.onRender)===null||t===void 0||t.call(this),oe(n("div",{class:[`${e}-drawer-container`,this.namespace,this.themeClass],style:this.cssVars,role:"none"},this.showMask?n(_e,{name:"fade-in-transition",appear:this.isMounted},{default:()=>this.show?n("div",{"aria-hidden":!0,class:[`${e}-drawer-mask`,this.showMask==="transparent"&&`${e}-drawer-mask--invisible`],onClick:this.handleMaskClick}):null}):null,n(jt,Object.assign({},this.$attrs,{class:[this.drawerClass,this.$attrs.class],style:[this.mergedBodyStyle,this.$attrs.style],blockScroll:this.blockScroll,contentStyle:this.contentStyle,contentClass:this.contentClass,placement:this.placement,scrollbarProps:this.scrollbarProps,show:this.show,displayDirective:this.displayDirective,nativeScrollbar:this.nativeScrollbar,onAfterEnter:this.onAfterEnter,onAfterLeave:this.onAfterLeave,trapFocus:this.trapFocus,autoFocus:this.autoFocus,resizable:this.resizable,maxHeight:this.maxHeight,minHeight:this.minHeight,maxWidth:this.maxWidth,minWidth:this.minWidth,showMask:this.showMask,onEsc:this.handleEsc,onClickoutside:this.handleOutsideClick}),this.$slots)),[[xt,{zIndex:this.zIndex,enabled:this.show}]])}})}}),ro={title:String,headerClass:String,headerStyle:[Object,String],footerClass:String,footerStyle:[Object,String],bodyClass:String,bodyStyle:[Object,String],bodyContentClass:String,bodyContentStyle:[Object,String],nativeScrollbar:{type:Boolean,default:!0},scrollbarProps:Object,closable:Boolean},no=Z({name:"DrawerContent",props:ro,setup(){const e=xe(Se,null);e||tt("drawer-content","`n-drawer-content` must be placed inside `n-drawer`.");const{doUpdateShow:t}=e;function o(){t(!1)}return{handleCloseClick:o,mergedTheme:e.mergedThemeRef,mergedClsPrefix:e.mergedClsPrefixRef}},render(){const{title:e,mergedClsPrefix:t,nativeScrollbar:o,mergedTheme:f,bodyClass:s,bodyStyle:b,bodyContentClass:y,bodyContentStyle:p,headerClass:d,headerStyle:$,footerClass:E,footerStyle:l,scrollbarProps:a,closable:S,$slots:z}=this;return n("div",{role:"none",class:[`${t}-drawer-content`,o&&`${t}-drawer-content--native-scrollbar`]},z.header||e||S?n("div",{class:[`${t}-drawer-header`,d],style:$,role:"none"},n("div",{class:`${t}-drawer-header__main`,role:"heading","aria-level":"1"},z.header!==void 0?z.header():e),S&&n(bt,{onClick:this.handleCloseClick,clsPrefix:t,class:`${t}-drawer-header__close`,absolute:!0})):null,o?n("div",{class:[`${t}-drawer-body`,s],style:b,role:"none"},n("div",{class:[`${t}-drawer-body-content-wrapper`,y],style:p,role:"none"},z)):n(Ke,Object.assign({themeOverrides:f.peerOverrides.Scrollbar,theme:f.peers.Scrollbar},a,{class:`${t}-drawer-body`,contentClass:[`${t}-drawer-body-content-wrapper`,y],contentStyle:p}),z),z.footer?n("div",{class:[`${t}-drawer-footer`,E],style:l,role:"none"},z.footer()):null)}});Object.assign(Object.assign({},Q.props),{left:[Number,String],right:[Number,String],top:[Number,String],bottom:[Number,String],shape:{type:String,default:"circle"},position:{type:String,default:"fixed"}});const so=ot("n-float-button-group");function io(e){const{popoverColor:t,textColor2:o,buttonColor2Hover:f,buttonColor2Pressed:s,primaryColor:b,primaryColorHover:y,primaryColorPressed:p,borderRadius:d}=e;return{color:t,colorHover:f,colorPressed:s,colorPrimary:b,colorPrimaryHover:y,colorPrimaryPressed:p,textColor:o,boxShadow:"0 2px 8px 0px rgba(0, 0, 0, .16)",boxShadowHover:"0 2px 12px 0px rgba(0, 0, 0, .24)",boxShadowPressed:"0 2px 12px 0px rgba(0, 0, 0, .24)",textColorPrimary:"#fff",borderRadiusSquare:d}}const ao={name:"FloatButton",common:Pe,self:io},lo=L("float-button",`
 user-select: none;
 cursor: pointer;
 color: var(--n-text-color);
 background-color: var(--n-color);
 font-size: 18px;
 transition:
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 box-shadow: var(--n-box-shadow);
 display: flex;
 align-items: stretch;
 box-sizing: border-box;
`,[D("circle-shape",`
 border-radius: 4096px;
 `),D("square-shape",`
 border-radius: var(--n-border-radius-square);
 `),N("fill",`
 position: absolute;
 inset: 0;
 transition: background-color .3s var(--n-bezier);
 border-radius: inherit;
 `),N("body",`
 position: relative;
 flex-grow: 1;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: transform .3s var(--n-bezier), opacity .3s var(--n-bezier);
 border-radius: inherit;
 flex-direction: column;
 box-sizing: border-box;
 padding: 2px 4px;
 gap: 2px;
 transform: scale(1);
 `,[N("description",`
 font-size: 12px;
 text-align: center;
 line-height: 14px;
 `)]),i("&:hover","box-shadow: var(--n-box-shadow-hover);",[i(">",[N("fill",`
 background-color: var(--n-color-hover);
 `)])]),i("&:active","box-shadow: var(--n-box-shadow-pressed);",[i(">",[N("fill",`
 background-color: var(--n-color-pressed);
 `)])]),D("show-menu",[i(">",[N("menu",`
 pointer-events: all;
 bottom: 100%;
 opacity: 1;
 `),N("close",`
 transform: scale(1);
 opacity: 1;
 `),N("body",`
 transform: scale(0.75);
 opacity: 0;
 `)])]),N("close",`
 opacity: 0;
 transform: scale(0.75);
 position: absolute;
 inset: 0;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: transform .3s var(--n-bezier), opacity .3s var(--n-bezier);
 `),N("menu",`
 position: absolute;
 bottom: calc(100% - 8px);
 display: flex;
 flex-direction: column;
 opacity: 0;
 pointer-events: none;
 transition:
 opacity .3s var(--n-bezier),
 bottom .3s var(--n-bezier); 
 `,[i("> *",`
 margin-bottom: 16px;
 `),L("float-button",`
 position: relative !important;
 `)])]),co=Object.assign(Object.assign({},Q.props),{width:{type:[Number,String],default:40},height:{type:[Number,String],default:40},left:[Number,String],right:[Number,String],top:[Number,String],bottom:[Number,String],shape:{type:String,default:"circle"},position:{type:String,default:"fixed"},type:{type:String,default:"default"},menuTrigger:String,showMenu:{type:Boolean,default:void 0},onUpdateShowMenu:{type:[Function,Array],default:void 0},"onUpdate:showMenu":{type:[Function,Array],default:void 0}}),uo=Z({name:"FloatButton",props:co,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:o}=ce(e),f=Q("FloatButton","-float-button",lo,ao,e,t),s=xe(so,null),b=_(!1),y=ae(e,"showMenu"),p=le(y,b);function d(k){const{onUpdateShowMenu:O,"onUpdate:showMenu":B}=e;b.value=k,O&&q(O,k),B&&q(B,k)}const $=F(()=>{const{self:{color:k,textColor:O,boxShadow:B,boxShadowHover:M,boxShadowPressed:C,colorHover:w,colorPrimary:r,colorPrimaryHover:v,textColorPrimary:T,borderRadiusSquare:c,colorPressed:R,colorPrimaryPressed:P},common:{cubicBezierEaseInOut:I}}=f.value,{type:H}=e;return{"--n-bezier":I,"--n-box-shadow":B,"--n-box-shadow-hover":M,"--n-box-shadow-pressed":C,"--n-color":H==="primary"?r:k,"--n-text-color":H==="primary"?T:O,"--n-color-hover":H==="primary"?v:w,"--n-color-pressed":H==="primary"?P:R,"--n-border-radius-square":c}}),E=F(()=>{const{width:k,height:O}=e;return Object.assign({position:s?void 0:e.position,width:W(k),minHeight:W(O)},s?null:{left:W(e.left),right:W(e.right),top:W(e.top),bottom:W(e.bottom)})}),l=F(()=>s?s.shapeRef.value:e.shape),a=()=>{e.menuTrigger==="hover"&&d(!0)},S=()=>{e.menuTrigger==="hover"&&p.value&&d(!1)},z=()=>{e.menuTrigger==="click"&&d(!p.value)},m=o?we("float-button",F(()=>e.type[0]),$,e):void 0;return{inlineStyle:E,cssVars:o?void 0:$,mergedClsPrefix:t,mergedShape:l,mergedShowMenu:p,themeClass:m==null?void 0:m.themeClass,onRender:m==null?void 0:m.onRender,Mouseenter:a,handleMouseleave:S,handleClick:z}},render(){var e;const{mergedClsPrefix:t,cssVars:o,mergedShape:f,type:s,menuTrigger:b,mergedShowMenu:y,themeClass:p,$slots:d,inlineStyle:$,onRender:E}=this,l=[[ft,this.handleMouseleave]];return E==null||E(),oe(n("div",{class:[`${t}-float-button`,`${t}-float-button--${f}-shape`,`${t}-float-button--${s}-type`,y&&`${t}-float-button--show-menu`,p],style:[o,$],onMouseenter:this.Mouseenter,onMouseleave:this.handleMouseleave,onClick:this.handleClick,role:"button"},n("div",{class:`${t}-float-button__fill`,"aria-hidden":!0}),n("div",{class:`${t}-float-button__body`},(e=d.default)===null||e===void 0?void 0:e.call(d),rt(d.description,a=>a?n("div",{class:`${t}-float-button__description`},a):null)),b?n("div",{class:`${t}-float-button__close`},n(He,{clsPrefix:t},{default:()=>n(vt,null)})):null,b?n("div",{onClick:a=>{a.stopPropagation()},"data-float-button-menu":!0,class:`${t}-float-button__menu`},Ie(d.menu,()=>[])):null),l)}}),ho=e=>(De("data-v-70821bbd"),e=e(),je(),e),mo={class:"nav-container"},fo={class:"left"},bo={class:"title"},vo=["src"],po=["to"],go={class:"right"},yo=ho(()=>h("div",{class:"tools"},null,-1)),wo={class:"menu"},_o=Z({__name:"ArticleHeader",props:{user:{}},emits:["outlineVisible","moreClick"],setup(e,{expose:t,emit:o}){Le(m=>({28900910:u(s).textColor1,"307fe2df":u(s).dividerColor,b7ae4184:u(s).cardColor,"32bf2b1b":u(s).boxShadow1}));const f=Oe();nt(),Ne();const s=We(),{theme:b}=f;st();const y=o;t({setNavVisible(m){a.value=m}});function p(){b.dark=!b.dark}const d=_(!0);function $(){d.value=!d.value,y("outlineVisible",d.value)}const E=F(()=>b.dark?"material-symbols:dark-mode":"material-symbols:light-mode"),l=[],a=_(!1);ye(()=>{l.push(Ve(document.body,"wheel").subscribe(m=>{m.deltaY>0?a.value=!1:a.value=!0}))}),Fe(()=>{l.forEach(m=>m.unsubscribe())});function S(m){const k=m.target;k.src="/avatar03.png"}function z(){y("moreClick")}return(m,k)=>{const O=ct,B=Ue,M=Ye;return X(),G("div",{class:te(["nav",u(a)&&"visible"])},[h("div",mo,[h("div",fo,[g(O,{to:`/${m.user.UID}`},{default:j(()=>[h("div",bo,[h("img",{class:"tapenote-icon logo",src:m.user.avatar,alt:"",onError:S},null,40,vo),h("span",{class:"tapenote-name",to:`/${m.user.UID}`},K(m.user.nickname),9,po)])]),_:1},8,["to"])]),h("div",go,[yo,h("div",wo,[h("div",{class:"outline-switch",onClick:$},[g(B,{class:"outline-switch-icon",name:u(d)?"heroicons-outline:eye":"heroicons-outline:eye-off",size:"24px"},null,8,["name"])]),g(M,{class:"divider",vertical:""}),h("div",{class:"theme-switch",onClick:p},[g(B,{name:u(E),size:"24px"},null,8,["name"])])]),g(B,{class:"more-btn",name:"mingcute:more-1-fill",size:"24px",onClick:z}),g(dt,{class:"collapse-btn",style:{scale:.6},onClick:z})])])],2)}}}),xo=qe(_o,[["__scopeId","data-v-70821bbd"]]),So=e=>(De("data-v-998b6a34"),e=e(),je(),e),Co={class:"wrapper"},ko={class:"header"},$o={class:"title"},zo={class:"tags"},Ro={class:"detail"},Po={class:"author"},To={class:"time"},Bo={class:"wordage"},Eo={key:0,class:"duration"},Mo={class:"main"},Io={class:te(["outline-wrapper"])},Ho={vertical:""},Lo=So(()=>h("span",null,"主题 ：",-1)),Oo={key:0},No={key:1},Fo={class:"custom-outline"},Do=["onClick"],jo=Z({__name:"Article",props:{id:{}},setup(e){Le(x=>({"69b50480":u(t).textColor1,d4829464:u(t).cardColor,"69b50482":u(t).textColor3}));const t=We(),o=e,f=mt(),s=Oe(),b=_(),y=_(),p=_(),d=_(),$=_(),E=_(),l=_({UID:"",user:{UID:"",nickname:"",avatar:""},editionId:"",fromEditionId:"",type:"note",isParsed:!1,msg:"",editorVersion:"",cover:"",title:"",content:"",abbrev:"",audio:"",promoterSequence:[],keyframeSequence:[],subtitleSequence:[],subtitleKeyframeSequence:[],tags:[],isPublish:!1,author:{penname:"",avatar:"",email:"",blog:""},detail:{wordage:0,duration:0,fileSize:0},meta:{views:0,likes:0,collections:0,comments:0},_id:"",columnId:"",createAt:"",updateAt:""});let a,S;const z=[];let m;const k=[],O=_(0);ye(async()=>{b.value=document.body,S=await it(()=>import("./C6sUMVAr.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42]),import.meta.url),$fetch(`/api/article/${o.id}`).then(x=>{l.value=x,ht({rootRef:$,editorRef:p,scrollerRef:b,controllerRef:y,outlineRef:d,data:l.value}).then(U=>{a=U;const Y=a.get(S.Player);z.push(Y.onStateUpdate.subscribe(()=>{console.log("playing"),v.value=Y.isPlaying,Y.isPlaying&&E.value.setNavVisible(!1)}),a.onReady.subscribe(()=>{m=p.value.querySelectorAll("h1, h2, h3, h4, h5, h6"),m.forEach(J=>{k.push({tagName:J.tagName.toLocaleLowerCase(),text:J.textContent||"",offsetTop:J.offsetTop})})}))})}).catch(x=>{f.error("获取文章失败!"),Ae("/")}),z.push(Ve(document.body,"scroll").subscribe(()=>{O.value=k.findIndex(x=>x.offsetTop>document.body.scrollTop)}))}),Fe(()=>{try{console.log("销毁依赖"),z.forEach(x=>x.unsubscribe()),a.get(S.Player).destory(),a.get(S.OutlineService).destory(),a.get(S.DialogProvider).destory(),a.get(S.AnimeProvider).destory(),a.get(S.Structurer).destory(),a.get(S.ThemeProvider).destory(),a.get(S.RootEventService).destory(),a.get(S.AnimeEventService).destory(),a.destroy(),console.log("编辑器是否已经销毁："+a.destroyed)}catch(x){console.log(x),console.error("编辑器销毁失败！")}});const B=_(!0);function M(){B.value=!B.value}const C=_(!1);function w(){C.value=!0}function r(x){document.body.scrollTo({top:x-10,behavior:"smooth"})}const v=_(!1),T=F(()=>v.value?"material-symbols:pause-rounded":"material-symbols:play-arrow-rounded");function c(){const x=a.get(S.Player);if(!x.isPlaying&&!x.isPause){x.start(),v.value=!0;return}if(x.isPlaying&&!x.isPause){x.pause(),v.value=!1;return}if(!x.isPlaying&&x.isPause){x.resume(),v.value=!0;return}}const R=_(!0);let P;function I(){P=setTimeout(()=>{console.log("mousedown"),R.value=!0,clearTimeout(P)},1e3)}function H(){clearTimeout(P)}return(x,U)=>{const Y=xo,J=Bt,V=Ue,re=Ye,ee=uo,ue=Dt,he=ut,ne=Et,me=no,fe=oo;return X(),G(be,null,[g(Y,{ref_key:"navRef",ref:E,user:u(l).user,onOutlineVisible:M,onMoreClick:w},null,8,["user"]),h("div",{ref_key:"rootRef",ref:$,class:"article"},[h("div",Co,[h("div",ko,[h("div",$o,K(u(l).title),1),h("div",zo,[(X(!0),G(be,null,ke(u(l).tags,A=>(X(),at(J,{bordered:!1},{default:j(()=>[$e(K(A),1)]),_:2},1024))),256))]),h("div",Ro,[h("div",Po,[g(V,{name:"clarity:avatar-solid",size:"20px"}),h("span",null,K(u(l).author.penname),1)]),h("div",To,[g(V,{name:"material-symbols:calendar-clock",size:"20px"}),h("span",null,K(u(ze)(u(l).createAt).format("YYYY-MM-DD HH:mm:ss")),1)]),h("div",Bo,[g(V,{name:"ant-design:field-number-outlined",size:"24px"}),h("span",null,K(u(l).detail.wordage),1)]),u(l).detail.duration?(X(),G("div",Eo,[g(V,{name:"material-symbols:alarm",size:"20px"}),h("span",null,K(u(ze)().minute(Math.floor(u(l).detail.duration/60)).second(u(l).detail.duration%60).format("mm:ss")),1)])):ve("",!0)]),g(re)]),h("div",Mo,[h("div",{ref_key:"editorRef",ref:p,class:"content editor"},null,512),h("div",Io,[h("div",{ref_key:"outlineRef",ref:d,class:te(["outliner",u(B)?"":"outline-visible"])},null,2)])])]),oe(h("div",{ref_key:"controllerRef",ref:y,class:te(["controller"])},null,512),[[ge,u(l).type==="course"]])],512),g(ee,{class:"mo-controller",shape:"circle",position:"fixed",right:"40px",bottom:"40px",onClick:c,onMousedown:I,onMouseup:H,onTouchstart:I,onTouchend:H,onToucemove:H},{menu:j(()=>[g(ee,null,{default:j(()=>[g(V,{name:"clarity:avatar-solid",size:"20px"})]),_:1}),g(ee,null,{default:j(()=>[g(V,{name:"clarity:avatar-solid",size:"20px"})]),_:1}),g(ee,null,{default:j(()=>[g(V,{name:"clarity:avatar-solid",size:"20px"})]),_:1})]),default:j(()=>[g(V,{name:u(T),size:"24"},null,8,["name"])]),_:1}),g(ue,{class:"back-top",right:100,to:u($)},null,8,["to"]),g(fe,{show:u(C),"onUpdate:show":U[1]||(U[1]=A=>lt(C)?C.value=A:null),width:"40%",placement:"right",to:u($)},{default:j(()=>[g(me,{title:"Menu"},{default:j(()=>[h("div",Ho,[g(ne,null,{default:j(()=>[Lo,g(he,{class:"theme-switch","onUpdate:value":U[0]||(U[0]=A=>u(s).theme.dark=A),value:u(s).theme.dark,size:"medium"},{icon:j(()=>[u(s).theme.dark?ve("",!0):(X(),G("span",Oo,"☀")),u(s).theme.dark?(X(),G("span",No,"🌙")):ve("",!0)]),_:1},8,["value"])]),_:1}),g(re,{class:"divider"}),h("div",Fo,[g(ne,{vertical:""},{default:j(()=>[$e(" 目录 "),(X(),G(be,null,ke(k,(A,se)=>h("div",{key:se,class:te(["outline-heading-item",`outline-heading-${A.tagName}`])},[h("a",{class:te(["outline-heading-text",u(O)===se?"outline-heading-active":""]),href:"javascript:;",onClick:Ce=>r(A.offsetTop)},K(A.text),11,Do)],2)),64))]),_:1})])])]),_:1})]),_:1},8,["show","to"])],64)}}}),Ao=qe(jo,[["__scopeId","data-v-998b6a34"]]),pr=Z({__name:"[id]",setup(e){const t=Ne();return t.params.id||(console.log("警告！确保用户已经通过身份验证！"),Ae("/")),(o,f)=>{const s=Ao;return X(),G("div",null,[g(s,{id:u(t).params.id},null,8,["id"])])}}});export{pr as default};
