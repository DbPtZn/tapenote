import{_ as r}from"./DlAUqK2U.js";import{A as e,z as t}from"./BmdUO_FW.js";const c={};function o(n,a){return t(),e("div",null," party ")}const f=r(c,[["render",o]]);export{f as default};
