const t=new WeakSet;function n(e){t.add(e)}function f(e){return!t.has(e)}export{f as e,n as m};
