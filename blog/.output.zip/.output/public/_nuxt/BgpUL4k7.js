import{_ as E}from"./DJI109mh.js";import{f as S,s as t,b as u,a as y,e as h,u as M,j as H,Y as j,h as A,l as D,X as F,v as P,x as p,a3 as R,N as L,a4 as O,r as G,z as V,A as J,B as g,D as l,E as s,G as $,K,L as W,M as X,J as Y,ax as q}from"./agTtEPyh.js";import{_ as Q}from"./ifS_JpK_.js";import{p as U,a as Z,d as ee,N as te}from"./DwBaRR9t.js";import{u as T}from"./2ZKYzm_-.js";import{a as oe,N as ae}from"./Bs5aOGxo.js";import{_ as I}from"./DlAUqK2U.js";import{N as re}from"./B9LYsvIZ.js";import"./94yb6JQI.js";import"./qItcCqav.js";import"./CPO6eoYI.js";import"./DiUaNqzw.js";import"./DpetxL_I.js";import"./CgDIfVP3.js";import"./DVStUdaF.js";import"./B2JAqTIZ.js";import"./Dz6IFsFJ.js";import"./BQO-GLxH.js";import"./a4dohR0S.js";import"./BTo_LjMj.js";import"./BJzoeemS.js";import"./BydF-e59.js";import"./C4qrVBgM.js";import"./BPjecetv.js";import"./R4FuRqJU.js";import"./BxnNfj_0.js";import"./BBvQIeFO.js";import"./B-p6aW7q.js";import"./vCpSA_hg.js";import"./BUltGF3k.js";import"./B1JEyG5d.js";import"./Bk_rJcZu.js";import"./CitWoLXq.js";import"./WOZlt_tu.js";import"./D5pdJeKL.js";import"./DsSU6HIH.js";const se=S({name:"ArrowBack",render(){return t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24"},t("path",{d:"M0 0h24v24H0V0z",fill:"none"}),t("path",{d:"M19 11H7.83l4.88-4.88c.39-.39.39-1.03 0-1.42-.39-.39-1.02-.39-1.41 0l-6.59 6.59c-.39.39-.39 1.02 0 1.41l6.59 6.59c.39.39 1.02.39 1.41 0 .39-.39.39-1.02 0-1.41L7.83 13H19c.55 0 1-.45 1-1s-.45-1-1-1z"}))}}),ne=u([y("page-header-header",`
 margin-bottom: 20px;
 `),y("page-header",`
 display: flex;
 align-items: center;
 justify-content: space-between;
 line-height: 1.5;
 font-size: var(--n-font-size);
 `,[h("main",`
 display: flex;
 flex-wrap: nowrap;
 align-items: center;
 `),h("back",`
 display: flex;
 margin-right: 16px;
 font-size: var(--n-back-size);
 cursor: pointer;
 color: var(--n-back-color);
 transition: color .3s var(--n-bezier);
 `,[u("&:hover","color: var(--n-back-color-hover);"),u("&:active","color: var(--n-back-color-pressed);")]),h("avatar",`
 display: flex;
 margin-right: 12px
 `),h("title",`
 margin-right: 16px;
 transition: color .3s var(--n-bezier);
 font-size: var(--n-title-font-size);
 font-weight: var(--n-title-font-weight);
 color: var(--n-title-text-color);
 `),h("subtitle",`
 font-size: 14px;
 transition: color .3s var(--n-bezier);
 color: var(--n-subtitle-text-color);
 `)]),y("page-header-content",`
 font-size: var(--n-font-size);
 `,[u("&:not(:first-child)","margin-top: 20px;")]),y("page-header-footer",`
 font-size: var(--n-font-size);
 `,[u("&:not(:first-child)","margin-top: 20px;")])]),ie=Object.assign(Object.assign({},H.props),{title:String,subtitle:String,extra:String,onBack:Function}),le=S({name:"PageHeader",props:ie,setup(o){const{mergedClsPrefixRef:a,mergedRtlRef:c,inlineThemeDisabled:n}=M(o),m=H("PageHeader","-page-header",ne,U,o,a),e=j("PageHeader",c,a),i=A(()=>{const{self:{titleTextColor:d,subtitleTextColor:_,backColor:v,fontSize:b,titleFontSize:x,backSize:f,titleFontWeight:k,backColorHover:z,backColorPressed:w},common:{cubicBezierEaseInOut:C}}=m.value;return{"--n-title-text-color":d,"--n-title-font-size":x,"--n-title-font-weight":k,"--n-font-size":b,"--n-back-size":f,"--n-subtitle-text-color":_,"--n-back-color":v,"--n-back-color-hover":z,"--n-back-color-pressed":w,"--n-bezier":C}}),r=n?D("page-header",void 0,i,o):void 0;return{rtlEnabled:e,mergedClsPrefix:a,cssVars:n?void 0:i,themeClass:r==null?void 0:r.themeClass,onRender:r==null?void 0:r.onRender}},render(){var o;const{onBack:a,title:c,subtitle:n,extra:m,mergedClsPrefix:e,cssVars:i,$slots:r}=this;(o=this.onRender)===null||o===void 0||o.call(this);const{title:d,subtitle:_,extra:v,default:b,header:x,avatar:f,footer:k,back:z}=r,w=a,C=c||d,B=n||_,N=m||v;return t("div",{style:i,class:[`${e}-page-header-wrapper`,this.themeClass,this.rtlEnabled&&`${e}-page-header-wrapper--rtl`]},x?t("div",{class:`${e}-page-header-header`,key:"breadcrumb"},x()):null,(w||f||C||B||N)&&t("div",{class:`${e}-page-header`,key:"header"},t("div",{class:`${e}-page-header__main`,key:"back"},w?t("div",{class:`${e}-page-header__back`,onClick:a},z?z():t(F,{clsPrefix:e},{default:()=>t(se,null)})):null,f?t("div",{class:`${e}-page-header__avatar`},f()):null,C?t("div",{class:`${e}-page-header__title`,key:"title"},c||d()):null,B?t("div",{class:`${e}-page-header__subtitle`,key:"subtitle"},n||_()):null),N?t("div",{class:`${e}-page-header__extra`},m||v()):null),b?t("div",{class:`${e}-page-header-content`,key:"content"},b()):null,k?t("div",{class:`${e}-page-header-footer`,key:"footer"},k()):null)}}),ce=o=>(W("data-v-6f30af4c"),o=o(),X(),o),de={class:"nav"},pe={class:"nav-container"},me=ce(()=>g("img",{class:"logo",src:Q},null,-1)),_e=S({__name:"ManageHeader",setup(o){P(n=>({d204aecc:p(a).dividerColor,"734af811":p(a).bodyColor,"77d92396":p(a).boxShadow1})),R(),L();const a=T();O(),G();const c=[{label:"预览",key:"1"},{label:"预览",key:"2"},{label:"预览",key:"3"}];return(n,m)=>{const e=E,i=K,r=oe,d=ae,_=le;return V(),J("div",de,[g("div",pe,[l(_,{class:"wrapper"},{title:s(()=>[l(e,{to:"/"},{default:s(()=>[$("Tapenote")]),_:1})]),avatar:s(()=>[me]),extra:s(()=>[l(d,null,{default:s(()=>[l(i,null,{default:s(()=>[$("预览")]),_:1}),l(r,{options:c,placement:"bottom-start",to:!1},{default:s(()=>[l(i,{bordered:!1,style:{padding:"0 4px","font-size":"24px","line-height":"24px"}},{default:s(()=>[$(" ··· ")]),_:1})]),_:1})]),_:1})]),_:1})])])}}}),fe=I(_e,[["__scopeId","data-v-6f30af4c"]]),ue={class:"layout"},he={class:"header"},ge={class:"content"},ve=S({__name:"manage",setup(o){P(n=>({"40f3b870":p(a).bodyColor,"5a139f54":p(a).scrollbarColor}));const a=T(),c=R();return(n,m)=>{const e=fe,i=te,r=re,d=Z;return V(),Y(d,{theme:p(c).theme.dark?p(ee):null},{default:s(()=>[l(r,null,{default:s(()=>[l(i,null,{default:s(()=>[g("div",ue,[g("div",he,[l(e)]),g("div",ge,[q(n.$slots,"default",{},void 0,!0)])])]),_:3})]),_:3})]),_:3},8,["theme"])}}}),tt=I(ve,[["__scopeId","data-v-e3f5b164"]]);export{tt as default};
