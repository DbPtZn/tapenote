import{_ as e}from"./DlAUqK2U.js";import{A as o,z as t}from"./agTtEPyh.js";const r={};function c(n,a){return t(),o("div",null," about ")}const f=e(r,[["render",c]]);export{f as default};
