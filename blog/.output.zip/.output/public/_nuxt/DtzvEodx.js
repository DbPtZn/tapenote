import{bf as qe,f as V,s as t,bg as te,j as oe,c as $e,b9 as Tt,Q as Lt,b as N,a as h,af as $t,S as U,r as W,p as Ot,n as Ye,g as ie,h as L,u as se,l as me,T as zt,X as j,_ as Me,U as Re,H as ve,$ as Bt,aI as It,Z as Oe,al as Dt,o as Ue,w as ke,R as P,b2 as Ge,b4 as Ke,b3 as Je,b1 as Qe,k as Pe,a2 as be,b6 as Mt,q as Ut,ag as et,ah as Ft,K as fe,aB as Nt,aE as _t,e as Q,aF as jt,ae as Et,bh as At,a1 as Fe,W as Ht}from"./Dw-eJYB0.js";import{p as Wt,t as Vt,f as Ne,u as Zt}from"./DWthmWeD.js";import{u as Xt}from"./B9sDpcpB.js";import{f as le}from"./B-p6aW7q.js";import{o as qt,i as Yt}from"./BmxDCYHM.js";import{f as _e,a as Se,o as ge,c as Te}from"./DTeQSsQy.js";import{f as Gt,L as Kt,z as Jt}from"./4OvUpPkk.js";import{t as Qt}from"./D9ahxme7.js";import{u as er,E as tr}from"./CvD7E7Un.js";import{d as tt,N as rr}from"./9dWk58tl.js";import{e as or}from"./D4rqFDaS.js";import{u as ir}from"./CiaBG7ek.js";function nr(e,o,r,i){for(var n=-1,s=e==null?0:e.length;++n<s;)r=o(r,e[n],n,e);return r}function lr(e){return function(o){return e==null?void 0:e[o]}}var ar={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},sr=lr(ar),dr=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,ur="\\u0300-\\u036f",cr="\\ufe20-\\ufe2f",fr="\\u20d0-\\u20ff",gr=ur+cr+fr,hr="["+gr+"]",pr=RegExp(hr,"g");function vr(e){return e=qe(e),e&&e.replace(dr,sr).replace(pr,"")}var mr=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;function br(e){return e.match(mr)||[]}var wr=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;function xr(e){return wr.test(e)}var rt="\\ud800-\\udfff",yr="\\u0300-\\u036f",Cr="\\ufe20-\\ufe2f",Rr="\\u20d0-\\u20ff",Sr=yr+Cr+Rr,ot="\\u2700-\\u27bf",it="a-z\\xdf-\\xf6\\xf8-\\xff",kr="\\xac\\xb1\\xd7\\xf7",Pr="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",Tr="\\u2000-\\u206f",Lr=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",nt="A-Z\\xc0-\\xd6\\xd8-\\xde",$r="\\ufe0e\\ufe0f",lt=kr+Pr+Tr+Lr,at="['’]",je="["+lt+"]",Or="["+Sr+"]",st="\\d+",zr="["+ot+"]",dt="["+it+"]",ut="[^"+rt+lt+st+ot+it+nt+"]",Br="\\ud83c[\\udffb-\\udfff]",Ir="(?:"+Or+"|"+Br+")",Dr="[^"+rt+"]",ct="(?:\\ud83c[\\udde6-\\uddff]){2}",ft="[\\ud800-\\udbff][\\udc00-\\udfff]",ae="["+nt+"]",Mr="\\u200d",Ee="(?:"+dt+"|"+ut+")",Ur="(?:"+ae+"|"+ut+")",Ae="(?:"+at+"(?:d|ll|m|re|s|t|ve))?",He="(?:"+at+"(?:D|LL|M|RE|S|T|VE))?",gt=Ir+"?",ht="["+$r+"]?",Fr="(?:"+Mr+"(?:"+[Dr,ct,ft].join("|")+")"+ht+gt+")*",Nr="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",_r="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",jr=ht+gt+Fr,Er="(?:"+[zr,ct,ft].join("|")+")"+jr,Ar=RegExp([ae+"?"+dt+"+"+Ae+"(?="+[je,ae,"$"].join("|")+")",Ur+"+"+He+"(?="+[je,ae+Ee,"$"].join("|")+")",ae+"?"+Ee+"+"+Ae,ae+"+"+He,_r,Nr,st,Er].join("|"),"g");function Hr(e){return e.match(Ar)||[]}function Wr(e,o,r){return e=qe(e),o=o,o===void 0?xr(e)?Hr(e):br(e):e.match(o)||[]}var Vr="['’]",Zr=RegExp(Vr,"g");function Xr(e){return function(o){return nr(Wr(vr(o).replace(Zr,"")),e,"")}}var qr=Xr(function(e,o,r){return e+(r?"-":"")+o.toLowerCase()});const Yr=V({name:"Add",render(){return t("svg",{width:"512",height:"512",viewBox:"0 0 512 512",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M256 112V400M400 256H112",stroke:"currentColor","stroke-width":"32","stroke-linecap":"round","stroke-linejoin":"round"}))}}),Gr=te("attach",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M3.25735931,8.70710678 L7.85355339,4.1109127 C8.82986412,3.13460197 10.4127766,3.13460197 11.3890873,4.1109127 C12.365398,5.08722343 12.365398,6.67013588 11.3890873,7.64644661 L6.08578644,12.9497475 C5.69526215,13.3402718 5.06209717,13.3402718 4.67157288,12.9497475 C4.28104858,12.5592232 4.28104858,11.9260582 4.67157288,11.5355339 L9.97487373,6.23223305 C10.1701359,6.0369709 10.1701359,5.72038841 9.97487373,5.52512627 C9.77961159,5.32986412 9.4630291,5.32986412 9.26776695,5.52512627 L3.96446609,10.8284271 C3.18341751,11.6094757 3.18341751,12.8758057 3.96446609,13.6568542 C4.74551468,14.4379028 6.01184464,14.4379028 6.79289322,13.6568542 L12.0961941,8.35355339 C13.4630291,6.98671837 13.4630291,4.77064094 12.0961941,3.40380592 C10.7293591,2.0369709 8.51328163,2.0369709 7.14644661,3.40380592 L2.55025253,8 C2.35499039,8.19526215 2.35499039,8.51184464 2.55025253,8.70710678 C2.74551468,8.90236893 3.06209717,8.90236893 3.25735931,8.70710678 Z"}))))),Kr=te("trash",t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M432,144,403.33,419.74A32,32,0,0,1,371.55,448H140.46a32,32,0,0,1-31.78-28.26L80,144",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),t("rect",{x:"32",y:"64",width:"448",height:"80",rx:"16",ry:"16",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),t("line",{x1:"312",y1:"240",x2:"200",y2:"352",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}),t("line",{x1:"312",y1:"352",x2:"200",y2:"240",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),pt=te("download",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M3.5,13 L12.5,13 C12.7761424,13 13,13.2238576 13,13.5 C13,13.7454599 12.8231248,13.9496084 12.5898756,13.9919443 L12.5,14 L3.5,14 C3.22385763,14 3,13.7761424 3,13.5 C3,13.2545401 3.17687516,13.0503916 3.41012437,13.0080557 L3.5,13 L12.5,13 L3.5,13 Z M7.91012437,1.00805567 L8,1 C8.24545989,1 8.44960837,1.17687516 8.49194433,1.41012437 L8.5,1.5 L8.5,10.292 L11.1819805,7.6109127 C11.3555469,7.43734635 11.6249713,7.4180612 11.8198394,7.55305725 L11.8890873,7.6109127 C12.0626536,7.78447906 12.0819388,8.05390346 11.9469427,8.2487716 L11.8890873,8.31801948 L8.35355339,11.8535534 C8.17998704,12.0271197 7.91056264,12.0464049 7.7156945,11.9114088 L7.64644661,11.8535534 L4.1109127,8.31801948 C3.91565056,8.12275734 3.91565056,7.80617485 4.1109127,7.6109127 C4.28447906,7.43734635 4.55390346,7.4180612 4.7487716,7.55305725 L4.81801948,7.6109127 L7.5,10.292 L7.5,1.5 C7.5,1.25454011 7.67687516,1.05039163 7.91012437,1.00805567 L8,1 L7.91012437,1.00805567 Z"}))))),Jr=te("cancel",t("svg",{viewBox:"0 0 16 16",version:"1.1",xmlns:"http://www.w3.org/2000/svg"},t("g",{stroke:"none","stroke-width":"1",fill:"none","fill-rule":"evenodd"},t("g",{fill:"currentColor","fill-rule":"nonzero"},t("path",{d:"M2.58859116,2.7156945 L2.64644661,2.64644661 C2.82001296,2.47288026 3.08943736,2.45359511 3.2843055,2.58859116 L3.35355339,2.64644661 L8,7.293 L12.6464466,2.64644661 C12.8417088,2.45118446 13.1582912,2.45118446 13.3535534,2.64644661 C13.5488155,2.84170876 13.5488155,3.15829124 13.3535534,3.35355339 L8.707,8 L13.3535534,12.6464466 C13.5271197,12.820013 13.5464049,13.0894374 13.4114088,13.2843055 L13.3535534,13.3535534 C13.179987,13.5271197 12.9105626,13.5464049 12.7156945,13.4114088 L12.6464466,13.3535534 L8,8.707 L3.35355339,13.3535534 C3.15829124,13.5488155 2.84170876,13.5488155 2.64644661,13.3535534 C2.45118446,13.1582912 2.45118446,12.8417088 2.64644661,12.6464466 L7.293,8 L2.64644661,3.35355339 C2.47288026,3.17998704 2.45359511,2.91056264 2.58859116,2.7156945 L2.64644661,2.64644661 L2.58859116,2.7156945 Z"}))))),Qr=te("retry",t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 512 512"},t("path",{d:"M320,146s24.36-12-64-12A160,160,0,1,0,416,294",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-miterlimit: 10; stroke-width: 32px;"}),t("polyline",{points:"256 58 336 138 256 218",style:"fill: none; stroke: currentcolor; stroke-linecap: round; stroke-linejoin: round; stroke-width: 32px;"}))),eo=te("rotateClockwise",t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10C17 12.7916 15.3658 15.2026 13 16.3265V14.5C13 14.2239 12.7761 14 12.5 14C12.2239 14 12 14.2239 12 14.5V17.5C12 17.7761 12.2239 18 12.5 18H15.5C15.7761 18 16 17.7761 16 17.5C16 17.2239 15.7761 17 15.5 17H13.8758C16.3346 15.6357 18 13.0128 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10C2 10.2761 2.22386 10.5 2.5 10.5C2.77614 10.5 3 10.2761 3 10Z",fill:"currentColor"}),t("path",{d:"M10 12C11.1046 12 12 11.1046 12 10C12 8.89543 11.1046 8 10 8C8.89543 8 8 8.89543 8 10C8 11.1046 8.89543 12 10 12ZM10 11C9.44772 11 9 10.5523 9 10C9 9.44772 9.44772 9 10 9C10.5523 9 11 9.44772 11 10C11 10.5523 10.5523 11 10 11Z",fill:"currentColor"}))),to=te("rotateClockwise",t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M17 10C17 6.13401 13.866 3 10 3C6.13401 3 3 6.13401 3 10C3 12.7916 4.63419 15.2026 7 16.3265V14.5C7 14.2239 7.22386 14 7.5 14C7.77614 14 8 14.2239 8 14.5V17.5C8 17.7761 7.77614 18 7.5 18H4.5C4.22386 18 4 17.7761 4 17.5C4 17.2239 4.22386 17 4.5 17H6.12422C3.66539 15.6357 2 13.0128 2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10C18 10.2761 17.7761 10.5 17.5 10.5C17.2239 10.5 17 10.2761 17 10Z",fill:"currentColor"}),t("path",{d:"M10 12C8.89543 12 8 11.1046 8 10C8 8.89543 8.89543 8 10 8C11.1046 8 12 8.89543 12 10C12 11.1046 11.1046 12 10 12ZM10 11C10.5523 11 11 10.5523 11 10C11 9.44772 10.5523 9 10 9C9.44772 9 9 9.44772 9 10C9 10.5523 9.44772 11 10 11Z",fill:"currentColor"}))),ro=te("zoomIn",t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M11.5 8.5C11.5 8.22386 11.2761 8 11 8H9V6C9 5.72386 8.77614 5.5 8.5 5.5C8.22386 5.5 8 5.72386 8 6V8H6C5.72386 8 5.5 8.22386 5.5 8.5C5.5 8.77614 5.72386 9 6 9H8V11C8 11.2761 8.22386 11.5 8.5 11.5C8.77614 11.5 9 11.2761 9 11V9H11C11.2761 9 11.5 8.77614 11.5 8.5Z",fill:"currentColor"}),t("path",{d:"M8.5 3C11.5376 3 14 5.46243 14 8.5C14 9.83879 13.5217 11.0659 12.7266 12.0196L16.8536 16.1464C17.0488 16.3417 17.0488 16.6583 16.8536 16.8536C16.68 17.0271 16.4106 17.0464 16.2157 16.9114L16.1464 16.8536L12.0196 12.7266C11.0659 13.5217 9.83879 14 8.5 14C5.46243 14 3 11.5376 3 8.5C3 5.46243 5.46243 3 8.5 3ZM8.5 4C6.01472 4 4 6.01472 4 8.5C4 10.9853 6.01472 13 8.5 13C10.9853 13 13 10.9853 13 8.5C13 6.01472 10.9853 4 8.5 4Z",fill:"currentColor"}))),oo=te("zoomOut",t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M11 8C11.2761 8 11.5 8.22386 11.5 8.5C11.5 8.77614 11.2761 9 11 9H6C5.72386 9 5.5 8.77614 5.5 8.5C5.5 8.22386 5.72386 8 6 8H11Z",fill:"currentColor"}),t("path",{d:"M14 8.5C14 5.46243 11.5376 3 8.5 3C5.46243 3 3 5.46243 3 8.5C3 11.5376 5.46243 14 8.5 14C9.83879 14 11.0659 13.5217 12.0196 12.7266L16.1464 16.8536L16.2157 16.9114C16.4106 17.0464 16.68 17.0271 16.8536 16.8536C17.0488 16.6583 17.0488 16.3417 16.8536 16.1464L12.7266 12.0196C13.5217 11.0659 14 9.83879 14 8.5ZM4 8.5C4 6.01472 6.01472 4 8.5 4C10.9853 4 13 6.01472 13 8.5C13 10.9853 10.9853 13 8.5 13C6.01472 13 4 10.9853 4 8.5Z",fill:"currentColor"}))),io=V({name:"ResizeSmall",render(){return t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 20 20"},t("g",{fill:"none"},t("path",{d:"M5.5 4A1.5 1.5 0 0 0 4 5.5v1a.5.5 0 0 1-1 0v-1A2.5 2.5 0 0 1 5.5 3h1a.5.5 0 0 1 0 1h-1zM16 5.5A1.5 1.5 0 0 0 14.5 4h-1a.5.5 0 0 1 0-1h1A2.5 2.5 0 0 1 17 5.5v1a.5.5 0 0 1-1 0v-1zm0 9a1.5 1.5 0 0 1-1.5 1.5h-1a.5.5 0 0 0 0 1h1a2.5 2.5 0 0 0 2.5-2.5v-1a.5.5 0 0 0-1 0v1zm-12 0A1.5 1.5 0 0 0 5.5 16h1.25a.5.5 0 0 1 0 1H5.5A2.5 2.5 0 0 1 3 14.5v-1.25a.5.5 0 0 1 1 0v1.25zM8.5 7A1.5 1.5 0 0 0 7 8.5v3A1.5 1.5 0 0 0 8.5 13h3a1.5 1.5 0 0 0 1.5-1.5v-3A1.5 1.5 0 0 0 11.5 7h-3zM8 8.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v3a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-3z",fill:"currentColor"})))}}),ze=Object.assign(Object.assign({},oe.props),{onPreviewPrev:Function,onPreviewNext:Function,showToolbar:{type:Boolean,default:!0},showToolbarTooltip:Boolean,renderToolbar:Function}),vt=$e("n-image");function no(){return{toolbarIconColor:"rgba(255, 255, 255, .9)",toolbarColor:"rgba(0, 0, 0, .35)",toolbarBoxShadow:"none",toolbarBorderRadius:"24px"}}const lo=Tt({name:"Image",common:Lt,peers:{Tooltip:Qt},self:no}),ao=t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M6 5C5.75454 5 5.55039 5.17688 5.50806 5.41012L5.5 5.5V14.5C5.5 14.7761 5.72386 15 6 15C6.24546 15 6.44961 14.8231 6.49194 14.5899L6.5 14.5V5.5C6.5 5.22386 6.27614 5 6 5ZM13.8536 5.14645C13.68 4.97288 13.4106 4.9536 13.2157 5.08859L13.1464 5.14645L8.64645 9.64645C8.47288 9.82001 8.4536 10.0894 8.58859 10.2843L8.64645 10.3536L13.1464 14.8536C13.3417 15.0488 13.6583 15.0488 13.8536 14.8536C14.0271 14.68 14.0464 14.4106 13.9114 14.2157L13.8536 14.1464L9.70711 10L13.8536 5.85355C14.0488 5.65829 14.0488 5.34171 13.8536 5.14645Z",fill:"currentColor"})),so=t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M13.5 5C13.7455 5 13.9496 5.17688 13.9919 5.41012L14 5.5V14.5C14 14.7761 13.7761 15 13.5 15C13.2545 15 13.0504 14.8231 13.0081 14.5899L13 14.5V5.5C13 5.22386 13.2239 5 13.5 5ZM5.64645 5.14645C5.82001 4.97288 6.08944 4.9536 6.28431 5.08859L6.35355 5.14645L10.8536 9.64645C11.0271 9.82001 11.0464 10.0894 10.9114 10.2843L10.8536 10.3536L6.35355 14.8536C6.15829 15.0488 5.84171 15.0488 5.64645 14.8536C5.47288 14.68 5.4536 14.4106 5.58859 14.2157L5.64645 14.1464L9.79289 10L5.64645 5.85355C5.45118 5.65829 5.45118 5.34171 5.64645 5.14645Z",fill:"currentColor"})),uo=t("svg",{viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},t("path",{d:"M4.089 4.216l.057-.07a.5.5 0 0 1 .638-.057l.07.057L10 9.293l5.146-5.147a.5.5 0 0 1 .638-.057l.07.057a.5.5 0 0 1 .057.638l-.057.07L10.707 10l5.147 5.146a.5.5 0 0 1 .057.638l-.057.07a.5.5 0 0 1-.638.057l-.07-.057L10 10.707l-5.146 5.147a.5.5 0 0 1-.638.057l-.07-.057a.5.5 0 0 1-.057-.638l.057-.07L9.293 10L4.146 4.854a.5.5 0 0 1-.057-.638l.057-.07l-.057.07z",fill:"currentColor"})),co=N([N("body >",[h("image-container","position: fixed;")]),h("image-preview-container",`
 position: fixed;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 display: flex;
 `),h("image-preview-overlay",`
 z-index: -1;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 background: rgba(0, 0, 0, .3);
 `,[_e()]),h("image-preview-toolbar",`
 z-index: 1;
 position: absolute;
 left: 50%;
 transform: translateX(-50%);
 border-radius: var(--n-toolbar-border-radius);
 height: 48px;
 bottom: 40px;
 padding: 0 12px;
 background: var(--n-toolbar-color);
 box-shadow: var(--n-toolbar-box-shadow);
 color: var(--n-toolbar-icon-color);
 transition: color .3s var(--n-bezier);
 display: flex;
 align-items: center;
 `,[h("base-icon",`
 padding: 0 8px;
 font-size: 28px;
 cursor: pointer;
 `),_e()]),h("image-preview-wrapper",`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 display: flex;
 pointer-events: none;
 `,[Gt()]),h("image-preview",`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: all;
 margin: auto;
 max-height: calc(100vh - 32px);
 max-width: calc(100vw - 32px);
 transition: transform .3s var(--n-bezier);
 `),h("image",`
 display: inline-flex;
 max-height: 100%;
 max-width: 100%;
 `,[$t("preview-disabled",`
 cursor: pointer;
 `),N("img",`
 border-radius: inherit;
 `)])]),he=32,mt=V({name:"ImagePreview",props:Object.assign(Object.assign({},ze),{onNext:Function,onPrev:Function,clsPrefix:{type:String,required:!0}}),setup(e){const o=oe("Image","-image",co,lo,e,U(e,"clsPrefix"));let r=null;const i=W(null),n=W(null),s=W(void 0),u=W(!1),c=W(!1),{localeRef:d}=er("Image");function l(){const{value:g}=n;if(!r||!g)return;const{style:x}=g,p=r.getBoundingClientRect(),D=p.left+p.width/2,M=p.top+p.height/2;x.transformOrigin=`${D}px ${M}px`}function a(g){var x,p;switch(g.key){case" ":g.preventDefault();break;case"ArrowLeft":(x=e.onPrev)===null||x===void 0||x.call(e);break;case"ArrowRight":(p=e.onNext)===null||p===void 0||p.call(e);break;case"Escape":Be();break}}Ot(u,g=>{g?Se("keydown",document,a):ge("keydown",document,a)}),Ye(()=>{ge("keydown",document,a)});let f=0,w=0,v=0,C=0,y=0,I=0,z=0,k=0,H=!1;function $(g){const{clientX:x,clientY:p}=g;v=x-f,C=p-w,or(K)}function m(g){const{mouseUpClientX:x,mouseUpClientY:p,mouseDownClientX:D,mouseDownClientY:M}=g,X=D-x,G=M-p,J=`vertical${G>0?"Top":"Bottom"}`,re=`horizontal${X>0?"Left":"Right"}`;return{moveVerticalDirection:J,moveHorizontalDirection:re,deltaHorizontal:X,deltaVertical:G}}function R(g){const{value:x}=i;if(!x)return{offsetX:0,offsetY:0};const p=x.getBoundingClientRect(),{moveVerticalDirection:D,moveHorizontalDirection:M,deltaHorizontal:X,deltaVertical:G}=g||{};let J=0,re=0;return p.width<=window.innerWidth?J=0:p.left>0?J=(p.width-window.innerWidth)/2:p.right<window.innerWidth?J=-(p.width-window.innerWidth)/2:M==="horizontalRight"?J=Math.min((p.width-window.innerWidth)/2,y-(X??0)):J=Math.max(-((p.width-window.innerWidth)/2),y-(X??0)),p.height<=window.innerHeight?re=0:p.top>0?re=(p.height-window.innerHeight)/2:p.bottom<window.innerHeight?re=-(p.height-window.innerHeight)/2:D==="verticalBottom"?re=Math.min((p.height-window.innerHeight)/2,I-(G??0)):re=Math.max(-((p.height-window.innerHeight)/2),I-(G??0)),{offsetX:J,offsetY:re}}function S(g){ge("mousemove",document,$),ge("mouseup",document,S);const{clientX:x,clientY:p}=g;H=!1;const D=m({mouseUpClientX:x,mouseUpClientY:p,mouseDownClientX:z,mouseDownClientY:k}),M=R(D);v=M.offsetX,C=M.offsetY,K()}const _=ie(vt,null);function b(g){var x,p;if((p=(x=_==null?void 0:_.previewedImgPropsRef.value)===null||x===void 0?void 0:x.onMousedown)===null||p===void 0||p.call(x,g),g.button!==0)return;const{clientX:D,clientY:M}=g;H=!0,f=D-v,w=M-C,y=v,I=C,z=D,k=M,K(),Se("mousemove",document,$),Se("mouseup",document,S)}const B=1.5;let T=0,O=1,E=0;function Z(g){var x,p;(p=(x=_==null?void 0:_.previewedImgPropsRef.value)===null||x===void 0?void 0:x.onDblclick)===null||p===void 0||p.call(x,g);const D=ce();O=O===D?1:D,K()}function A(){O=1,T=0}function F(){var g;A(),E=0,(g=e.onPrev)===null||g===void 0||g.call(e)}function Y(){var g;A(),E=0,(g=e.onNext)===null||g===void 0||g.call(e)}function q(){E-=90,K()}function ee(){E+=90,K()}function we(){const{value:g}=i;if(!g)return 1;const{innerWidth:x,innerHeight:p}=window,D=Math.max(1,g.naturalHeight/(p-he)),M=Math.max(1,g.naturalWidth/(x-he));return Math.max(3,D*2,M*2)}function ce(){const{value:g}=i;if(!g)return 1;const{innerWidth:x,innerHeight:p}=window,D=g.naturalHeight/(p-he),M=g.naturalWidth/(x-he);return D<1&&M<1?1:Math.max(D,M)}function xe(){const g=we();O<g&&(T+=1,O=Math.min(g,Math.pow(B,T)),K())}function ye(){if(O>.5){const g=O;T-=1,O=Math.max(.5,Math.pow(B,T));const x=g-O;K(!1);const p=R();O+=x,K(!1),O-=x,v=p.offsetX,C=p.offsetY,K()}}function Ce(){const g=s.value;g&&tt(g,void 0)}function K(g=!0){var x;const{value:p}=i;if(!p)return;const{style:D}=p,M=It((x=_==null?void 0:_.previewedImgPropsRef.value)===null||x===void 0?void 0:x.style);let X="";if(typeof M=="string")X=`${M};`;else for(const J in M)X+=`${qr(J)}: ${M[J]};`;const G=`transform-origin: center; transform: translateX(${v}px) translateY(${C}px) rotate(${E}deg) scale(${O});`;H?D.cssText=`${X}cursor: grabbing; transition: none;${G}`:D.cssText=`${X}cursor: grab;${G}${g?"":"transition: none;"}`,g||p.offsetHeight}function Be(){u.value=!u.value,c.value=!0}function St(){O=ce(),T=Math.ceil(Math.log(O)/Math.log(B)),v=0,C=0,K()}const kt={setPreviewSrc:g=>{s.value=g},setThumbnailEl:g=>{r=g},toggleShow:Be};function Pt(g,x){if(e.showToolbarTooltip){const{value:p}=o;return t(rr,{to:!1,theme:p.peers.Tooltip,themeOverrides:p.peerOverrides.Tooltip,keepAliveOnHover:!1},{default:()=>d.value[x],trigger:()=>g})}else return g}const Ie=L(()=>{const{common:{cubicBezierEaseInOut:g},self:{toolbarIconColor:x,toolbarBorderRadius:p,toolbarBoxShadow:D,toolbarColor:M}}=o.value;return{"--n-bezier":g,"--n-toolbar-icon-color":x,"--n-toolbar-color":M,"--n-toolbar-border-radius":p,"--n-toolbar-box-shadow":D}}),{inlineThemeDisabled:De}=se(),ne=De?me("image-preview",void 0,Ie,e):void 0;return Object.assign({previewRef:i,previewWrapperRef:n,previewSrc:s,show:u,appear:zt(),displayed:c,previewedImgProps:_==null?void 0:_.previewedImgPropsRef,handleWheel(g){g.preventDefault()},handlePreviewMousedown:b,handlePreviewDblclick:Z,syncTransformOrigin:l,handleAfterLeave:()=>{A(),E=0,c.value=!1},handleDragStart:g=>{var x,p;(p=(x=_==null?void 0:_.previewedImgPropsRef.value)===null||x===void 0?void 0:x.onDragstart)===null||p===void 0||p.call(x,g),g.preventDefault()},zoomIn:xe,zoomOut:ye,handleDownloadClick:Ce,rotateCounterclockwise:q,rotateClockwise:ee,handleSwitchPrev:F,handleSwitchNext:Y,withTooltip:Pt,resizeToOrignalImageSize:St,cssVars:De?void 0:Ie,themeClass:ne==null?void 0:ne.themeClass,onRender:ne==null?void 0:ne.onRender},kt)},render(){var e,o;const{clsPrefix:r,renderToolbar:i,withTooltip:n}=this,s=n(t(j,{clsPrefix:r,onClick:this.handleSwitchPrev},{default:()=>ao}),"tipPrevious"),u=n(t(j,{clsPrefix:r,onClick:this.handleSwitchNext},{default:()=>so}),"tipNext"),c=n(t(j,{clsPrefix:r,onClick:this.rotateCounterclockwise},{default:()=>t(to,null)}),"tipCounterclockwise"),d=n(t(j,{clsPrefix:r,onClick:this.rotateClockwise},{default:()=>t(eo,null)}),"tipClockwise"),l=n(t(j,{clsPrefix:r,onClick:this.resizeToOrignalImageSize},{default:()=>t(io,null)}),"tipOriginalSize"),a=n(t(j,{clsPrefix:r,onClick:this.zoomOut},{default:()=>t(oo,null)}),"tipZoomOut"),f=n(t(j,{clsPrefix:r,onClick:this.handleDownloadClick},{default:()=>t(pt,null)}),"tipDownload"),w=n(t(j,{clsPrefix:r,onClick:this.toggleShow},{default:()=>uo}),"tipClose"),v=n(t(j,{clsPrefix:r,onClick:this.zoomIn},{default:()=>t(ro,null)}),"tipZoomIn");return t(ve,null,(o=(e=this.$slots).default)===null||o===void 0?void 0:o.call(e),t(Kt,{show:this.show},{default:()=>{var C;return this.show||this.displayed?((C=this.onRender)===null||C===void 0||C.call(this),Me(t("div",{class:[`${r}-image-preview-container`,this.themeClass],style:this.cssVars,onWheel:this.handleWheel},t(Re,{name:"fade-in-transition",appear:this.appear},{default:()=>this.show?t("div",{class:`${r}-image-preview-overlay`,onClick:this.toggleShow}):null}),this.showToolbar?t(Re,{name:"fade-in-transition",appear:this.appear},{default:()=>this.show?t("div",{class:`${r}-image-preview-toolbar`},i?i({nodes:{prev:s,next:u,rotateCounterclockwise:c,rotateClockwise:d,resizeToOriginalSize:l,zoomOut:a,zoomIn:v,download:f,close:w}}):t(ve,null,this.onPrev?t(ve,null,s,u):null,c,d,l,a,v,f,w)):null}):null,t(Re,{name:"fade-in-scale-up-transition",onAfterLeave:this.handleAfterLeave,appear:this.appear,onEnter:this.syncTransformOrigin,onBeforeLeave:this.syncTransformOrigin},{default:()=>{const{previewedImgProps:y={}}=this;return Me(t("div",{class:`${r}-image-preview-wrapper`,ref:"previewWrapperRef"},t("img",Object.assign({},y,{draggable:!1,onMousedown:this.handlePreviewMousedown,onDblclick:this.handlePreviewDblclick,class:[`${r}-image-preview`,y.class],key:this.previewSrc,src:this.previewSrc,ref:"previewRef",onDragstart:this.handleDragStart}))),[[Bt,this.show]])}})),[[Jt,{enabled:this.show}]])):null}}))}}),bt=$e("n-image-group"),fo=ze,go=V({name:"ImageGroup",props:fo,setup(e){let o;const{mergedClsPrefixRef:r}=se(e),i=`c${Te()}`,n=Dt(),s=W(null),u=d=>{var l;o=d,(l=s.value)===null||l===void 0||l.setPreviewSrc(d)};function c(d){var l,a;if(!(n!=null&&n.proxy))return;const w=n.proxy.$el.parentElement.querySelectorAll(`[data-group-id=${i}]:not([data-error=true])`);if(!w.length)return;const v=Array.from(w).findIndex(C=>C.dataset.previewSrc===o);~v?u(w[(v+d+w.length)%w.length].dataset.previewSrc):u(w[0].dataset.previewSrc),d===1?(l=e.onPreviewNext)===null||l===void 0||l.call(e):(a=e.onPreviewPrev)===null||a===void 0||a.call(e)}return Oe(bt,{mergedClsPrefixRef:r,setPreviewSrc:u,setThumbnailEl:d=>{var l;(l=s.value)===null||l===void 0||l.setThumbnailEl(d)},toggleShow:()=>{var d;(d=s.value)===null||d===void 0||d.toggleShow()},groupId:i,renderToolbarRef:U(e,"renderToolbar")}),{mergedClsPrefix:r,previewInstRef:s,next:()=>{c(1)},prev:()=>{c(-1)}}},render(){return t(mt,{theme:this.theme,themeOverrides:this.themeOverrides,clsPrefix:this.mergedClsPrefix,ref:"previewInstRef",onPrev:this.prev,onNext:this.next,showToolbar:this.showToolbar,showToolbarTooltip:this.showToolbarTooltip,renderToolbar:this.renderToolbar},this.$slots)}}),ho=Object.assign({alt:String,height:[String,Number],imgProps:Object,previewedImgProps:Object,lazy:Boolean,intersectionObserverOptions:Object,objectFit:{type:String,default:"fill"},previewSrc:String,fallbackSrc:String,width:[String,Number],src:String,previewDisabled:Boolean,loadDescription:String,onError:Function,onLoad:Function},ze),po=V({name:"Image",props:ho,inheritAttrs:!1,setup(e){const o=W(null),r=W(!1),i=W(null),n=ie(bt,null),{mergedClsPrefixRef:s}=n||se(e),u={click:()=>{if(e.previewDisabled||r.value)return;const l=e.previewSrc||e.src;if(n){n.setPreviewSrc(l),n.setThumbnailEl(o.value),n.toggleShow();return}const{value:a}=i;a&&(a.setPreviewSrc(l),a.setThumbnailEl(o.value),a.toggleShow())}},c=W(!e.lazy);Ue(()=>{var l;(l=o.value)===null||l===void 0||l.setAttribute("data-group-id",(n==null?void 0:n.groupId)||"")}),Ue(()=>{if(e.lazy&&e.intersectionObserverOptions){let l;const a=ke(()=>{l==null||l(),l=void 0,l=qt(o.value,e.intersectionObserverOptions,c)});Ye(()=>{a(),l==null||l()})}}),ke(()=>{var l;e.src||((l=e.imgProps)===null||l===void 0||l.src),r.value=!1});const d=W(!1);return Oe(vt,{previewedImgPropsRef:U(e,"previewedImgProps")}),Object.assign({mergedClsPrefix:s,groupId:n==null?void 0:n.groupId,previewInstRef:i,imageRef:o,showError:r,shouldStartLoading:c,loaded:d,mergedOnClick:l=>{var a,f;u.click(),(f=(a=e.imgProps)===null||a===void 0?void 0:a.onClick)===null||f===void 0||f.call(a,l)},mergedOnError:l=>{if(!c.value)return;r.value=!0;const{onError:a,imgProps:{onError:f}={}}=e;a==null||a(l),f==null||f(l)},mergedOnLoad:l=>{const{onLoad:a,imgProps:{onLoad:f}={}}=e;a==null||a(l),f==null||f(l),d.value=!0}},u)},render(){var e,o;const{mergedClsPrefix:r,imgProps:i={},loaded:n,$attrs:s,lazy:u}=this,c=(o=(e=this.$slots).placeholder)===null||o===void 0?void 0:o.call(e),d=this.src||i.src,l=t("img",Object.assign(Object.assign({},i),{ref:"imageRef",width:this.width||i.width,height:this.height||i.height,src:this.showError?this.fallbackSrc:u&&this.intersectionObserverOptions?this.shouldStartLoading?d:void 0:d,alt:this.alt||i.alt,"aria-label":this.alt||i.alt,onClick:this.mergedOnClick,onError:this.mergedOnError,onLoad:this.mergedOnLoad,loading:Yt&&u&&!this.intersectionObserverOptions?"lazy":"eager",style:[i.style||"",c&&!n?{height:"0",width:"0",visibility:"hidden"}:"",{objectFit:this.objectFit}],"data-error":this.showError,"data-preview-src":this.previewSrc||this.src}));return t("div",Object.assign({},s,{role:"none",class:[s.class,`${r}-image`,(this.previewDisabled||this.showError)&&`${r}-image--preview-disabled`]}),this.groupId?l:t(mt,{theme:this.theme,themeOverrides:this.themeOverrides,clsPrefix:r,ref:"previewInstRef",showToolbar:this.showToolbar,showToolbarTooltip:this.showToolbarTooltip,renderToolbar:this.renderToolbar},{default:()=>l,toolbar:()=>{var a,f;return(f=(a=this.$slots).toolbar)===null||f===void 0?void 0:f.call(a)}}),!n&&c)}}),vo=N([h("progress",{display:"inline-block"},[h("progress-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),P("line",`
 width: 100%;
 display: block;
 `,[h("progress-content",`
 display: flex;
 align-items: center;
 `,[h("progress-graph",{flex:1})]),h("progress-custom-content",{marginLeft:"14px"}),h("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[P("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),P("circle, dashboard",{width:"120px"},[h("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),h("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),h("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),P("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[h("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),h("progress-content",{position:"relative"}),h("progress-graph",{position:"relative"},[h("progress-graph-circle",[N("svg",{verticalAlign:"bottom"}),h("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[P("empty",{opacity:0})]),h("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),h("progress-graph-line",[P("indicator-inside",[h("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[h("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),h("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),P("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[h("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),h("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),h("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[h("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[P("processing",[N("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),N("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),mo={success:t(Ge,null),error:t(Ke,null),warning:t(Je,null),info:t(Qe,null)},bo=V({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:o}){const r=L(()=>le(e.height)),i=L(()=>e.railBorderRadius!==void 0?le(e.railBorderRadius):e.height!==void 0?le(e.height,{c:.5}):""),n=L(()=>e.fillBorderRadius!==void 0?le(e.fillBorderRadius):e.railBorderRadius!==void 0?le(e.railBorderRadius):e.height!==void 0?le(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:s,railColor:u,railStyle:c,percentage:d,unit:l,indicatorTextColor:a,status:f,showIndicator:w,fillColor:v,processing:C,clsPrefix:y}=e;return t("div",{class:`${y}-progress-content`,role:"none"},t("div",{class:`${y}-progress-graph`,"aria-hidden":!0},t("div",{class:[`${y}-progress-graph-line`,{[`${y}-progress-graph-line--indicator-${s}`]:!0}]},t("div",{class:`${y}-progress-graph-line-rail`,style:[{backgroundColor:u,height:r.value,borderRadius:i.value},c]},t("div",{class:[`${y}-progress-graph-line-fill`,C&&`${y}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:v,height:r.value,lineHeight:r.value,borderRadius:n.value}},s==="inside"?t("div",{class:`${y}-progress-graph-line-indicator`,style:{color:a}},o.default?o.default():`${d}${l}`):null)))),w&&s==="outside"?t("div",null,o.default?t("div",{class:`${y}-progress-custom-content`,style:{color:a},role:"none"},o.default()):f==="default"?t("div",{role:"none",class:`${y}-progress-icon ${y}-progress-icon--as-text`,style:{color:a}},d,l):t("div",{class:`${y}-progress-icon`,"aria-hidden":!0},t(j,{clsPrefix:y},{default:()=>mo[f]}))):null)}}}),wo={success:t(Ge,null),error:t(Ke,null),warning:t(Je,null),info:t(Qe,null)},xo=V({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:o}){function r(i,n,s){const{gapDegree:u,viewBoxWidth:c,strokeWidth:d}=e,l=50,a=0,f=l,w=0,v=2*l,C=50+d/2,y=`M ${C},${C} m ${a},${f}
      a ${l},${l} 0 1 1 ${w},${-v}
      a ${l},${l} 0 1 1 ${-w},${v}`,I=Math.PI*2*l,z={stroke:s,strokeDasharray:`${i/100*(I-u)}px ${c*8}px`,strokeDashoffset:`-${u/2}px`,transformOrigin:n?"center":void 0,transform:n?`rotate(${n}deg)`:void 0};return{pathString:y,pathStyle:z}}return()=>{const{fillColor:i,railColor:n,strokeWidth:s,offsetDegree:u,status:c,percentage:d,showIndicator:l,indicatorTextColor:a,unit:f,gapOffsetDegree:w,clsPrefix:v}=e,{pathString:C,pathStyle:y}=r(100,0,n),{pathString:I,pathStyle:z}=r(d,u,i),k=100+s;return t("div",{class:`${v}-progress-content`,role:"none"},t("div",{class:`${v}-progress-graph`,"aria-hidden":!0},t("div",{class:`${v}-progress-graph-circle`,style:{transform:w?`rotate(${w}deg)`:void 0}},t("svg",{viewBox:`0 0 ${k} ${k}`},t("g",null,t("path",{class:`${v}-progress-graph-circle-rail`,d:C,"stroke-width":s,"stroke-linecap":"round",fill:"none",style:y})),t("g",null,t("path",{class:[`${v}-progress-graph-circle-fill`,d===0&&`${v}-progress-graph-circle-fill--empty`],d:I,"stroke-width":s,"stroke-linecap":"round",fill:"none",style:z}))))),l?t("div",null,o.default?t("div",{class:`${v}-progress-custom-content`,role:"none"},o.default()):c!=="default"?t("div",{class:`${v}-progress-icon`,"aria-hidden":!0},t(j,{clsPrefix:v},{default:()=>wo[c]})):t("div",{class:`${v}-progress-text`,style:{color:a},role:"none"},t("span",{class:`${v}-progress-text__percentage`},d),t("span",{class:`${v}-progress-text__unit`},f))):null)}}});function We(e,o,r=100){return`m ${r/2} ${r/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const yo=V({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:o}){const r=L(()=>e.percentage.map((n,s)=>`${Math.PI*n/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*s)-e.circleGap*s)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:i,strokeWidth:n,circleGap:s,showIndicator:u,fillColor:c,railColor:d,railStyle:l,percentage:a,clsPrefix:f}=e;return t("div",{class:`${f}-progress-content`,role:"none"},t("div",{class:`${f}-progress-graph`,"aria-hidden":!0},t("div",{class:`${f}-progress-graph-circle`},t("svg",{viewBox:`0 0 ${i} ${i}`},a.map((w,v)=>t("g",{key:v},t("path",{class:`${f}-progress-graph-circle-rail`,d:We(i/2-n/2*(1+2*v)-s*v,n,i),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:d[v]},l[v]]}),t("path",{class:[`${f}-progress-graph-circle-fill`,w===0&&`${f}-progress-graph-circle-fill--empty`],d:We(i/2-n/2*(1+2*v)-s*v,n,i),"stroke-width":n,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:r.value[v],strokeDashoffset:0,stroke:c[v]}})))))),u&&o.default?t("div",null,t("div",{class:`${f}-progress-text`},o.default())):null)}}}),Co=Object.assign(Object.assign({},oe.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),Ro=V({name:"Progress",props:Co,setup(e){const o=L(()=>e.indicatorPlacement||e.indicatorPosition),r=L(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:i,inlineThemeDisabled:n}=se(e),s=oe("Progress","-progress",vo,Wt,e,i),u=L(()=>{const{status:d}=e,{common:{cubicBezierEaseInOut:l},self:{fontSize:a,fontSizeCircle:f,railColor:w,railHeight:v,iconSizeCircle:C,iconSizeLine:y,textColorCircle:I,textColorLineInner:z,textColorLineOuter:k,lineBgProcessing:H,fontWeightCircle:$,[Pe("iconColor",d)]:m,[Pe("fillColor",d)]:R}}=s.value;return{"--n-bezier":l,"--n-fill-color":R,"--n-font-size":a,"--n-font-size-circle":f,"--n-font-weight-circle":$,"--n-icon-color":m,"--n-icon-size-circle":C,"--n-icon-size-line":y,"--n-line-bg-processing":H,"--n-rail-color":w,"--n-rail-height":v,"--n-text-color-circle":I,"--n-text-color-line-inner":z,"--n-text-color-line-outer":k}}),c=n?me("progress",L(()=>e.status[0]),u,e):void 0;return{mergedClsPrefix:i,mergedIndicatorPlacement:o,gapDeg:r,cssVars:n?void 0:u,themeClass:c==null?void 0:c.themeClass,onRender:c==null?void 0:c.onRender}},render(){const{type:e,cssVars:o,indicatorTextColor:r,showIndicator:i,status:n,railColor:s,railStyle:u,color:c,percentage:d,viewBoxWidth:l,strokeWidth:a,mergedIndicatorPlacement:f,unit:w,borderRadius:v,fillBorderRadius:C,height:y,processing:I,circleGap:z,mergedClsPrefix:k,gapDeg:H,gapOffsetDegree:$,themeClass:m,$slots:R,onRender:S}=this;return S==null||S(),t("div",{class:[m,`${k}-progress`,`${k}-progress--${e}`,`${k}-progress--${n}`],style:o,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":d,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?t(xo,{clsPrefix:k,status:n,showIndicator:i,indicatorTextColor:r,railColor:s,fillColor:c,railStyle:u,offsetDegree:this.offsetDegree,percentage:d,viewBoxWidth:l,strokeWidth:a,gapDegree:H===void 0?e==="dashboard"?75:0:H,gapOffsetDegree:$,unit:w},R):e==="line"?t(bo,{clsPrefix:k,status:n,showIndicator:i,indicatorTextColor:r,railColor:s,fillColor:c,railStyle:u,percentage:d,processing:I,indicatorPlacement:f,unit:w,fillBorderRadius:C,railBorderRadius:v,height:y},R):e==="multiple-circle"?t(yo,{clsPrefix:k,strokeWidth:a,railColor:s,fillColor:c,railStyle:u,viewBoxWidth:l,percentage:d,showIndicator:i,circleGap:z},R):null)}}),So=h("text",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
`,[P("strong",`
 font-weight: var(--n-font-weight-strong);
 `),P("italic",{fontStyle:"italic"}),P("underline",{textDecoration:"underline"}),P("code",`
 line-height: 1.4;
 display: inline-block;
 font-family: var(--n-font-famliy-mono);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 box-sizing: border-box;
 padding: .05em .35em 0 .35em;
 border-radius: var(--n-code-border-radius);
 font-size: .9em;
 color: var(--n-code-text-color);
 background-color: var(--n-code-color);
 border: var(--n-code-border);
 `)]),ko=Object.assign(Object.assign({},oe.props),{code:Boolean,type:{type:String,default:"default"},delete:Boolean,strong:Boolean,italic:Boolean,underline:Boolean,depth:[String,Number],tag:String,as:{type:String,validator:()=>!0,default:void 0}}),ni=V({name:"Text",props:ko,setup(e){const{mergedClsPrefixRef:o,inlineThemeDisabled:r}=se(e),i=oe("Typography","-text",So,Vt,e,o),n=L(()=>{const{depth:u,type:c}=e,d=c==="default"?u===void 0?"textColor":`textColor${u}Depth`:Pe("textColor",c),{common:{fontWeightStrong:l,fontFamilyMono:a,cubicBezierEaseInOut:f},self:{codeTextColor:w,codeBorderRadius:v,codeColor:C,codeBorder:y,[d]:I}}=i.value;return{"--n-bezier":f,"--n-text-color":I,"--n-font-weight-strong":l,"--n-font-famliy-mono":a,"--n-code-border-radius":v,"--n-code-text-color":w,"--n-code-color":C,"--n-code-border":y}}),s=r?me("text",L(()=>`${e.type[0]}${e.depth||""}`),n,e):void 0;return{mergedClsPrefix:o,compitableTag:Xt(e,["as","tag"]),cssVars:r?void 0:n,themeClass:s==null?void 0:s.themeClass,onRender:s==null?void 0:s.onRender}},render(){var e,o,r;const{mergedClsPrefix:i}=this;(e=this.onRender)===null||e===void 0||e.call(this);const n=[`${i}-text`,this.themeClass,{[`${i}-text--code`]:this.code,[`${i}-text--delete`]:this.delete,[`${i}-text--strong`]:this.strong,[`${i}-text--italic`]:this.italic,[`${i}-text--underline`]:this.underline}],s=(r=(o=this.$slots).default)===null||r===void 0?void 0:r.call(o);return this.code?t("code",{class:n,style:this.cssVars},this.delete?t("del",null,s):s):this.delete?t("del",{class:n,style:this.cssVars},s):t(this.compitableTag||"span",{class:n,style:this.cssVars},s)}}),de=$e("n-upload"),wt="__UPLOAD_DRAGGER__",Po=V({name:"UploadDragger",[wt]:!0,setup(e,{slots:o}){const r=ie(de,null);return r||be("upload-dragger","`n-upload-dragger` must be placed inside `n-upload`."),()=>{const{mergedClsPrefixRef:{value:i},mergedDisabledRef:{value:n},maxReachedRef:{value:s}}=r;return t("div",{class:[`${i}-upload-dragger`,(n||s)&&`${i}-upload-dragger--disabled`]},o)}}});var Le=function(e,o,r,i){function n(s){return s instanceof r?s:new r(function(u){u(s)})}return new(r||(r=Promise))(function(s,u){function c(a){try{l(i.next(a))}catch(f){u(f)}}function d(a){try{l(i.throw(a))}catch(f){u(f)}}function l(a){a.done?s(a.value):n(a.value).then(c,d)}l((i=i.apply(e,o||[])).next())})};function xt(e){return e.includes("image/")}function Ve(e=""){const o=e.split("/"),i=o[o.length-1].split(/#|\?/)[0];return(/\.[^./\\]*$/.exec(i)||[""])[0]}const Ze=/(webp|svg|png|gif|jpg|jpeg|jfif|bmp|dpg|ico)$/i,yt=e=>{if(e.type)return xt(e.type);const o=Ve(e.name||"");if(Ze.test(o))return!0;const r=e.thumbnailUrl||e.url||"",i=Ve(r);return!!(/^data:image\//.test(r)||Ze.test(i))};function To(e){return Le(this,void 0,void 0,function*(){return yield new Promise(o=>{if(!e.type||!xt(e.type)){o("");return}o(window.URL.createObjectURL(e))})})}const Lo=Mt&&window.FileReader&&window.File;function $o(e){return e.isDirectory}function Oo(e){return e.isFile}function zo(e,o){return Le(this,void 0,void 0,function*(){const r=[];function i(n){return Le(this,void 0,void 0,function*(){for(const s of n)if(s){if(o&&$o(s)){const u=s.createReader();try{const c=yield new Promise((d,l)=>{u.readEntries(d,l)});yield i(c)}catch{}}else if(Oo(s))try{const u=yield new Promise((c,d)=>{s.file(c,d)});r.push({file:u,entry:s,source:"dnd"})}catch{}}})}return yield i(e),r})}function ue(e){const{id:o,name:r,percentage:i,status:n,url:s,file:u,thumbnailUrl:c,type:d,fullPath:l,batchId:a}=e;return{id:o,name:r,percentage:i??null,status:n,url:s??null,file:u??null,thumbnailUrl:c??null,type:d??null,fullPath:l??null,batchId:a??null}}function Bo(e,o,r){return e=e.toLowerCase(),o=o.toLocaleLowerCase(),r=r.toLocaleLowerCase(),r.split(",").map(n=>n.trim()).filter(Boolean).some(n=>{if(n.startsWith(".")){if(e.endsWith(n))return!0}else if(n.includes("/")){const[s,u]=o.split("/"),[c,d]=n.split("/");if((c==="*"||s&&c&&c===s)&&(d==="*"||u&&d&&d===u))return!0}else return!0;return!1})}const Ct=V({name:"UploadTrigger",props:{abstract:Boolean},setup(e,{slots:o}){const r=ie(de,null);r||be("upload-trigger","`n-upload-trigger` must be placed inside `n-upload`.");const{mergedClsPrefixRef:i,mergedDisabledRef:n,maxReachedRef:s,listTypeRef:u,dragOverRef:c,openOpenFileDialog:d,draggerInsideRef:l,handleFileAddition:a,mergedDirectoryDndRef:f,triggerClassRef:w,triggerStyleRef:v}=r,C=L(()=>u.value==="image-card");function y(){n.value||s.value||d()}function I($){$.preventDefault(),c.value=!0}function z($){$.preventDefault(),c.value=!0}function k($){$.preventDefault(),c.value=!1}function H($){var m;if($.preventDefault(),!l.value||n.value||s.value){c.value=!1;return}const R=(m=$.dataTransfer)===null||m===void 0?void 0:m.items;R!=null&&R.length?zo(Array.from(R).map(S=>S.webkitGetAsEntry()),f.value).then(S=>{a(S)}).finally(()=>{c.value=!1}):c.value=!1}return()=>{var $;const{value:m}=i;return e.abstract?($=o.default)===null||$===void 0?void 0:$.call(o,{handleClick:y,handleDrop:H,handleDragOver:I,handleDragEnter:z,handleDragLeave:k}):t("div",{class:[`${m}-upload-trigger`,(n.value||s.value)&&`${m}-upload-trigger--disabled`,C.value&&`${m}-upload-trigger--image-card`,w.value],style:v.value,onClick:y,onDrop:H,onDragover:I,onDragenter:z,onDragleave:k},C.value?t(Po,null,{default:()=>Ut(o.default,()=>[t(j,{clsPrefix:m},{default:()=>t(Yr,null)})])}):o)}}}),Io=V({name:"UploadProgress",props:{show:Boolean,percentage:{type:Number,required:!0},status:{type:String,required:!0}},setup(){return{mergedTheme:ie(de).mergedThemeRef}},render(){return t(et,null,{default:()=>this.show?t(Ro,{type:"line",showIndicator:!1,percentage:this.percentage,status:this.status,height:2,theme:this.mergedTheme.peers.Progress,themeOverrides:this.mergedTheme.peerOverrides.Progress}):null})}}),Do=t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},t("g",{fill:"none"},t("path",{d:"M21.75 3A3.25 3.25 0 0 1 25 6.25v15.5A3.25 3.25 0 0 1 21.75 25H6.25A3.25 3.25 0 0 1 3 21.75V6.25A3.25 3.25 0 0 1 6.25 3h15.5zm.583 20.4l-7.807-7.68a.75.75 0 0 0-.968-.07l-.084.07l-7.808 7.68c.183.065.38.1.584.1h15.5c.204 0 .4-.035.583-.1l-7.807-7.68l7.807 7.68zM21.75 4.5H6.25A1.75 1.75 0 0 0 4.5 6.25v15.5c0 .208.036.408.103.593l7.82-7.692a2.25 2.25 0 0 1 3.026-.117l.129.117l7.82 7.692c.066-.185.102-.385.102-.593V6.25a1.75 1.75 0 0 0-1.75-1.75zm-3.25 3a2.5 2.5 0 1 1 0 5a2.5 2.5 0 0 1 0-5zm0 1.5a1 1 0 1 0 0 2a1 1 0 0 0 0-2z",fill:"currentColor"}))),Mo=t("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 28 28"},t("g",{fill:"none"},t("path",{d:"M6.4 2A2.4 2.4 0 0 0 4 4.4v19.2A2.4 2.4 0 0 0 6.4 26h15.2a2.4 2.4 0 0 0 2.4-2.4V11.578c0-.729-.29-1.428-.805-1.944l-6.931-6.931A2.4 2.4 0 0 0 14.567 2H6.4zm-.9 2.4a.9.9 0 0 1 .9-.9H14V10a2 2 0 0 0 2 2h6.5v11.6a.9.9 0 0 1-.9.9H6.4a.9.9 0 0 1-.9-.9V4.4zm16.44 6.1H16a.5.5 0 0 1-.5-.5V4.06l6.44 6.44z",fill:"currentColor"})));var Uo=function(e,o,r,i){function n(s){return s instanceof r?s:new r(function(u){u(s)})}return new(r||(r=Promise))(function(s,u){function c(a){try{l(i.next(a))}catch(f){u(f)}}function d(a){try{l(i.throw(a))}catch(f){u(f)}}function l(a){a.done?s(a.value):n(a.value).then(c,d)}l((i=i.apply(e,o||[])).next())})};const pe={paddingMedium:"0 3px",heightMedium:"24px",iconSizeMedium:"18px"},Fo=V({name:"UploadFile",props:{clsPrefix:{type:String,required:!0},file:{type:Object,required:!0},listType:{type:String,required:!0},index:{type:Number,required:!0}},setup(e){const o=ie(de),r=W(null),i=W(""),n=L(()=>{const{file:m}=e;return m.status==="finished"?"success":m.status==="error"?"error":"info"}),s=L(()=>{const{file:m}=e;if(m.status==="error")return"error"}),u=L(()=>{const{file:m}=e;return m.status==="uploading"}),c=L(()=>{if(!o.showCancelButtonRef.value)return!1;const{file:m}=e;return["uploading","pending","error"].includes(m.status)}),d=L(()=>{if(!o.showRemoveButtonRef.value)return!1;const{file:m}=e;return["finished"].includes(m.status)}),l=L(()=>{if(!o.showDownloadButtonRef.value)return!1;const{file:m}=e;return["finished"].includes(m.status)}),a=L(()=>{if(!o.showRetryButtonRef.value)return!1;const{file:m}=e;return["error"].includes(m.status)}),f=Ft(()=>i.value||e.file.thumbnailUrl||e.file.url),w=L(()=>{if(!o.showPreviewButtonRef.value)return!1;const{file:{status:m},listType:R}=e;return["finished"].includes(m)&&f.value&&R==="image-card"});function v(){o.submit(e.file.id)}function C(m){m.preventDefault();const{file:R}=e;["finished","pending","error"].includes(R.status)?I(R):["uploading"].includes(R.status)?k(R):_t("upload","The button clicked type is unknown.")}function y(m){m.preventDefault(),z(e.file)}function I(m){const{xhrMap:R,doChange:S,onRemoveRef:{value:_},mergedFileListRef:{value:b}}=o;Promise.resolve(_?_({file:Object.assign({},m),fileList:b,index:e.index}):!0).then(B=>{if(B===!1)return;const T=Object.assign({},m,{status:"removed"});R.delete(m.id),S(T,void 0,{remove:!0})})}function z(m){const{onDownloadRef:{value:R}}=o;Promise.resolve(R?R(Object.assign({},m)):!0).then(S=>{S!==!1&&tt(m.url,m.name)})}function k(m){const{xhrMap:R}=o,S=R.get(m.id);S==null||S.abort(),I(Object.assign({},m))}function H(m){const{onPreviewRef:{value:R}}=o;if(R)R(e.file,{event:m});else if(e.listType==="image-card"){const{value:S}=r;if(!S)return;S.click()}}const $=()=>Uo(this,void 0,void 0,function*(){const{listType:m}=e;m!=="image"&&m!=="image-card"||o.shouldUseThumbnailUrlRef.value(e.file)&&(i.value=yield o.getFileThumbnailUrlResolver(e.file))});return ke(()=>{$()}),{mergedTheme:o.mergedThemeRef,progressStatus:n,buttonType:s,showProgress:u,disabled:o.mergedDisabledRef,showCancelButton:c,showRemoveButton:d,showDownloadButton:l,showRetryButton:a,showPreviewButton:w,mergedThumbnailUrl:f,shouldUseThumbnailUrl:o.shouldUseThumbnailUrlRef,renderIcon:o.renderIconRef,imageRef:r,handleRemoveOrCancelClick:C,handleDownloadClick:y,handleRetryClick:v,handlePreviewClick:H}},render(){const{clsPrefix:e,mergedTheme:o,listType:r,file:i,renderIcon:n}=this;let s;const u=r==="image";u||r==="image-card"?s=!this.shouldUseThumbnailUrl(i)||!this.mergedThumbnailUrl?t("span",{class:`${e}-upload-file-info__thumbnail`},n?n(i):yt(i)?t(j,{clsPrefix:e},{default:()=>Do}):t(j,{clsPrefix:e},{default:()=>Mo})):t("a",{rel:"noopener noreferer",target:"_blank",href:i.url||void 0,class:`${e}-upload-file-info__thumbnail`,onClick:this.handlePreviewClick},r==="image-card"?t(po,{src:this.mergedThumbnailUrl||void 0,previewSrc:i.url||void 0,alt:i.name,ref:"imageRef"}):t("img",{src:this.mergedThumbnailUrl||void 0,alt:i.name})):s=t("span",{class:`${e}-upload-file-info__thumbnail`},n?n(i):t(j,{clsPrefix:e},{default:()=>t(Gr,null)}));const d=t(Io,{show:this.showProgress,percentage:i.percentage||0,status:this.progressStatus}),l=r==="text"||r==="image";return t("div",{class:[`${e}-upload-file`,`${e}-upload-file--${this.progressStatus}-status`,i.url&&i.status!=="error"&&r!=="image-card"&&`${e}-upload-file--with-url`,`${e}-upload-file--${r}-type`]},t("div",{class:`${e}-upload-file-info`},s,t("div",{class:`${e}-upload-file-info__name`},l&&(i.url&&i.status!=="error"?t("a",{rel:"noopener noreferer",target:"_blank",href:i.url||void 0,onClick:this.handlePreviewClick},i.name):t("span",{onClick:this.handlePreviewClick},i.name)),u&&d),t("div",{class:[`${e}-upload-file-info__action`,`${e}-upload-file-info__action--${r}-type`]},this.showPreviewButton?t(fe,{key:"preview",quaternary:!0,type:this.buttonType,onClick:this.handlePreviewClick,theme:o.peers.Button,themeOverrides:o.peerOverrides.Button,builtinThemeOverrides:pe},{icon:()=>t(j,{clsPrefix:e},{default:()=>t(tr,null)})}):null,(this.showRemoveButton||this.showCancelButton)&&!this.disabled&&t(fe,{key:"cancelOrTrash",theme:o.peers.Button,themeOverrides:o.peerOverrides.Button,quaternary:!0,builtinThemeOverrides:pe,type:this.buttonType,onClick:this.handleRemoveOrCancelClick},{icon:()=>t(Nt,null,{default:()=>this.showRemoveButton?t(j,{clsPrefix:e,key:"trash"},{default:()=>t(Kr,null)}):t(j,{clsPrefix:e,key:"cancel"},{default:()=>t(Jr,null)})})}),this.showRetryButton&&!this.disabled&&t(fe,{key:"retry",quaternary:!0,type:this.buttonType,onClick:this.handleRetryClick,theme:o.peers.Button,themeOverrides:o.peerOverrides.Button,builtinThemeOverrides:pe},{icon:()=>t(j,{clsPrefix:e},{default:()=>t(Qr,null)})}),this.showDownloadButton?t(fe,{key:"download",quaternary:!0,type:this.buttonType,onClick:this.handleDownloadClick,theme:o.peers.Button,themeOverrides:o.peerOverrides.Button,builtinThemeOverrides:pe},{icon:()=>t(j,{clsPrefix:e},{default:()=>t(pt,null)})}):null)),!u&&d)}}),No=V({name:"UploadFileList",setup(e,{slots:o}){const r=ie(de,null);r||be("upload-file-list","`n-upload-file-list` must be placed inside `n-upload`.");const{abstractRef:i,mergedClsPrefixRef:n,listTypeRef:s,mergedFileListRef:u,fileListClassRef:c,fileListStyleRef:d,cssVarsRef:l,themeClassRef:a,maxReachedRef:f,showTriggerRef:w,imageGroupPropsRef:v}=r,C=L(()=>s.value==="image-card"),y=()=>u.value.map((z,k)=>t(Fo,{clsPrefix:n.value,key:z.id,file:z,index:k,listType:s.value})),I=()=>C.value?t(go,Object.assign({},v.value),{default:y}):t(et,{group:!0},{default:y});return()=>{const{value:z}=n,{value:k}=i;return t("div",{class:[`${z}-upload-file-list`,C.value&&`${z}-upload-file-list--grid`,k?a==null?void 0:a.value:void 0,c.value],style:[k&&l?l.value:"",d.value]},I(),w.value&&!f.value&&C.value&&t(Ct,null,o))}}}),_o=N([h("upload","width: 100%;",[P("dragger-inside",[h("upload-trigger",`
 display: block;
 `)]),P("drag-over",[h("upload-dragger",`
 border: var(--n-dragger-border-hover);
 `)])]),h("upload-dragger",`
 cursor: pointer;
 box-sizing: border-box;
 width: 100%;
 text-align: center;
 border-radius: var(--n-border-radius);
 padding: 24px;
 opacity: 1;
 transition:
 opacity .3s var(--n-bezier),
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-dragger-color);
 border: var(--n-dragger-border);
 `,[N("&:hover",`
 border: var(--n-dragger-border-hover);
 `),P("disabled",`
 cursor: not-allowed;
 `)]),h("upload-trigger",`
 display: inline-block;
 box-sizing: border-box;
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[N("+",[h("upload-file-list","margin-top: 8px;")]),P("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `),P("image-card",`
 width: 96px;
 height: 96px;
 `,[h("base-icon",`
 font-size: 24px;
 `),h("upload-dragger",`
 padding: 0;
 height: 100%;
 width: 100%;
 display: flex;
 align-items: center;
 justify-content: center;
 `)])]),h("upload-file-list",`
 line-height: var(--n-line-height);
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 `,[N("a, img","outline: none;"),P("disabled",`
 opacity: var(--n-item-disabled-opacity);
 cursor: not-allowed;
 `,[h("upload-file","cursor: not-allowed;")]),P("grid",`
 display: grid;
 grid-template-columns: repeat(auto-fill, 96px);
 grid-gap: 8px;
 margin-top: 0;
 `),h("upload-file",`
 display: block;
 box-sizing: border-box;
 cursor: default;
 padding: 0px 12px 0 6px;
 transition: background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 `,[Ne(),h("progress",[Ne({foldPadding:!0})]),N("&:hover",`
 background-color: var(--n-item-color-hover);
 `,[h("upload-file-info",[Q("action",`
 opacity: 1;
 `)])]),P("image-type",`
 border-radius: var(--n-border-radius);
 text-decoration: underline;
 text-decoration-color: #0000;
 `,[h("upload-file-info",`
 padding-top: 0px;
 padding-bottom: 0px;
 width: 100%;
 height: 100%;
 display: flex;
 justify-content: space-between;
 align-items: center;
 padding: 6px 0;
 `,[h("progress",`
 padding: 2px 0;
 margin-bottom: 0;
 `),Q("name",`
 padding: 0 8px;
 `),Q("thumbnail",`
 width: 32px;
 height: 32px;
 font-size: 28px;
 display: flex;
 justify-content: center;
 align-items: center;
 `,[N("img",`
 width: 100%;
 `)])])]),P("text-type",[h("progress",`
 box-sizing: border-box;
 padding-bottom: 6px;
 margin-bottom: 6px;
 `)]),P("image-card-type",`
 position: relative;
 width: 96px;
 height: 96px;
 border: var(--n-item-border-image-card);
 border-radius: var(--n-border-radius);
 padding: 0;
 display: flex;
 align-items: center;
 justify-content: center;
 transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 overflow: hidden;
 `,[h("progress",`
 position: absolute;
 left: 8px;
 bottom: 8px;
 right: 8px;
 width: unset;
 `),h("upload-file-info",`
 padding: 0;
 width: 100%;
 height: 100%;
 `,[Q("thumbnail",`
 width: 100%;
 height: 100%;
 display: flex;
 flex-direction: column;
 align-items: center;
 justify-content: center;
 font-size: 36px;
 `,[N("img",`
 width: 100%;
 `)])]),N("&::before",`
 position: absolute;
 z-index: 1;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 opacity: 0;
 transition: opacity .2s var(--n-bezier);
 content: "";
 `),N("&:hover",[N("&::before","opacity: 1;"),h("upload-file-info",[Q("thumbnail","opacity: .12;")])])]),P("error-status",[N("&:hover",`
 background-color: var(--n-item-color-hover-error);
 `),h("upload-file-info",[Q("name","color: var(--n-item-text-color-error);"),Q("thumbnail","color: var(--n-item-text-color-error);")]),P("image-card-type",`
 border: var(--n-item-border-image-card-error);
 `)]),P("with-url",`
 cursor: pointer;
 `,[h("upload-file-info",[Q("name",`
 color: var(--n-item-text-color-success);
 text-decoration-color: var(--n-item-text-color-success);
 `,[N("a",`
 text-decoration: underline;
 `)])])]),h("upload-file-info",`
 position: relative;
 padding-top: 6px;
 padding-bottom: 6px;
 display: flex;
 flex-wrap: nowrap;
 `,[Q("thumbnail",`
 font-size: 18px;
 opacity: 1;
 transition: opacity .2s var(--n-bezier);
 color: var(--n-item-icon-color);
 `,[h("base-icon",`
 margin-right: 2px;
 vertical-align: middle;
 transition: color .3s var(--n-bezier);
 `)]),Q("action",`
 padding-top: inherit;
 padding-bottom: inherit;
 position: absolute;
 right: 0;
 top: 0;
 bottom: 0;
 width: 80px;
 display: flex;
 align-items: center;
 transition: opacity .2s var(--n-bezier);
 justify-content: flex-end;
 opacity: 0;
 `,[h("button",[N("&:not(:last-child)",{marginRight:"4px"}),h("base-icon",[N("svg",[jt()])])]),P("image-type",`
 position: relative;
 max-width: 80px;
 width: auto;
 `),P("image-card-type",`
 z-index: 2;
 position: absolute;
 width: 100%;
 height: 100%;
 left: 0;
 right: 0;
 bottom: 0;
 top: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 `)]),Q("name",`
 color: var(--n-item-text-color);
 flex: 1;
 display: flex;
 justify-content: center;
 text-overflow: ellipsis;
 overflow: hidden;
 flex-direction: column;
 text-decoration-color: #0000;
 font-size: var(--n-font-size);
 transition:
 color .3s var(--n-bezier),
 text-decoration-color .3s var(--n-bezier); 
 `,[N("a",`
 color: inherit;
 text-decoration: underline;
 `)])])])]),h("upload-file-input",`
 display: none;
 width: 0;
 height: 0;
 opacity: 0;
 `)]);var Xe=function(e,o,r,i){function n(s){return s instanceof r?s:new r(function(u){u(s)})}return new(r||(r=Promise))(function(s,u){function c(a){try{l(i.next(a))}catch(f){u(f)}}function d(a){try{l(i.throw(a))}catch(f){u(f)}}function l(a){a.done?s(a.value):n(a.value).then(c,d)}l((i=i.apply(e,o||[])).next())})};function jo(e,o,r){const{doChange:i,xhrMap:n}=e;let s=0;function u(d){var l;let a=Object.assign({},o,{status:"error",percentage:s});n.delete(o.id),a=ue(((l=e.onError)===null||l===void 0?void 0:l.call(e,{file:a,event:d}))||a),i(a,d)}function c(d){var l;if(e.isErrorState){if(e.isErrorState(r)){u(d);return}}else if(r.status<200||r.status>=300){u(d);return}let a=Object.assign({},o,{status:"finished",percentage:s});n.delete(o.id),a=ue(((l=e.onFinish)===null||l===void 0?void 0:l.call(e,{file:a,event:d}))||a),i(a,d)}return{handleXHRLoad:c,handleXHRError:u,handleXHRAbort(d){const l=Object.assign({},o,{status:"removed",file:null,percentage:s});n.delete(o.id),i(l,d)},handleXHRProgress(d){const l=Object.assign({},o,{status:"uploading"});if(d.lengthComputable){const a=Math.ceil(d.loaded/d.total*100);l.percentage=a,s=a}i(l,d)}}}function Eo(e){const{inst:o,file:r,data:i,headers:n,withCredentials:s,action:u,customRequest:c}=e,{doChange:d}=e.inst;let l=0;c({file:r,data:i,headers:n,withCredentials:s,action:u,onProgress(a){const f=Object.assign({},r,{status:"uploading"}),w=a.percent;f.percentage=w,l=w,d(f)},onFinish(){var a;let f=Object.assign({},r,{status:"finished",percentage:l});f=ue(((a=o.onFinish)===null||a===void 0?void 0:a.call(o,{file:f}))||f),d(f)},onError(){var a;let f=Object.assign({},r,{status:"error",percentage:l});f=ue(((a=o.onError)===null||a===void 0?void 0:a.call(o,{file:f}))||f),d(f)}})}function Ao(e,o,r){const i=jo(e,o,r);r.onabort=i.handleXHRAbort,r.onerror=i.handleXHRError,r.onload=i.handleXHRLoad,r.upload&&(r.upload.onprogress=i.handleXHRProgress)}function Rt(e,o){return typeof e=="function"?e({file:o}):e||{}}function Ho(e,o,r){const i=Rt(o,r);i&&Object.keys(i).forEach(n=>{e.setRequestHeader(n,i[n])})}function Wo(e,o,r){const i=Rt(o,r);i&&Object.keys(i).forEach(n=>{e.append(n,i[n])})}function Vo(e,o,r,{method:i,action:n,withCredentials:s,responseType:u,headers:c,data:d}){const l=new XMLHttpRequest;l.responseType=u,e.xhrMap.set(r.id,l),l.withCredentials=s;const a=new FormData;if(Wo(a,d,r),r.file!==null&&a.append(o,r.file),Ao(e,r,l),n!==void 0){l.open(i.toUpperCase(),n),Ho(l,c,r),l.send(a);const f=Object.assign({},r,{status:"uploading"});e.doChange(f)}}const Zo=Object.assign(Object.assign({},oe.props),{name:{type:String,default:"file"},accept:String,action:String,customRequest:Function,directory:Boolean,directoryDnd:{type:Boolean,default:void 0},method:{type:String,default:"POST"},multiple:Boolean,showFileList:{type:Boolean,default:!0},data:[Object,Function],headers:[Object,Function],withCredentials:Boolean,responseType:{type:String,default:""},disabled:{type:Boolean,default:void 0},onChange:Function,onRemove:Function,onFinish:Function,onError:Function,onBeforeUpload:Function,isErrorState:Function,onDownload:Function,defaultUpload:{type:Boolean,default:!0},fileList:Array,"onUpdate:fileList":[Function,Array],onUpdateFileList:[Function,Array],fileListClass:String,fileListStyle:[String,Object],defaultFileList:{type:Array,default:()=>[]},showCancelButton:{type:Boolean,default:!0},showRemoveButton:{type:Boolean,default:!0},showDownloadButton:Boolean,showRetryButton:{type:Boolean,default:!0},showPreviewButton:{type:Boolean,default:!0},listType:{type:String,default:"text"},onPreview:Function,shouldUseThumbnailUrl:{type:Function,default:e=>Lo?yt(e):!1},createThumbnailUrl:Function,abstract:Boolean,max:Number,showTrigger:{type:Boolean,default:!0},imageGroupProps:Object,inputProps:Object,triggerClass:String,triggerStyle:[String,Object],renderIcon:Function}),li=V({name:"Upload",props:Zo,setup(e){e.abstract&&e.listType==="image-card"&&be("upload","when the list-type is image-card, abstract is not supported.");const{mergedClsPrefixRef:o,inlineThemeDisabled:r}=se(e),i=oe("Upload","-upload",_o,Zt,e,o),n=Et(e),s=W(e.defaultFileList),u=U(e,"fileList"),c=W(null),d={value:!1},l=W(!1),a=new Map,f=ir(u,s),w=L(()=>f.value.map(ue)),v=L(()=>{const{max:b}=e;return b!==void 0?w.value.length>=b:!1});function C(){var b;(b=c.value)===null||b===void 0||b.click()}function y(b){const B=b.target;H(B.files?Array.from(B.files).map(T=>({file:T,entry:null,source:"input"})):null,b),B.value=""}function I(b){const{"onUpdate:fileList":B,onUpdateFileList:T}=e;B&&Fe(B,b),T&&Fe(T,b),s.value=b}const z=L(()=>e.multiple||e.directory),k=(b,B,T={append:!1,remove:!1})=>{const{append:O,remove:E}=T,Z=Array.from(w.value),A=Z.findIndex(F=>F.id===b.id);if(O||E||~A){O?Z.push(b):E?Z.splice(A,1):Z.splice(A,1,b);const{onChange:F}=e;F&&F({file:b,fileList:Z,event:B}),I(Z)}};function H(b,B){if(!b||b.length===0)return;const{onBeforeUpload:T}=e;b=z.value?b:[b[0]];const{max:O,accept:E}=e;b=b.filter(({file:A,source:F})=>F==="dnd"&&(E!=null&&E.trim())?Bo(A.name,A.type,E):!0),O&&(b=b.slice(0,O-w.value.length));const Z=Te();Promise.all(b.map(A=>Xe(this,[A],void 0,function*({file:F,entry:Y}){var q;const ee={id:Te(),batchId:Z,name:F.name,status:"pending",percentage:0,file:F,url:null,type:F.type,thumbnailUrl:null,fullPath:(q=Y==null?void 0:Y.fullPath)!==null&&q!==void 0?q:`/${F.webkitRelativePath||F.name}`};return!T||(yield T({file:ee,fileList:w.value}))!==!1?ee:null}))).then(A=>Xe(this,void 0,void 0,function*(){let F=Promise.resolve();A.forEach(Y=>{F=F.then(Ht).then(()=>{Y&&k(Y,B,{append:!0})})}),yield F})).then(()=>{e.defaultUpload&&$()})}function $(b){const{method:B,action:T,withCredentials:O,headers:E,data:Z,name:A}=e,F=b!==void 0?w.value.filter(q=>q.id===b):w.value,Y=b!==void 0;F.forEach(q=>{const{status:ee}=q;(ee==="pending"||ee==="error"&&Y)&&(e.customRequest?Eo({inst:{doChange:k,xhrMap:a,onFinish:e.onFinish,onError:e.onError},file:q,action:T,withCredentials:O,headers:E,data:Z,customRequest:e.customRequest}):Vo({doChange:k,xhrMap:a,onFinish:e.onFinish,onError:e.onError,isErrorState:e.isErrorState},A,q,{method:B,action:T,withCredentials:O,responseType:e.responseType,headers:E,data:Z}))})}function m(b){var B;if(b.thumbnailUrl)return b.thumbnailUrl;const{createThumbnailUrl:T}=e;return T?(B=T(b.file,b))!==null&&B!==void 0?B:b.url||"":b.url?b.url:b.file?To(b.file):""}const R=L(()=>{const{common:{cubicBezierEaseInOut:b},self:{draggerColor:B,draggerBorder:T,draggerBorderHover:O,itemColorHover:E,itemColorHoverError:Z,itemTextColorError:A,itemTextColorSuccess:F,itemTextColor:Y,itemIconColor:q,itemDisabledOpacity:ee,lineHeight:we,borderRadius:ce,fontSize:xe,itemBorderImageCardError:ye,itemBorderImageCard:Ce}}=i.value;return{"--n-bezier":b,"--n-border-radius":ce,"--n-dragger-border":T,"--n-dragger-border-hover":O,"--n-dragger-color":B,"--n-font-size":xe,"--n-item-color-hover":E,"--n-item-color-hover-error":Z,"--n-item-disabled-opacity":ee,"--n-item-icon-color":q,"--n-item-text-color":Y,"--n-item-text-color-error":A,"--n-item-text-color-success":F,"--n-line-height":we,"--n-item-border-image-card-error":ye,"--n-item-border-image-card":Ce}}),S=r?me("upload",void 0,R,e):void 0;Oe(de,{mergedClsPrefixRef:o,mergedThemeRef:i,showCancelButtonRef:U(e,"showCancelButton"),showDownloadButtonRef:U(e,"showDownloadButton"),showRemoveButtonRef:U(e,"showRemoveButton"),showRetryButtonRef:U(e,"showRetryButton"),onRemoveRef:U(e,"onRemove"),onDownloadRef:U(e,"onDownload"),mergedFileListRef:w,triggerClassRef:U(e,"triggerClass"),triggerStyleRef:U(e,"triggerStyle"),shouldUseThumbnailUrlRef:U(e,"shouldUseThumbnailUrl"),renderIconRef:U(e,"renderIcon"),xhrMap:a,submit:$,doChange:k,showPreviewButtonRef:U(e,"showPreviewButton"),onPreviewRef:U(e,"onPreview"),getFileThumbnailUrlResolver:m,listTypeRef:U(e,"listType"),dragOverRef:l,openOpenFileDialog:C,draggerInsideRef:d,handleFileAddition:H,mergedDisabledRef:n.mergedDisabledRef,maxReachedRef:v,fileListClassRef:U(e,"fileListClass"),fileListStyleRef:U(e,"fileListStyle"),abstractRef:U(e,"abstract"),acceptRef:U(e,"accept"),cssVarsRef:r?void 0:R,themeClassRef:S==null?void 0:S.themeClass,onRender:S==null?void 0:S.onRender,showTriggerRef:U(e,"showTrigger"),imageGroupPropsRef:U(e,"imageGroupProps"),mergedDirectoryDndRef:L(()=>{var b;return(b=e.directoryDnd)!==null&&b!==void 0?b:e.directory})});const _={clear:()=>{s.value=[]},submit:$,openOpenFileDialog:C};return Object.assign({mergedClsPrefix:o,draggerInsideRef:d,inputElRef:c,mergedTheme:i,dragOver:l,mergedMultiple:z,cssVars:r?void 0:R,themeClass:S==null?void 0:S.themeClass,onRender:S==null?void 0:S.onRender,handleFileInputChange:y},_)},render(){var e,o;const{draggerInsideRef:r,mergedClsPrefix:i,$slots:n,directory:s,onRender:u}=this;if(n.default&&!this.abstract){const d=n.default()[0];!((e=d==null?void 0:d.type)===null||e===void 0)&&e[wt]&&(r.value=!0)}const c=t("input",Object.assign({},this.inputProps,{ref:"inputElRef",type:"file",class:`${i}-upload-file-input`,accept:this.accept,multiple:this.mergedMultiple,onChange:this.handleFileInputChange,webkitdirectory:s||void 0,directory:s||void 0}));return this.abstract?t(ve,null,(o=n.default)===null||o===void 0?void 0:o.call(n),t(At,{to:"body"},c)):(u==null||u(),t("div",{class:[`${i}-upload`,r.value&&`${i}-upload--dragger-inside`,this.dragOver&&`${i}-upload--drag-over`,this.themeClass],style:this.cssVars},c,this.showTrigger&&this.listType!=="image-card"&&t(Ct,null,n),this.showFileList&&t(No,null,n)))}});export{Yr as A,li as N,ni as a};
