import{_ as c}from"./DlAUqK2U.js";import{A as e,z as o}from"./BmdUO_FW.js";const n={};function r(t,s){return o(),e("div",null," column ")}const l=c(n,[["render",r]]);export{l as default};
