import{Q as de,aG as ue,a as H,e as t,aF as L,b as D,R as s,af as E,f as he,u as be,j as X,ae as fe,r as N,S as ve,h as z,k as m,l as ge,aJ as W,s as i,t as p,aB as me,aC as pe,a1 as K,z as we,A as xe,L as ye,M as _e,B as P}from"./BmdUO_FW.js";import{a as ke}from"./DL2Kioqa.js";import{u as Se}from"./BAywZTNm.js";import{p as O,d as c}from"./FLc-EezL.js";import{_ as Ce}from"./DlAUqK2U.js";function Be(e){const{primaryColor:l,opacityDisabled:f,borderRadius:n,textColor3:r}=e;return Object.assign(Object.assign({},ke),{iconColor:r,textColor:"white",loadingColor:l,opacityDisabled:f,railColor:"rgba(0, 0, 0, .14)",railColorActive:l,buttonBoxShadow:"0 1px 4px 0 rgba(0, 0, 0, 0.3), inset 0 0 1px 0 rgba(0, 0, 0, 0.05)",buttonColor:"#FFF",railBorderRadiusSmall:n,railBorderRadiusMedium:n,railBorderRadiusLarge:n,buttonBorderRadiusSmall:n,buttonBorderRadiusMedium:n,buttonBorderRadiusLarge:n,boxShadowFocus:`0 0 0 2px ${ue(l,{alpha:.2})}`})}const Re={name:"Switch",common:de,self:Be},$e=H("switch",`
 height: var(--n-height);
 min-width: var(--n-width);
 vertical-align: middle;
 user-select: none;
 -webkit-user-select: none;
 display: inline-flex;
 outline: none;
 justify-content: center;
 align-items: center;
`,[t("children-placeholder",`
 height: var(--n-rail-height);
 display: flex;
 flex-direction: column;
 overflow: hidden;
 pointer-events: none;
 visibility: hidden;
 `),t("rail-placeholder",`
 display: flex;
 flex-wrap: none;
 `),t("button-placeholder",`
 width: calc(1.75 * var(--n-rail-height));
 height: var(--n-rail-height);
 `),H("base-loading",`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 font-size: calc(var(--n-button-width) - 4px);
 color: var(--n-loading-color);
 transition: color .3s var(--n-bezier);
 `,[L({left:"50%",top:"50%",originalTransform:"translateX(-50%) translateY(-50%)"})]),t("checked, unchecked",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 box-sizing: border-box;
 position: absolute;
 white-space: nowrap;
 top: 0;
 bottom: 0;
 display: flex;
 align-items: center;
 line-height: 1;
 `),t("checked",`
 right: 0;
 padding-right: calc(1.25 * var(--n-rail-height) - var(--n-offset));
 `),t("unchecked",`
 left: 0;
 justify-content: flex-end;
 padding-left: calc(1.25 * var(--n-rail-height) - var(--n-offset));
 `),D("&:focus",[t("rail",`
 box-shadow: var(--n-box-shadow-focus);
 `)]),s("round",[t("rail","border-radius: calc(var(--n-rail-height) / 2);",[t("button","border-radius: calc(var(--n-button-height) / 2);")])]),E("disabled",[E("icon",[s("rubber-band",[s("pressed",[t("rail",[t("button","max-width: var(--n-button-width-pressed);")])]),t("rail",[D("&:active",[t("button","max-width: var(--n-button-width-pressed);")])]),s("active",[s("pressed",[t("rail",[t("button","left: calc(100% - var(--n-offset) - var(--n-button-width-pressed));")])]),t("rail",[D("&:active",[t("button","left: calc(100% - var(--n-offset) - var(--n-button-width-pressed));")])])])])])]),s("active",[t("rail",[t("button","left: calc(100% - var(--n-button-width) - var(--n-offset))")])]),t("rail",`
 overflow: hidden;
 height: var(--n-rail-height);
 min-width: var(--n-rail-width);
 border-radius: var(--n-rail-border-radius);
 cursor: pointer;
 position: relative;
 transition:
 opacity .3s var(--n-bezier),
 background .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 background-color: var(--n-rail-color);
 `,[t("button-icon",`
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 font-size: calc(var(--n-button-height) - 4px);
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 display: flex;
 justify-content: center;
 align-items: center;
 line-height: 1;
 `,[L()]),t("button",`
 align-items: center; 
 top: var(--n-offset);
 left: var(--n-offset);
 height: var(--n-button-height);
 width: var(--n-button-width-pressed);
 max-width: var(--n-button-width);
 border-radius: var(--n-button-border-radius);
 background-color: var(--n-button-color);
 box-shadow: var(--n-button-box-shadow);
 box-sizing: border-box;
 cursor: inherit;
 content: "";
 position: absolute;
 transition:
 background-color .3s var(--n-bezier),
 left .3s var(--n-bezier),
 opacity .3s var(--n-bezier),
 max-width .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 `)]),s("active",[t("rail","background-color: var(--n-rail-color-active);")]),s("loading",[t("rail",`
 cursor: wait;
 `)]),s("disabled",[t("rail",`
 cursor: not-allowed;
 opacity: .5;
 `)])]),Ve=Object.assign(Object.assign({},X.props),{size:{type:String,default:"medium"},value:{type:[String,Number,Boolean],default:void 0},loading:Boolean,defaultValue:{type:[String,Number,Boolean],default:!1},disabled:{type:Boolean,default:void 0},round:{type:Boolean,default:!0},"onUpdate:value":[Function,Array],onUpdateValue:[Function,Array],checkedValue:{type:[String,Number,Boolean],default:!0},uncheckedValue:{type:[String,Number,Boolean],default:!1},railStyle:Function,rubberBand:{type:Boolean,default:!0},onChange:[Function,Array]});let C;const Ae=he({name:"Switch",props:Ve,setup(e){C===void 0&&(typeof CSS<"u"?typeof CSS.supports<"u"?C=CSS.supports("width","max(1px)"):C=!1:C=!0);const{mergedClsPrefixRef:l,inlineThemeDisabled:f}=be(e),n=X("Switch","-switch",$e,Re,e,l),r=fe(e),{mergedSizeRef:y,mergedDisabledRef:v}=r,_=N(e.defaultValue),B=ve(e,"value"),g=Se(B,_),k=z(()=>g.value===e.checkedValue),w=N(!1),a=N(!1),d=z(()=>{const{railStyle:o}=e;if(o)return o({focused:a.value,checked:k.value})});function u(o){const{"onUpdate:value":R,onChange:$,onUpdateValue:V}=e,{nTriggerFormInput:F,nTriggerFormChange:M}=r;R&&K(R,o),V&&K(V,o),$&&K($,o),_.value=o,F(),M()}function Y(){const{nTriggerFormFocus:o}=r;o()}function G(){const{nTriggerFormBlur:o}=r;o()}function J(){e.loading||v.value||(g.value!==e.checkedValue?u(e.checkedValue):u(e.uncheckedValue))}function Q(){a.value=!0,Y()}function q(){a.value=!1,G(),w.value=!1}function Z(o){e.loading||v.value||o.key===" "&&(g.value!==e.checkedValue?u(e.checkedValue):u(e.uncheckedValue),w.value=!1)}function ee(o){e.loading||v.value||o.key===" "&&(o.preventDefault(),w.value=!0)}const U=z(()=>{const{value:o}=y,{self:{opacityDisabled:R,railColor:$,railColorActive:V,buttonBoxShadow:F,buttonColor:M,boxShadowFocus:te,loadingColor:oe,textColor:ae,iconColor:ie,[m("buttonHeight",o)]:h,[m("buttonWidth",o)]:ne,[m("buttonWidthPressed",o)]:re,[m("railHeight",o)]:b,[m("railWidth",o)]:S,[m("railBorderRadius",o)]:le,[m("buttonBorderRadius",o)]:se},common:{cubicBezierEaseInOut:ce}}=n.value;let T,I,j;return C?(T=`calc((${b} - ${h}) / 2)`,I=`max(${b}, ${h})`,j=`max(${S}, calc(${S} + ${h} - ${b}))`):(T=O((c(b)-c(h))/2),I=O(Math.max(c(b),c(h))),j=c(b)>c(h)?S:O(c(S)+c(h)-c(b))),{"--n-bezier":ce,"--n-button-border-radius":se,"--n-button-box-shadow":F,"--n-button-color":M,"--n-button-width":ne,"--n-button-width-pressed":re,"--n-button-height":h,"--n-height":I,"--n-offset":T,"--n-opacity-disabled":R,"--n-rail-border-radius":le,"--n-rail-color":$,"--n-rail-color-active":V,"--n-rail-height":b,"--n-rail-width":S,"--n-width":j,"--n-box-shadow-focus":te,"--n-loading-color":oe,"--n-text-color":ae,"--n-icon-color":ie}}),x=f?ge("switch",z(()=>y.value[0]),U,e):void 0;return{handleClick:J,handleBlur:q,handleFocus:Q,handleKeyup:Z,handleKeydown:ee,mergedRailStyle:d,pressed:w,mergedClsPrefix:l,mergedValue:g,checked:k,mergedDisabled:v,cssVars:f?void 0:U,themeClass:x==null?void 0:x.themeClass,onRender:x==null?void 0:x.onRender}},render(){const{mergedClsPrefix:e,mergedDisabled:l,checked:f,mergedRailStyle:n,onRender:r,$slots:y}=this;r==null||r();const{checked:v,unchecked:_,icon:B,"checked-icon":g,"unchecked-icon":k}=y,w=!(W(B)&&W(g)&&W(k));return i("div",{role:"switch","aria-checked":f,class:[`${e}-switch`,this.themeClass,w&&`${e}-switch--icon`,f&&`${e}-switch--active`,l&&`${e}-switch--disabled`,this.round&&`${e}-switch--round`,this.loading&&`${e}-switch--loading`,this.pressed&&`${e}-switch--pressed`,this.rubberBand&&`${e}-switch--rubber-band`],tabindex:this.mergedDisabled?void 0:0,style:this.cssVars,onClick:this.handleClick,onFocus:this.handleFocus,onBlur:this.handleBlur,onKeyup:this.handleKeyup,onKeydown:this.handleKeydown},i("div",{class:`${e}-switch__rail`,"aria-hidden":"true",style:n},p(v,a=>p(_,d=>a||d?i("div",{"aria-hidden":!0,class:`${e}-switch__children-placeholder`},i("div",{class:`${e}-switch__rail-placeholder`},i("div",{class:`${e}-switch__button-placeholder`}),a),i("div",{class:`${e}-switch__rail-placeholder`},i("div",{class:`${e}-switch__button-placeholder`}),d)):null)),i("div",{class:`${e}-switch__button`},p(B,a=>p(g,d=>p(k,u=>i(me,null,{default:()=>this.loading?i(pe,{key:"loading",clsPrefix:e,strokeWidth:20}):this.checked&&(d||a)?i("div",{class:`${e}-switch__button-icon`,key:d?"checked-icon":"icon"},d||a):!this.checked&&(u||a)?i("div",{class:`${e}-switch__button-icon`,key:u?"unchecked-icon":"icon"},u||a):null})))),p(v,a=>a&&i("div",{key:"checked",class:`${e}-switch__checked`},a)),p(_,a=>a&&i("div",{key:"unchecked",class:`${e}-switch__unchecked`},a)))))}}),ze={},A=e=>(ye("data-v-063f16a0"),e=e(),_e(),e),Fe={class:"icon nav-icon"},Me=A(()=>P("span",null,null,-1)),Te=A(()=>P("span",null,null,-1)),Ie=A(()=>P("span",null,null,-1)),je=[Me,Te,Ie];function De(e,l){return we(),xe("div",Fe,je)}const Ue=Ce(ze,[["render",De],["__scopeId","data-v-063f16a0"]]);export{Ue as M,Ae as _};
