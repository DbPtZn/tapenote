function l(s,o="default",n=[]){const t=s.$slots[o];return t===void 0?n:t()}export{l as g};
