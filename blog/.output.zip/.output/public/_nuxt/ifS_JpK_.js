import{aO as o}from"./agTtEPyh.js";const p=o("/logo.png");export{p as _};
