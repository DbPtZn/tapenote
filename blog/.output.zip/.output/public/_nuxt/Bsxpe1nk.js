import{f as e,z as n,A as t}from"./agTtEPyh.js";const s=e({__name:"index",setup(o){return(a,r)=>(n(),t("div",null,"index"))}});export{s as default};
