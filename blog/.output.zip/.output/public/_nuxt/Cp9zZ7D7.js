import{f as $,aw as We,o as de,bj as qe,az as Ge,h as z,r as H,ah as X,s as u,V as Ue,n as we,a as E,e as L,b as K,u as Re,j as J,g as ce,b8 as Ye,k as D,l as ze,X as Ce,U as Ze,R as j,af as Xe,Y as Je,S as _,p as fe,Z as ve,t as he,aC as Qe,q as et,W as tt}from"./agTtEPyh.js";import{b as nt,d as ie,e as ot,i as ue,f as it,g as lt,h as me}from"./vCpSA_hg.js";import{r as ke}from"./DiUaNqzw.js";import{f as rt}from"./R4FuRqJU.js";import{e as st,i as at}from"./Dz6IFsFJ.js";import{d as ae,p as Y,V as pe,r as ge,g as le}from"./qItcCqav.js";import{S as dt}from"./94yb6JQI.js";import{u as ct}from"./DmZsUmVU.js";function re(e){const t=e.filter(o=>o!==void 0);if(t.length!==0)return t.length===1?t[0]:o=>{e.forEach(l=>{l&&l(o)})}}function be(e){return e&-e}class ut{constructor(t,o){this.l=t,this.min=o;const l=new Array(t+1);for(let a=0;a<t+1;++a)l[a]=0;this.ft=l}add(t,o){if(o===0)return;const{l,ft:a}=this;for(t+=1;t<=l;)a[t]+=o,t+=be(t)}get(t){return this.sum(t+1)-this.sum(t)}sum(t){if(t===void 0&&(t=this.l),t<=0)return 0;const{ft:o,min:l,l:a}=this;if(t>a)throw new Error("[FinweckTree.sum]: `i` is larger than length.");let r=t*l;for(;t>0;)r+=o[t],t-=be(t);return r}getBound(t){let o=0,l=this.l;for(;l>o;){const a=Math.floor((o+l)/2),r=this.sum(a);if(r>t){l=a;continue}else if(r<t){if(o===a)return this.sum(o+1)<=t?o+1:a;o=a}else return a}return o}}let Z;function ft(){return typeof document>"u"?!1:(Z===void 0&&("matchMedia"in window?Z=window.matchMedia("(pointer:coarse)").matches:Z=!1),Z)}let se;function ye(){return typeof document>"u"?1:(se===void 0&&(se="chrome"in window?window.devicePixelRatio:1),se)}const vt=ie(".v-vl",{maxHeight:"inherit",height:"100%",overflow:"auto",minWidth:"1px"},[ie("&:not(.v-vl--show-scrollbar)",{scrollbarWidth:"none"},[ie("&::-webkit-scrollbar, &::-webkit-scrollbar-track-piece, &::-webkit-scrollbar-thumb",{width:0,height:0,display:"none"})])]),ht=$({name:"VirtualList",inheritAttrs:!1,props:{showScrollbar:{type:Boolean,default:!0},items:{type:Array,default:()=>[]},itemSize:{type:Number,required:!0},itemResizable:Boolean,itemsStyle:[String,Object],visibleItemsTag:{type:[String,Object],default:"div"},visibleItemsProps:Object,ignoreItemResize:Boolean,onScroll:Function,onWheel:Function,onResize:Function,defaultScrollKey:[Number,String],defaultScrollIndex:Number,keyField:{type:String,default:"key"},paddingTop:{type:[Number,String],default:0},paddingBottom:{type:[Number,String],default:0}},setup(e){const t=We();vt.mount({id:"vueuc/virtual-list",head:!0,anchorMetaName:nt,ssr:t}),de(()=>{const{defaultScrollIndex:s,defaultScrollKey:c}=e;s!=null?h({index:s}):c!=null&&h({key:c})});let o=!1,l=!1;qe(()=>{if(o=!1,!l){l=!0;return}h({top:b.value,left:v})}),Ge(()=>{o=!0,l||(l=!0)});const a=z(()=>{const s=new Map,{keyField:c}=e;return e.items.forEach((m,p)=>{s.set(m[c],p)}),s}),r=H(null),d=H(void 0),f=new Map,g=z(()=>{const{items:s,itemSize:c,keyField:m}=e,p=new ut(s.length,c);return s.forEach((w,k)=>{const S=w[m],T=f.get(S);T!==void 0&&p.add(k,T)}),p}),y=H(0);let v=0;const b=H(0),C=X(()=>Math.max(g.value.getBound(b.value-ae(e.paddingTop))-1,0)),N=z(()=>{const{value:s}=d;if(s===void 0)return[];const{items:c,itemSize:m}=e,p=C.value,w=Math.min(p+Math.ceil(s/m+1),c.length-1),k=[];for(let S=p;S<=w;++S)k.push(c[S]);return k}),h=(s,c)=>{if(typeof s=="number"){x(s,c,"auto");return}const{left:m,top:p,index:w,key:k,position:S,behavior:T,debounce:P=!0}=s;if(m!==void 0||p!==void 0)x(m,p,T);else if(w!==void 0)R(w,T,P);else if(k!==void 0){const O=a.value.get(k);O!==void 0&&R(O,T,P)}else S==="bottom"?x(0,Number.MAX_SAFE_INTEGER,T):S==="top"&&x(0,0,T)};let F,I=null;function R(s,c,m){const{value:p}=g,w=p.sum(s)+ae(e.paddingTop);if(!m)r.value.scrollTo({left:0,top:w,behavior:c});else{F=s,I!==null&&window.clearTimeout(I),I=window.setTimeout(()=>{F=void 0,I=null},16);const{scrollTop:k,offsetHeight:S}=r.value;if(w>k){const T=p.get(s);w+T<=k+S||r.value.scrollTo({left:0,top:w+T-S,behavior:c})}else r.value.scrollTo({left:0,top:w,behavior:c})}}function x(s,c,m){r.value.scrollTo({left:s,top:c,behavior:m})}function B(s,c){var m,p,w;if(o||e.ignoreItemResize||U(c.target))return;const{value:k}=g,S=a.value.get(s),T=k.get(S),P=(w=(p=(m=c.borderBoxSize)===null||m===void 0?void 0:m[0])===null||p===void 0?void 0:p.blockSize)!==null&&w!==void 0?w:c.contentRect.height;if(P===T)return;P-e.itemSize===0?f.delete(s):f.set(s,P-e.itemSize);const V=P-T;if(V===0)return;k.add(S,V);const n=r.value;if(n!=null){if(F===void 0){const i=k.sum(S);n.scrollTop>i&&n.scrollBy(0,V)}else if(S<F)n.scrollBy(0,V);else if(S===F){const i=k.sum(S);P+i>n.scrollTop+n.offsetHeight&&n.scrollBy(0,V)}q()}y.value++}const A=!ft();let W=!1;function ee(s){var c;(c=e.onScroll)===null||c===void 0||c.call(e,s),(!A||!W)&&q()}function te(s){var c;if((c=e.onWheel)===null||c===void 0||c.call(e,s),A){const m=r.value;if(m!=null){if(s.deltaX===0&&(m.scrollTop===0&&s.deltaY<=0||m.scrollTop+m.offsetHeight>=m.scrollHeight&&s.deltaY>=0))return;s.preventDefault(),m.scrollTop+=s.deltaY/ye(),m.scrollLeft+=s.deltaX/ye(),q(),W=!0,ot(()=>{W=!1})}}}function ne(s){if(o||U(s.target)||s.contentRect.height===d.value)return;d.value=s.contentRect.height;const{onResize:c}=e;c!==void 0&&c(s)}function q(){const{value:s}=r;s!=null&&(b.value=s.scrollTop,v=s.scrollLeft)}function U(s){let c=s;for(;c!==null;){if(c.style.display==="none")return!0;c=c.parentElement}return!1}return{listHeight:d,listStyle:{overflow:"auto"},keyToIndex:a,itemsStyle:z(()=>{const{itemResizable:s}=e,c=Y(g.value.sum());return y.value,[e.itemsStyle,{boxSizing:"content-box",height:s?"":c,minHeight:s?c:"",paddingTop:Y(e.paddingTop),paddingBottom:Y(e.paddingBottom)}]}),visibleItemsStyle:z(()=>(y.value,{transform:`translateY(${Y(g.value.sum(C.value))})`})),viewportItems:N,listElRef:r,itemsElRef:H(null),scrollTo:h,handleListResize:ne,handleListScroll:ee,handleListWheel:te,handleItemResize:B}},render(){const{itemResizable:e,keyField:t,keyToIndex:o,visibleItemsTag:l}=this;return u(pe,{onResize:this.handleListResize},{default:()=>{var a,r;return u("div",Ue(this.$attrs,{class:["v-vl",this.showScrollbar&&"v-vl--show-scrollbar"],onScroll:this.handleListScroll,onWheel:this.handleListWheel,ref:"listElRef"}),[this.items.length!==0?u("div",{ref:"itemsElRef",class:"v-vl-items",style:this.itemsStyle},[u(l,Object.assign({class:"v-vl-visible-items",style:this.visibleItemsStyle},this.visibleItemsProps),{default:()=>this.viewportItems.map(d=>{const f=d[t],g=o.get(f),y=this.$slots.default({item:d,index:g})[0];return e?u(pe,{key:f,onResize:v=>this.handleItemResize(f,v)},{default:()=>y}):(y.key=f,y)})})]):(r=(a=this.$slots).empty)===null||r===void 0?void 0:r.call(a)])}})}});function mt(e,t){t&&(de(()=>{const{value:o}=e;o&&ge.registerHandler(o,t)}),we(()=>{const{value:o}=e;o&&ge.unregisterHandler(o)}))}const pt=$({name:"Checkmark",render(){return u("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 16 16"},u("g",{fill:"none"},u("path",{d:"M14.046 3.486a.75.75 0 0 1-.032 1.06l-7.93 7.474a.85.85 0 0 1-1.188-.022l-2.68-2.72a.75.75 0 1 1 1.068-1.053l2.234 2.267l7.468-7.038a.75.75 0 0 1 1.06.032z",fill:"currentColor"})))}}),gt=$({name:"Empty",render(){return u("svg",{viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg"},u("path",{d:"M26 7.5C26 11.0899 23.0899 14 19.5 14C15.9101 14 13 11.0899 13 7.5C13 3.91015 15.9101 1 19.5 1C23.0899 1 26 3.91015 26 7.5ZM16.8536 4.14645C16.6583 3.95118 16.3417 3.95118 16.1464 4.14645C15.9512 4.34171 15.9512 4.65829 16.1464 4.85355L18.7929 7.5L16.1464 10.1464C15.9512 10.3417 15.9512 10.6583 16.1464 10.8536C16.3417 11.0488 16.6583 11.0488 16.8536 10.8536L19.5 8.20711L22.1464 10.8536C22.3417 11.0488 22.6583 11.0488 22.8536 10.8536C23.0488 10.6583 23.0488 10.3417 22.8536 10.1464L20.2071 7.5L22.8536 4.85355C23.0488 4.65829 23.0488 4.34171 22.8536 4.14645C22.6583 3.95118 22.3417 3.95118 22.1464 4.14645L19.5 6.79289L16.8536 4.14645Z",fill:"currentColor"}),u("path",{d:"M25 22.75V12.5991C24.5572 13.0765 24.053 13.4961 23.5 13.8454V16H17.5L17.3982 16.0068C17.0322 16.0565 16.75 16.3703 16.75 16.75C16.75 18.2688 15.5188 19.5 14 19.5C12.4812 19.5 11.25 18.2688 11.25 16.75L11.2432 16.6482C11.1935 16.2822 10.8797 16 10.5 16H4.5V7.25C4.5 6.2835 5.2835 5.5 6.25 5.5H12.2696C12.4146 4.97463 12.6153 4.47237 12.865 4H6.25C4.45507 4 3 5.45507 3 7.25V22.75C3 24.5449 4.45507 26 6.25 26H21.75C23.5449 26 25 24.5449 25 22.75ZM4.5 22.75V17.5H9.81597L9.85751 17.7041C10.2905 19.5919 11.9808 21 14 21L14.215 20.9947C16.2095 20.8953 17.842 19.4209 18.184 17.5H23.5V22.75C23.5 23.7165 22.7165 24.5 21.75 24.5H6.25C5.2835 24.5 4.5 23.7165 4.5 22.75Z",fill:"currentColor"}))}}),bt=$({props:{onFocus:Function,onBlur:Function},setup(e){return()=>u("div",{style:"width: 0; height: 0",tabindex:0,onFocus:e.onFocus,onBlur:e.onBlur})}}),yt=E("empty",`
 display: flex;
 flex-direction: column;
 align-items: center;
 font-size: var(--n-font-size);
`,[L("icon",`
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 font-size: var(--n-icon-size);
 line-height: var(--n-icon-size);
 color: var(--n-icon-color);
 transition:
 color .3s var(--n-bezier);
 `,[K("+",[L("description",`
 margin-top: 8px;
 `)])]),L("description",`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 `),L("extra",`
 text-align: center;
 transition: color .3s var(--n-bezier);
 margin-top: 12px;
 color: var(--n-extra-text-color);
 `)]),xt=Object.assign(Object.assign({},J.props),{description:String,showDescription:{type:Boolean,default:!0},showIcon:{type:Boolean,default:!0},size:{type:String,default:"medium"},renderIcon:Function}),St=$({name:"Empty",props:xt,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:o}=Re(e),l=J("Empty","-empty",yt,st,e,t),{localeRef:a}=ct("Empty"),r=ce(Ye,null),d=z(()=>{var v,b,C;return(v=e.description)!==null&&v!==void 0?v:(C=(b=r==null?void 0:r.mergedComponentPropsRef.value)===null||b===void 0?void 0:b.Empty)===null||C===void 0?void 0:C.description}),f=z(()=>{var v,b;return((b=(v=r==null?void 0:r.mergedComponentPropsRef.value)===null||v===void 0?void 0:v.Empty)===null||b===void 0?void 0:b.renderIcon)||(()=>u(gt,null))}),g=z(()=>{const{size:v}=e,{common:{cubicBezierEaseInOut:b},self:{[D("iconSize",v)]:C,[D("fontSize",v)]:N,textColor:h,iconColor:F,extraTextColor:I}}=l.value;return{"--n-icon-size":C,"--n-font-size":N,"--n-bezier":b,"--n-text-color":h,"--n-icon-color":F,"--n-extra-text-color":I}}),y=o?ze("empty",z(()=>{let v="";const{size:b}=e;return v+=b[0],v}),g,e):void 0;return{mergedClsPrefix:t,mergedRenderIcon:f,localizedDescription:z(()=>d.value||a.value.description),cssVars:o?void 0:g,themeClass:y==null?void 0:y.themeClass,onRender:y==null?void 0:y.onRender}},render(){const{$slots:e,mergedClsPrefix:t,onRender:o}=this;return o==null||o(),u("div",{class:[`${t}-empty`,this.themeClass],style:this.cssVars},this.showIcon?u("div",{class:`${t}-empty__icon`},e.icon?e.icon():u(Ce,{clsPrefix:t},{default:this.mergedRenderIcon})):null,this.showDescription?u("div",{class:`${t}-empty__description`},e.default?e.default():this.localizedDescription):null,e.extra?u("div",{class:`${t}-empty__extra`},e.extra()):null)}});function wt(e,t){return u(Ze,{name:"fade-in-scale-up-transition"},{default:()=>e?u(Ce,{clsPrefix:t,class:`${t}-base-select-option__check`},{default:()=>u(pt)}):null})}const xe=$({name:"NBaseSelectOption",props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(e){const{valueRef:t,pendingTmNodeRef:o,multipleRef:l,valueSetRef:a,renderLabelRef:r,renderOptionRef:d,labelFieldRef:f,valueFieldRef:g,showCheckmarkRef:y,nodePropsRef:v,handleOptionClick:b,handleOptionMouseEnter:C}=ce(ue),N=X(()=>{const{value:R}=o;return R?e.tmNode.key===R.key:!1});function h(R){const{tmNode:x}=e;x.disabled||b(R,x)}function F(R){const{tmNode:x}=e;x.disabled||C(R,x)}function I(R){const{tmNode:x}=e,{value:B}=N;x.disabled||B||C(R,x)}return{multiple:l,isGrouped:X(()=>{const{tmNode:R}=e,{parent:x}=R;return x&&x.rawNode.type==="group"}),showCheckmark:y,nodeProps:v,isPending:N,isSelected:X(()=>{const{value:R}=t,{value:x}=l;if(R===null)return!1;const B=e.tmNode.rawNode[g.value];if(x){const{value:A}=a;return A.has(B)}else return R===B}),labelField:f,renderLabel:r,renderOption:d,handleMouseMove:I,handleMouseEnter:F,handleClick:h}},render(){const{clsPrefix:e,tmNode:{rawNode:t},isSelected:o,isPending:l,isGrouped:a,showCheckmark:r,nodeProps:d,renderOption:f,renderLabel:g,handleClick:y,handleMouseEnter:v,handleMouseMove:b}=this,C=wt(o,e),N=g?[g(t,o),r&&C]:[ke(t[this.labelField],t,o),r&&C],h=d==null?void 0:d(t),F=u("div",Object.assign({},h,{class:[`${e}-base-select-option`,t.class,h==null?void 0:h.class,{[`${e}-base-select-option--disabled`]:t.disabled,[`${e}-base-select-option--selected`]:o,[`${e}-base-select-option--grouped`]:a,[`${e}-base-select-option--pending`]:l,[`${e}-base-select-option--show-checkmark`]:r}],style:[(h==null?void 0:h.style)||"",t.style||""],onClick:re([y,h==null?void 0:h.onClick]),onMouseenter:re([v,h==null?void 0:h.onMouseenter]),onMousemove:re([b,h==null?void 0:h.onMousemove])}),u("div",{class:`${e}-base-select-option__content`},N));return t.render?t.render({node:F,option:t,selected:o}):f?f({node:F,option:t,selected:o}):F}}),Se=$({name:"NBaseSelectGroupHeader",props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(){const{renderLabelRef:e,renderOptionRef:t,labelFieldRef:o,nodePropsRef:l}=ce(ue);return{labelField:o,nodeProps:l,renderLabel:e,renderOption:t}},render(){const{clsPrefix:e,renderLabel:t,renderOption:o,nodeProps:l,tmNode:{rawNode:a}}=this,r=l==null?void 0:l(a),d=t?t(a,!1):ke(a[this.labelField],a,!1),f=u("div",Object.assign({},r,{class:[`${e}-base-select-group-header`,r==null?void 0:r.class]}),d);return a.render?a.render({node:f,option:a}):o?o({node:f,option:a,selected:!1}):f}}),Rt=E("base-select-menu",`
 line-height: 1.5;
 outline: none;
 z-index: 0;
 position: relative;
 border-radius: var(--n-border-radius);
 transition:
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 background-color: var(--n-color);
`,[E("scrollbar",`
 max-height: var(--n-height);
 `),E("virtual-list",`
 max-height: var(--n-height);
 `),E("base-select-option",`
 min-height: var(--n-option-height);
 font-size: var(--n-option-font-size);
 display: flex;
 align-items: center;
 `,[L("content",`
 z-index: 1;
 white-space: nowrap;
 text-overflow: ellipsis;
 overflow: hidden;
 `)]),E("base-select-group-header",`
 min-height: var(--n-option-height);
 font-size: .93em;
 display: flex;
 align-items: center;
 `),E("base-select-menu-option-wrapper",`
 position: relative;
 width: 100%;
 `),L("loading, empty",`
 display: flex;
 padding: 12px 32px;
 flex: 1;
 justify-content: center;
 `),L("loading",`
 color: var(--n-loading-color);
 font-size: var(--n-loading-size);
 `),L("header",`
 padding: 8px var(--n-option-padding-left);
 font-size: var(--n-option-font-size);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-action-divider-color);
 color: var(--n-action-text-color);
 `),L("action",`
 padding: 8px var(--n-option-padding-left);
 font-size: var(--n-option-font-size);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 border-top: 1px solid var(--n-action-divider-color);
 color: var(--n-action-text-color);
 `),E("base-select-group-header",`
 position: relative;
 cursor: default;
 padding: var(--n-option-padding);
 color: var(--n-group-header-text-color);
 `),E("base-select-option",`
 cursor: pointer;
 position: relative;
 padding: var(--n-option-padding);
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 box-sizing: border-box;
 color: var(--n-option-text-color);
 opacity: 1;
 `,[j("show-checkmark",`
 padding-right: calc(var(--n-option-padding-right) + 20px);
 `),K("&::before",`
 content: "";
 position: absolute;
 left: 4px;
 right: 4px;
 top: 0;
 bottom: 0;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),K("&:active",`
 color: var(--n-option-text-color-pressed);
 `),j("grouped",`
 padding-left: calc(var(--n-option-padding-left) * 1.5);
 `),j("pending",[K("&::before",`
 background-color: var(--n-option-color-pending);
 `)]),j("selected",`
 color: var(--n-option-text-color-active);
 `,[K("&::before",`
 background-color: var(--n-option-color-active);
 `),j("pending",[K("&::before",`
 background-color: var(--n-option-color-active-pending);
 `)])]),j("disabled",`
 cursor: not-allowed;
 `,[Xe("selected",`
 color: var(--n-option-text-color-disabled);
 `),j("selected",`
 opacity: var(--n-option-opacity-disabled);
 `)]),L("check",`
 font-size: 16px;
 position: absolute;
 right: calc(var(--n-option-padding-right) - 4px);
 top: calc(50% - 7px);
 color: var(--n-option-check-color);
 transition: color .3s var(--n-bezier);
 `,[rt({enterScale:"0.5"})])])]),It=$({name:"InternalSelectMenu",props:Object.assign(Object.assign({},J.props),{clsPrefix:{type:String,required:!0},scrollable:{type:Boolean,default:!0},treeMate:{type:Object,required:!0},multiple:Boolean,size:{type:String,default:"medium"},value:{type:[String,Number,Array],default:null},autoPending:Boolean,virtualScroll:{type:Boolean,default:!0},show:{type:Boolean,default:!0},labelField:{type:String,default:"label"},valueField:{type:String,default:"value"},loading:Boolean,focusable:Boolean,renderLabel:Function,renderOption:Function,nodeProps:Function,showCheckmark:{type:Boolean,default:!0},onMousedown:Function,onScroll:Function,onFocus:Function,onBlur:Function,onKeyup:Function,onKeydown:Function,onTabOut:Function,onMouseenter:Function,onMouseleave:Function,onResize:Function,resetMenuOnOptionsChange:{type:Boolean,default:!0},inlineThemeDisabled:Boolean,onToggle:Function}),setup(e){const{mergedClsPrefixRef:t,mergedRtlRef:o}=Re(e),l=Je("InternalSelectMenu",o,t),a=J("InternalSelectMenu","-internal-select-menu",Rt,at,e,_(e,"clsPrefix")),r=H(null),d=H(null),f=H(null),g=z(()=>e.treeMate.getFlattenedNodes()),y=z(()=>it(g.value)),v=H(null);function b(){const{treeMate:n}=e;let i=null;const{value:M}=e;M===null?i=n.getFirstAvailableNode():(e.multiple?i=n.getNode((M||[])[(M||[]).length-1]):i=n.getNode(M),(!i||i.disabled)&&(i=n.getFirstAvailableNode())),p(i||null)}function C(){const{value:n}=v;n&&!e.treeMate.getNode(n.key)&&(v.value=null)}let N;fe(()=>e.show,n=>{n?N=fe(()=>e.treeMate,()=>{e.resetMenuOnOptionsChange?(e.autoPending?b():C(),tt(w)):C()},{immediate:!0}):N==null||N()},{immediate:!0}),we(()=>{N==null||N()});const h=z(()=>ae(a.value.self[D("optionHeight",e.size)])),F=z(()=>le(a.value.self[D("padding",e.size)])),I=z(()=>e.multiple&&Array.isArray(e.value)?new Set(e.value):new Set),R=z(()=>{const n=g.value;return n&&n.length===0});function x(n){const{onToggle:i}=e;i&&i(n)}function B(n){const{onScroll:i}=e;i&&i(n)}function A(n){var i;(i=f.value)===null||i===void 0||i.sync(),B(n)}function W(){var n;(n=f.value)===null||n===void 0||n.sync()}function ee(){const{value:n}=v;return n||null}function te(n,i){i.disabled||p(i,!1)}function ne(n,i){i.disabled||x(i)}function q(n){var i;me(n,"action")||(i=e.onKeyup)===null||i===void 0||i.call(e,n)}function U(n){var i;me(n,"action")||(i=e.onKeydown)===null||i===void 0||i.call(e,n)}function s(n){var i;(i=e.onMousedown)===null||i===void 0||i.call(e,n),!e.focusable&&n.preventDefault()}function c(){const{value:n}=v;n&&p(n.getNext({loop:!0}),!0)}function m(){const{value:n}=v;n&&p(n.getPrev({loop:!0}),!0)}function p(n,i=!1){v.value=n,i&&w()}function w(){var n,i;const M=v.value;if(!M)return;const G=y.value(M.key);G!==null&&(e.virtualScroll?(n=d.value)===null||n===void 0||n.scrollTo({index:G}):(i=f.value)===null||i===void 0||i.scrollTo({index:G,elSize:h.value}))}function k(n){var i,M;!((i=r.value)===null||i===void 0)&&i.contains(n.target)&&((M=e.onFocus)===null||M===void 0||M.call(e,n))}function S(n){var i,M;!((i=r.value)===null||i===void 0)&&i.contains(n.relatedTarget)||(M=e.onBlur)===null||M===void 0||M.call(e,n)}ve(ue,{handleOptionMouseEnter:te,handleOptionClick:ne,valueSetRef:I,pendingTmNodeRef:v,nodePropsRef:_(e,"nodeProps"),showCheckmarkRef:_(e,"showCheckmark"),multipleRef:_(e,"multiple"),valueRef:_(e,"value"),renderLabelRef:_(e,"renderLabel"),renderOptionRef:_(e,"renderOption"),labelFieldRef:_(e,"labelField"),valueFieldRef:_(e,"valueField")}),ve(lt,r),de(()=>{const{value:n}=f;n&&n.sync()});const T=z(()=>{const{size:n}=e,{common:{cubicBezierEaseInOut:i},self:{height:M,borderRadius:G,color:Me,groupHeaderTextColor:Ne,actionDividerColor:Fe,optionTextColorPressed:Pe,optionTextColor:Ie,optionTextColorDisabled:Oe,optionTextColorActive:Le,optionOpacityDisabled:Be,optionCheckColor:_e,actionTextColor:Ee,optionColorPending:He,optionColorActive:$e,loadingColor:Ve,loadingSize:je,optionColorActivePending:De,[D("optionFontSize",n)]:Ae,[D("optionHeight",n)]:Ke,[D("optionPadding",n)]:oe}}=a.value;return{"--n-height":M,"--n-action-divider-color":Fe,"--n-action-text-color":Ee,"--n-bezier":i,"--n-border-radius":G,"--n-color":Me,"--n-option-font-size":Ae,"--n-group-header-text-color":Ne,"--n-option-check-color":_e,"--n-option-color-pending":He,"--n-option-color-active":$e,"--n-option-color-active-pending":De,"--n-option-height":Ke,"--n-option-opacity-disabled":Be,"--n-option-text-color":Ie,"--n-option-text-color-active":Le,"--n-option-text-color-disabled":Oe,"--n-option-text-color-pressed":Pe,"--n-option-padding":oe,"--n-option-padding-left":le(oe,"left"),"--n-option-padding-right":le(oe,"right"),"--n-loading-color":Ve,"--n-loading-size":je}}),{inlineThemeDisabled:P}=e,O=P?ze("internal-select-menu",z(()=>e.size[0]),T,e):void 0,V={selfRef:r,next:c,prev:m,getPendingTmNode:ee};return mt(r,e.onResize),Object.assign({mergedTheme:a,mergedClsPrefix:t,rtlEnabled:l,virtualListRef:d,scrollbarRef:f,itemSize:h,padding:F,flattenedNodes:g,empty:R,virtualListContainer(){const{value:n}=d;return n==null?void 0:n.listElRef},virtualListContent(){const{value:n}=d;return n==null?void 0:n.itemsElRef},doScroll:B,handleFocusin:k,handleFocusout:S,handleKeyUp:q,handleKeyDown:U,handleMouseDown:s,handleVirtualListResize:W,handleVirtualListScroll:A,cssVars:P?void 0:T,themeClass:O==null?void 0:O.themeClass,onRender:O==null?void 0:O.onRender},V)},render(){const{$slots:e,virtualScroll:t,clsPrefix:o,mergedTheme:l,themeClass:a,onRender:r}=this;return r==null||r(),u("div",{ref:"selfRef",tabindex:this.focusable?0:-1,class:[`${o}-base-select-menu`,this.rtlEnabled&&`${o}-base-select-menu--rtl`,a,this.multiple&&`${o}-base-select-menu--multiple`],style:this.cssVars,onFocusin:this.handleFocusin,onFocusout:this.handleFocusout,onKeyup:this.handleKeyUp,onKeydown:this.handleKeyDown,onMousedown:this.handleMouseDown,onMouseenter:this.onMouseenter,onMouseleave:this.onMouseleave},he(e.header,d=>d&&u("div",{class:`${o}-base-select-menu__header`,"data-header":!0,key:"header"},d)),this.loading?u("div",{class:`${o}-base-select-menu__loading`},u(Qe,{clsPrefix:o,strokeWidth:20})):this.empty?u("div",{class:`${o}-base-select-menu__empty`,"data-empty":!0},et(e.empty,()=>[u(St,{theme:l.peers.Empty,themeOverrides:l.peerOverrides.Empty})])):u(dt,{ref:"scrollbarRef",theme:l.peers.Scrollbar,themeOverrides:l.peerOverrides.Scrollbar,scrollable:this.scrollable,container:t?this.virtualListContainer:void 0,content:t?this.virtualListContent:void 0,onScroll:t?void 0:this.doScroll},{default:()=>t?u(ht,{ref:"virtualListRef",class:`${o}-virtual-list`,items:this.flattenedNodes,itemSize:this.itemSize,showScrollbar:!1,paddingTop:this.padding.top,paddingBottom:this.padding.bottom,onResize:this.handleVirtualListResize,onScroll:this.handleVirtualListScroll,itemResizable:!0},{default:({item:d})=>d.isGroup?u(Se,{key:d.key,clsPrefix:o,tmNode:d}):d.ignored?null:u(xe,{clsPrefix:o,key:d.key,tmNode:d})}):u("div",{class:`${o}-base-select-menu-option-wrapper`,style:{paddingTop:this.padding.top,paddingBottom:this.padding.bottom}},this.flattenedNodes.map(d=>d.isGroup?u(Se,{key:d.key,clsPrefix:o,tmNode:d}):u(xe,{clsPrefix:o,key:d.key,tmNode:d})))}),he(e.action,d=>d&&[u("div",{class:`${o}-base-select-menu__action`,"data-action":!0,key:"action"},d),u(bt,{onFocus:this.onTabOut,key:"focus-detector"})]))}});function Q(e){return e.type==="group"}function Te(e){return e.type==="ignored"}function Ot(e,t){try{return!!(1+t.toString().toLowerCase().indexOf(e.trim().toLowerCase()))}catch{return!1}}function Lt(e,t){return{getIsGroup:Q,getIgnored:Te,getKey(l){return Q(l)?l.name||l.key||"key-required":l[e]},getChildren(l){return l[t]}}}function Bt(e,t,o,l){if(!t)return e;function a(r){if(!Array.isArray(r))return[];const d=[];for(const f of r)if(Q(f)){const g=a(f[l]);g.length&&d.push(Object.assign({},f,{[l]:g}))}else{if(Te(f))continue;t(o,f)&&d.push(f)}return d}return a(e)}function _t(e,t,o){const l=new Map;return e.forEach(a=>{Q(a)?a[o].forEach(r=>{l.set(r[t],r)}):l.set(a[t],a)}),l}export{It as N,ht as V,_t as a,St as b,Lt as c,Bt as f,re as m,Ot as p,mt as u};
